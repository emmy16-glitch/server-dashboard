import { useMemo, useState } from "react";
import { AGENT, store, useStore } from "../lib/store";
import type { Project } from "../lib/types";
import { ago } from "../lib/types";
import { Label, Panel, SectionLabel, Tag } from "../components/ui";
import type { Route } from "../components/Shell";

const BLANK = {
  id: "",
  name: "",
  type: "local" as "local" | "external",
  healthUrl: "",
  port: "3000",
  command: "npm",
  provider: "vercel" as "vercel" | "railway" | "render" | "other",
};

export function RegistryView({ go }: { go: (r: Route) => void }) {
  const w = useStore();
  const [form, setForm] = useState(BLANK);
  const [err, setErr] = useState<string | null>(null);
  const [json, setJson] = useState<string | null>(null);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const text = useMemo(
    () =>
      json ??
      JSON.stringify(
        {
          version: 1,
          agents: [{ id: AGENT.id, hostname: AGENT.hostname, platform: AGENT.platform }],
          projects: w.projects,
        },
        null,
        2,
      ),
    [json, w.projects],
  );

  const submit = () => {
    setErr(null);
    const port = Number(form.port);
    if (!/^[a-z0-9-]{2,40}$/.test(form.id)) return setErr("id must match ^[a-z0-9-]{2,40}$ — lowercase, digits, dashes");
    if (w.projects.some((p) => p.id === form.id)) return setErr("id already exists — ids are stable and never renamed");
    if (!/^https?:\/\//.test(form.healthUrl)) return setErr("healthUrl must be http(s)://…");
    if (form.type === "local" && (form.command || "").trim().length === 0) return setErr("command is required for local projects");
    const ok = store.addProject({
      id: form.id,
      name: form.name || form.id,
      type: form.type,
      healthUrl: form.healthUrl,
      port: form.type === "local" && port >= 1024 && port <= 65535 ? port : undefined,
      command: form.command,
      provider: form.provider,
    });
    if (ok) {
      setForm(BLANK);
      setJson(null);
    }
  };

  return (
    <div className="pb-4">
      <section className="grid grid-cols-12 gap-x-6 gap-y-6 pb-6">
        <div className="col-span-12 lg:col-span-7">
          <Label>projects.json · the registry</Label>
          <h1 className="display mt-3 text-[34px] leading-[1] sm:text-[42px]">
            Registry,
            <br />
            not autodiscovery.
          </h1>
          <p className="mt-3 max-w-[50ch] text-[12.5px] leading-relaxed" style={{ color: "var(--ink-2)" }}>
            If it isn’t in the registry, it isn’t monitored. Local projects are spawned and owned by this box; external
            ones are pinged and linked out. Secrets never live here — only paths and masked names.
          </p>
        </div>
        <div className="col-span-12 grid grid-cols-2 gap-3 sm:grid-cols-4 lg:col-span-5 lg:grid-cols-2">
          {[
            ["projects", w.projects.length],
            ["local", w.projects.filter((p) => p.location.type === "local").length],
            ["external", w.projects.filter((p) => p.location.type === "external").length],
            ["allowed roots", 2],
          ].map(([k, v]) => (
            <Panel key={k as string} className="p-4">
              <div className="label">{k as string}</div>
              <div className="display tnum mt-2 text-[26px] leading-none">{v as number}</div>
            </Panel>
          ))}
        </div>
      </section>

      <div className="grid grid-cols-12 gap-3">
        {/* table */}
        <div className="col-span-12 xl:col-span-7">
          <Panel flat className="overflow-hidden">
            <div className="flex items-center justify-between px-4 py-2.5 hair-b">
              <span className="label">entries</span>
              <span className="mono text-[9px]" style={{ color: "var(--ink-3)" }}>
                PATCH /api/projects/:id · DELETE stops the process first
              </span>
            </div>
            <div className="scroll overflow-x-auto">
              <table className="w-full" style={{ borderCollapse: "collapse" }}>
                <thead>
                  <tr>
                    {["id", "type", "health", "int.", "state", ""].map((h) => (
                      <th key={h} className="label px-3 py-2 text-left hair-b whitespace-nowrap">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {w.projects.map((p: Project) => {
                    const l = w.live[p.id];
                    return (
                      <tr key={p.id} className="hair-b" style={{ borderColor: "var(--line)" }}>
                        <td className="px-3 py-2.5">
                          <button
                            className="mono text-[11px] hover:underline"
                            style={{ color: "var(--ink)", background: "none", border: 0, cursor: "pointer", padding: 0 }}
                            onClick={() => go({ view: "project", id: p.id, tab: "overview" })}
                          >
                            {p.id}
                          </button>
                          <div className="mono text-[9px]" style={{ color: "var(--ink-3)" }}>
                            {p.name}
                          </div>
                        </td>
                        <td className="px-3 py-2.5">
                          <Tag tone={p.location.type === "local" ? "accent" : "line"}>{p.location.type === "local" ? "local" : p.location.provider}</Tag>
                        </td>
                        <td className="mono px-3 py-2.5 text-[10px]" style={{ color: "var(--ink-2)" }}>
                          {p.runtime.healthUrl.replace(/^https?:\/\/[^/]+/, "")}
                        </td>
                        <td className="mono tnum px-3 py-2.5 text-[10.5px]">{p.monitoring.intervalSeconds}s</td>
                        <td className="px-3 py-2.5">
                          <span
                            className="mono text-[10px]"
                            style={{ color: !p.enabled ? "var(--ink-3)" : l?.status === "UP" ? "var(--up)" : l?.status === "DOWN" ? "var(--down)" : "var(--warn)" }}
                          >
                            {p.enabled ? l?.status ?? "—" : "disabled"}
                          </span>
                        </td>
                        <td className="px-3 py-2.5 text-right">
                          <div className="flex justify-end gap-1">
                            <button className="btn btn-sm" title="enable / disable monitoring" onClick={() => store.toggleProject(p.id)}>
                              {p.enabled ? "off" : "on"}
                            </button>
                            <button
                              className="btn btn-sm"
                              style={{ color: "var(--down)" }}
                              onClick={() => confirm(`DELETE ${p.id}?`) && store.removeProject(p.id)}
                            >
                              del
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Panel>

          {/* raw json */}
          <Panel className="mt-3 overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 hair-b">
              <span className="label">raw registry · editable</span>
              <div className="flex items-center gap-2">
                {msg && (
                  <span className="mono text-[9.5px]" style={{ color: msg.ok ? "var(--up)" : "var(--down)" }}>
                    {msg.text}
                  </span>
                )}
                <button
                  className="btn btn-sm btn-ghost"
                  onClick={() => {
                    setJson(null);
                    setMsg(null);
                  }}
                >
                  revert
                </button>
                <button
                  className="btn btn-sm btn-primary"
                  onClick={() => {
                    const r = store.applyRegistry(text);
                    setMsg(r.ok ? { ok: true, text: `validated · ${r.count} projects` } : { ok: false, text: r.error! });
                    if (r.ok) setJson(null);
                  }}
                >
                  validate &amp; apply
                </button>
              </div>
            </div>
            <textarea
              className="scroll mono w-full resize-y px-4 py-3 text-[11px] leading-[1.7] outline-none"
              style={{ background: "transparent", color: "var(--ink-2)", border: 0, minHeight: 320, tabSize: 2 }}
              spellCheck={false}
              value={text}
              onChange={(e) => setJson(e.target.value)}
            />
          </Panel>
        </div>

        {/* side */}
        <div className="col-span-12 space-y-3 xl:col-span-5">
          <Panel className="p-4">
            <SectionLabel right={<span className="mono text-[9px]" style={{ color: "var(--ink-3)" }}>POST /api/projects</span>}>
              register a project
            </SectionLabel>
            <div className="grid grid-cols-2 gap-2.5">
              <Field label="id *" value={form.id} onChange={(v) => setForm({ ...form, id: v })} placeholder="my-service" />
              <Field label="display name" value={form.name} onChange={(v) => setForm({ ...form, name: v })} placeholder="My Service" />
              <div className="col-span-2">
                <div className="label mb-1.5">location.type *</div>
                <div className="flex gap-1">
                  {(["local", "external"] as const).map((t) => (
                    <button
                      key={t}
                      className="chip"
                      onClick={() => setForm({ ...form, type: t })}
                      style={{
                        color: form.type === t ? "var(--bg)" : "var(--ink-2)",
                        background: form.type === t ? "var(--ink)" : "var(--surface-2)",
                        borderColor: "transparent",
                      }}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>
              <div className="col-span-2">
                <Field label="healthUrl *" value={form.healthUrl} onChange={(v) => setForm({ ...form, healthUrl: v })} placeholder="http://localhost:8080/health" />
              </div>
              {form.type === "local" ? (
                <>
                  <Field label="command" value={form.command} onChange={(v) => setForm({ ...form, command: v })} placeholder="npm" />
                  <Field label="port" value={form.port} onChange={(v) => setForm({ ...form, port: v })} placeholder="1024–65535" />
                </>
              ) : (
                <div className="col-span-2">
                  <div className="label mb-1.5">provider</div>
                  <div className="flex flex-wrap gap-1">
                    {(["vercel", "railway", "render", "other"] as const).map((pv) => (
                      <button
                        key={pv}
                        className="chip"
                        onClick={() => setForm({ ...form, provider: pv })}
                        style={{
                          color: form.provider === pv ? "var(--bg)" : "var(--ink-2)",
                          background: form.provider === pv ? "var(--ink)" : "var(--surface-2)",
                          borderColor: "transparent",
                        }}
                      >
                        {pv}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
            {err && (
              <div className="panel-inset mt-3 px-3 py-2" style={{ borderColor: "var(--down)" }}>
                <span className="mono text-[10.5px]" style={{ color: "var(--down)" }}>
                  ✕ {err}
                </span>
              </div>
            )}
            <div className="mt-3 flex items-center justify-between gap-2">
              <span className="mono text-[9px]" style={{ color: "var(--ink-3)" }}>
                cwd must sit inside an allowed root
              </span>
              <button className="btn btn-accent" onClick={submit} disabled={w.readOnly}>
                {w.readOnly ? "🔒 read-only" : "register project"}
              </button>
            </div>
          </Panel>

          <Panel className="p-4">
            <SectionLabel>validation rules</SectionLabel>
            <ul className="space-y-2">
              {[
                ["id", "^[a-z0-9-]{2,40}$ · unique · never renamed"],
                ["local", "cwd must exist inside allowedRoots (/root/projects, /root/Software_projects)"],
                ["local", "command from the safe-mode allowlist · port free or owned by the same project"],
                ["external", "healthUrl must be https?:// · no cwd, no command"],
                ["expectedStatus", "defaults to [200] · 404/500 ⇒ DEGRADED"],
                ["secrets", "never stored — only paths + masked names"],
              ].map(([k, v], i) => (
                <li key={i} className="flex gap-2.5">
                  <span className="mono mt-[3px] w-[86px] shrink-0 text-[9.5px] uppercase" style={{ color: "var(--accent)" }}>
                    {k}
                  </span>
                  <span className="mono text-[10.5px] leading-relaxed" style={{ color: "var(--ink-2)" }}>
                    {v}
                  </span>
                </li>
              ))}
            </ul>
          </Panel>

          <Panel className="p-4">
            <SectionLabel>storage evolution</SectionLabel>
            <p className="mono text-[10.5px] leading-relaxed" style={{ color: "var(--ink-2)" }}>
              v1 keeps JSON files — zero deps, survives proot. Migration to SQLite happens past ~50k checks or once we need
              queries (uptime %, p95, incidents by project). All access flows through storage/*.js so the swap stays local.
            </p>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {["projects.json", "deployments.json", "incidents.json", "status-history.json", "audit.json", "→ .sqlite"].map((f) => (
                <Tag key={f}>{f}</Tag>
              ))}
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <label className="block min-w-0">
      <span className="label mb-1.5 block">{label}</span>
      <input className="input w-full" value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} />
    </label>
  );
}

/* ═══════════════════════════ AUDIT ═══════════════════════════ */

export function AuditView() {
  const w = useStore();
  const [q, setQ] = useState("");
  const [only, setOnly] = useState<"all" | "ok" | "denied" | "fail">("all");
  const rows = w.audit.filter(
    (a) => (only === "all" || a.result === only) && (!q || `${a.actor} ${a.action} ${a.projectId} ${a.detail}`.toLowerCase().includes(q.toLowerCase())),
  );
  const tone = (r: string) => (r === "ok" ? "var(--up)" : r === "denied" ? "var(--warn)" : "var(--down)");

  return (
    <div className="pb-4">
      <div className="flex flex-wrap items-end justify-between gap-4 pb-5">
        <div>
          <Label>append-only · audit.json</Label>
          <h1 className="display mt-3 text-[32px] leading-none sm:text-[40px]">Every action, on the record.</h1>
          <p className="mono mt-3 max-w-[54ch] text-[10.5px] leading-relaxed" style={{ color: "var(--ink-3)" }}>
            process control, deploys, exec calls, AI tool use and denied commands are all written here. mutating errors never leak stack or env.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <input className="input" placeholder="grep the trail…" value={q} onChange={(e) => setQ(e.target.value)} />
          {(["all", "ok", "denied", "fail"] as const).map((f) => (
            <button
              key={f}
              className="chip"
              onClick={() => setOnly(f)}
              style={{
                color: only === f ? "var(--bg)" : "var(--ink-2)",
                background: only === f ? "var(--ink)" : "var(--surface-2)",
                borderColor: "transparent",
              }}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <Panel flat className="overflow-hidden">
        <div className="flex items-center justify-between px-4 py-2.5 hair-b">
          <span className="label">{rows.length} entries</span>
          <span className="mono text-[9px]" style={{ color: "var(--ink-3)" }}>
            newest first · capped at 260 in this session
          </span>
        </div>
        <div className="scroll max-h-[70vh] overflow-y-auto">
          <table className="w-full" style={{ borderCollapse: "collapse" }}>
            <tbody>
              {rows.map((a) => (
                <tr key={a.id} className="hair-b" style={{ borderColor: "var(--line)" }}>
                  <td className="mono tnum whitespace-nowrap px-3 py-2 text-[10px]" style={{ color: "var(--ink-3)" }}>
                    {new Date(a.ts).toISOString().slice(11, 19)}
                    <span className="hidden sm:inline"> · {ago(a.ts, w.clock)}</span>
                  </td>
                  <td className="mono whitespace-nowrap px-3 py-2 text-[10.5px]" style={{ color: "var(--ink)" }}>
                    {a.actor}
                  </td>
                  <td className="mono whitespace-nowrap px-3 py-2 text-[10.5px]" style={{ color: "var(--accent)" }}>
                    {a.action}
                  </td>
                  <td className="mono hidden px-3 py-2 text-[10.5px] sm:table-cell" style={{ color: "var(--ink-3)" }}>
                    {a.projectId}
                  </td>
                  <td className="mono px-3 py-2 text-[10.5px]" style={{ color: "var(--ink-2)" }}>
                    {a.detail}
                  </td>
                  <td className="mono px-3 py-2 text-right text-[10px] uppercase" style={{ color: tone(a.result) }}>
                    {a.result}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    </div>
  );
}
