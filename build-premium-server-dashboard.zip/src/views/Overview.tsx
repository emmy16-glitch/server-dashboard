import React, { useMemo } from "react";
import { AGENT, store, THEMES, useStore } from "../lib/store";
import type { Project, Range, Status } from "../lib/types";
import { ago, dur, pct, statusColor } from "../lib/types";
import { BigStat, Bars, Label, Panel, Ring, Segmented, Sparkline, StatusBadge, StatusDot, Tag, UptimeBar, cx } from "../components/ui";
import type { Route } from "../components/Shell";

const RANGES: readonly Range[] = ["1h", "24h", "7d", "30d"] as const;
const STATUSES: (Status | "ALL")[] = ["ALL", "UP", "DEGRADED", "DOWN", "STOPPED"];

/* ───────────────────────────── masthead ───────────────────────────── */

function Masthead({ go }: { go: (r: Route) => void }) {
  const w = useStore();
  const s = store.stats();
  const open = w.incidents.filter((i) => i.state !== "resolved");
  const worst = w.projects.find((p) => w.live[p.id]?.status === "DOWN") ?? w.projects.find((p) => w.live[p.id]?.status === "DEGRADED");

  return (
    <section className="grid grid-cols-12 gap-x-6 gap-y-8 pb-7">
      <div className="col-span-12 lg:col-span-7 xl:col-span-8">
        <div className="flex items-center gap-3">
          <Label>monitor · registry · recover</Label>
          <span className="h-px flex-1" style={{ background: "var(--line)" }} />
          <span className="mono text-[9.5px]" style={{ color: "var(--ink-3)" }}>
            {AGENT.hostname}
          </span>
        </div>
        <h1 className="display mt-4 text-[38px] leading-[0.98] sm:text-[48px] xl:text-[60px]">
          Everything
          <br />
          that should be up.
        </h1>
        <p className="mt-4 max-w-[46ch] text-[12.5px] leading-relaxed" style={{ color: "var(--ink-2)" }}>
          One registry, five local processes and three hosted URLs — checked every thirty seconds. If it isn't in{" "}
          <span className="mono" style={{ color: "var(--ink)" }}>
            projects.json
          </span>
          , it isn't monitored.
        </p>

        <div className="mt-5 flex flex-wrap items-center gap-2">
          {s.down > 0 && (
            <button className="btn btn-sm" style={{ borderColor: "var(--down)", color: "var(--down)" }} onClick={() => worst && go({ view: "project", id: worst.id, tab: "ai" })}>
              ✕ {s.down} down · {open.length} open incident{open.length === 1 ? "" : "s"} — diagnose
            </button>
          )}
          {s.degraded > 0 && (
            <button className="btn btn-sm" style={{ borderColor: "var(--warn)", color: "var(--warn)" }} onClick={() => store.set("statusFilter", "DEGRADED")}>
              ! {s.degraded} degraded
            </button>
          )}
          {s.down === 0 && s.degraded === 0 && <Tag tone="up">✓ all checks passing</Tag>}
          <Tag>{s.local} local · {s.external} external</Tag>
          <Tag>registry, not autodiscovery</Tag>
        </div>
      </div>

      <div className="col-span-12 lg:col-span-5 xl:col-span-4">
        <Panel className="flex items-center gap-5 p-5">
          <Ring value={s.fleet} label="fleet" />
          <div className="min-w-0 flex-1 space-y-3">
            <BigStat label="p50 latency" value={s.p50} unit="ms" />
            <div className="hair-t pt-3">
              <BigStat label="p95 latency" value={s.p95} unit="ms" />
            </div>
          </div>
        </Panel>
      </div>
    </section>
  );
}

/* ───────────────────────── design language band ───────────────────── */

function VersionBand() {
  const w = useStore();
  return (
    <div className="mb-6 flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
      <div className="flex items-baseline gap-3">
        <span className="label whitespace-nowrap">same data · four materials</span>
        <span className="hidden h-px flex-1 sm:block" style={{ background: "var(--line)" }} />
      </div>
      <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
        {THEMES.map((t) => {
          const on = w.theme === t.key;
          return (
            <button
              key={t.key}
              onClick={() => store.set("theme", t.key)}
              className="text-left transition-all"
              style={{
                padding: "8px 11px",
                border: `var(--bw) solid ${on ? "var(--line-2)" : "var(--line)"}`,
                background: on ? "var(--surface)" : "transparent",
                borderRadius: "calc(var(--r) * .8)",
                boxShadow: on ? "var(--shadow)" : "none",
              }}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="display text-[12.5px] leading-none">{t.name}</span>
                <span className="h-[7px] w-[7px]" style={{ background: on ? "var(--accent)" : "var(--surface-3)" }} />
              </div>
              <div className="mono mt-[6px] text-[9px] leading-tight" style={{ color: "var(--ink-3)" }}>
                {t.material}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ─────────────────────────── stat strip ──────────────────────────── */

function Strip() {
  const w = useStore();
  const s = store.stats();
  const cells: { k: string; v: React.ReactNode; tone?: string; sub?: string }[] = [
    { k: "monitored", v: s.total, sub: `${s.local} local / ${s.external} external` },
    { k: "up", v: s.up, tone: "var(--up)" },
    { k: "degraded", v: s.degraded, tone: "var(--warn)" },
    { k: "down", v: s.down, tone: "var(--down)" },
    { k: "stopped", v: s.stopped, tone: "var(--idle)" },
    { k: "incidents open", v: s.open, tone: s.open ? "var(--down)" : "var(--up)" },
    { k: "restarts 24h", v: w.projects.reduce((a, p) => a + (w.live[p.id]?.restarts ?? 0), 0) },
    { k: "checks stored", v: (24812 + s.checks * 8).toLocaleString(), sub: "status-history.json" },
  ];
  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 xl:grid-cols-8 hair hair-y">
      {cells.map((c, i) => (
        <div
          key={c.k}
          className={cx("px-4 py-3.5", i < cells.length - 1 && "sm:border-r")}
          style={{ borderRight: i === cells.length - 1 ? undefined : `var(--bw) solid var(--line)` }}
        >
          <div className="label">{c.k}</div>
          <div className="display tnum mt-2 text-[24px] leading-none" style={{ color: c.tone ?? "var(--ink)" }}>
            {c.v}
          </div>
          {c.sub && (
            <div className="mono mt-1.5 text-[9px]" style={{ color: "var(--ink-3)" }}>
              {c.sub}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

/* ─────────────────────────── control bar ─────────────────────────── */

function Controls() {
  const w = useStore();
  return (
    <div className="flex flex-wrap items-center gap-2 py-4">
      <div className="relative min-w-[190px] flex-1">
        <input
          className="input w-full"
          placeholder="filter by id · tag · path · url"
          value={w.filter}
          onChange={(e) => store.set("filter", e.target.value)}
        />
      </div>
      <div className="flex items-center gap-1">
        {STATUSES.map((s) => {
          const on = w.statusFilter === s;
          return (
            <button
              key={s}
              className="chip"
              onClick={() => store.set("statusFilter", s)}
              style={{
                color: on ? "var(--bg)" : s === "ALL" ? "var(--ink-2)" : statusColor(s),
                background: on ? (s === "ALL" ? "var(--ink)" : statusColor(s)) : "var(--surface-2)",
                borderColor: on ? "transparent" : "var(--line)",
              }}
            >
              {s === "ALL" ? "all" : s}
            </button>
          );
        })}
      </div>
      <div className="flex items-center gap-1">
        {(["ALL", "local", "external"] as const).map((e) => {
          const on = w.envFilter === e;
          return (
            <button
              key={e}
              className="chip"
              onClick={() => store.set("envFilter", e)}
              style={{
                color: on ? "var(--bg)" : "var(--ink-2)",
                background: on ? "var(--ink)" : "var(--surface-2)",
                borderColor: on ? "transparent" : "var(--line)",
              }}
            >
              {e === "ALL" ? "any env" : e}
            </button>
          );
        })}
      </div>
      <div className="ml-auto flex items-center gap-2">
        <span className="label">window</span>
        <Segmented value={w.range} options={RANGES} onChange={(r) => store.set("range", r)} />
      </div>
    </div>
  );
}

/* ──────────────────────────── project card ───────────────────────── */

function Card({ p, go, wide }: { p: Project; go: (r: Route) => void; wide: boolean }) {
  const w = useStore();
  const l = w.live[p.id];
  if (!l) return null;
  const local = p.location.type === "local";
  const open = w.incidents.find((i) => i.projectId === p.id && i.state !== "resolved");
  const tone = statusColor(l.status);

  return (
    <Panel
      className={cx("group relative flex cursor-pointer flex-col p-4 transition-all", wide && "md:col-span-2")}
      style={{ borderColor: l.status === "DOWN" ? "var(--down)" : l.status === "DEGRADED" ? "var(--warn)" : undefined }}
      onClick={() => go({ view: "project", id: p.id, tab: "overview" })}
    >
      {l.status === "DOWN" && <span className="hazard absolute right-0 top-0 h-[3px] w-full" />}

      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <StatusDot status={l.status} />
            <h3 className="display truncate text-[15px] leading-none">{p.name}</h3>
          </div>
          <div className="mono mt-2 truncate text-[10px]" style={{ color: "var(--ink-3)" }} title={p.location.cwd ?? p.runtime.healthUrl}>
            {p.id} · {local ? (p.location.cwd ?? "") : `${p.location.provider} · ${p.runtime.healthUrl.replace(/^https?:\/\//, "")}`}
          </div>
        </div>
        <StatusBadge status={l.status} />
      </div>

      <div className="mt-3.5">
        <Sparkline checks={l.history} tone={tone} height={wide ? 46 : 38} />
      </div>

      <div className="mt-3 grid grid-cols-4 gap-2">
        {[
          { k: "latency", v: l.latencyMs != null ? `${l.latencyMs}` : "—", u: "ms" },
          { k: `uptime ${w.range}`, v: pct(l.uptime[w.range]) },
          { k: "restarts", v: `${l.restarts}` },
          { k: "code", v: l.code ?? "—", tone: l.code === 200 ? "var(--up)" : l.code ? "var(--warn)" : "var(--down)" },
        ].map((m) => (
          <div key={m.k} className="min-w-0">
            <div className="label truncate">{m.k}</div>
            <div className="mono tnum mt-1.5 truncate text-[13px] leading-none" style={{ color: m.tone ?? "var(--ink)" }}>
              {m.v}
              {m.u && (
                <span className="text-[9px]" style={{ color: "var(--ink-3)" }}>
                  {" "}
                  {m.u}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-3.5">
        <UptimeBar checks={l.history} />
      </div>

      {wide && local && (
        <div className="mt-3 grid grid-cols-3 gap-4">
          <div>
            <div className="label">process</div>
            <div className="mono tnum mt-1.5 text-[11px]">
              {l.pid ? `pid ${l.pid}` : "not running"} · {dur(l.uptimeSec)}
            </div>
          </div>
          <div>
            <div className="label">cpu / mem</div>
            <div className="mono tnum mt-1.5 text-[11px]">
              {l.pid ? `${l.cpuPct.toFixed(1)}% · ${l.memMB.toFixed(0)}mb` : "—"}
            </div>
          </div>
          <div>
            <div className="label">last deploy</div>
            <div className="mono tnum mt-1.5 truncate text-[11px]">
              {w.deployments.find((d) => d.projectId === p.id)?.sha.slice(0, 7) ?? "—"} ·{" "}
              {w.deployments.find((d) => d.projectId === p.id) ? ago(w.deployments.find((d) => d.projectId === p.id)!.startedAt, w.clock) : "never"}
            </div>
          </div>
        </div>
      )}

      <div className="mt-4 flex items-center justify-between gap-2 hair-t pt-3">
        <div className="flex min-w-0 items-center gap-1.5">
          <Tag>{p.template}</Tag>
          {open && (
            <Tag tone="down">
              {open.id} {open.state}
            </Tag>
          )}
          {p.runtime.autoRestart && <Tag tone="accent">auto-restart</Tag>}
        </div>
        <div className="flex shrink-0 items-center gap-1.5">
          <span className="mono text-[9px]" style={{ color: "var(--ink-3)" }}>
            {ago(l.checkedAt, w.clock)} ago
          </span>
          <button
            className="btn btn-sm"
            onClick={(e) => {
              e.stopPropagation();
              if (local) store.restart(p.id);
              else store.toast("external project — control lives at the provider", "warn");
            }}
            disabled={!local || w.readOnly}
          >
            ↻
          </button>
          <button className="btn btn-sm" onClick={(e) => { e.stopPropagation(); go({ view: "project", id: p.id, tab: "overview" }); }}>
            open →
          </button>
        </div>
      </div>
    </Panel>
  );
}

/* ─────────────────────────────── view ────────────────────────────── */

export function Overview({ go }: { go: (r: Route) => void }) {
  const w = useStore();
  const list = useMemo(() => store.filtered(), [w]);
  const attention = [...list].sort((a, b) => rank(w.live[b.id]?.status) - rank(w.live[a.id]?.status));

  return (
    <>
      <Masthead go={go} />
      <VersionBand />
      <Strip />
      <Controls />

      {list.length === 0 ? (
        <Panel className="p-10 text-center">
          <div className="serif text-[20px]">No project matches that filter.</div>
          <p className="mono mt-2 text-[11px]" style={{ color: "var(--ink-3)" }}>
            the registry is the source of truth — nothing is discovered by scanning
          </p>
          <button className="btn mt-4" onClick={() => store.patch({ filter: "", statusFilter: "ALL", envFilter: "ALL" })}>
            clear filters
          </button>
        </Panel>
      ) : (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
          {attention.map((p) => (
            <Card key={p.id} p={p} go={go} wide={w.live[p.id]?.status === "DOWN"} />
          ))}
        </div>
      )}

      <section className="mt-8 grid grid-cols-12 gap-3">
        <Panel className="col-span-12 p-4 lg:col-span-8">
          <div className="flex items-center justify-between">
            <Label>latency · all projects · last 48 checks</Label>
            <span className="mono text-[9px]" style={{ color: "var(--ink-3)" }}>
              GET healthUrl · 10s timeout
            </span>
          </div>
          <div className="mt-4 space-y-3">
            {w.projects.map((p) => {
              const l = w.live[p.id];
              if (!l) return null;
              return (
                <button
                  key={p.id}
                  className="flex w-full items-center gap-3 text-left"
                  onClick={() => go({ view: "project", id: p.id, tab: "overview" })}
                  style={{ background: "none", border: 0, cursor: "pointer", padding: 0 }}
                >
                  <span className="mono w-[104px] shrink-0 truncate text-[10px]" style={{ color: "var(--ink-2)" }}>
                    {p.id}
                  </span>
                  <span className="flex-1">
                    <Bars checks={l.history} height={22} />
                  </span>
                  <span className="mono tnum w-[52px] shrink-0 text-right text-[10px]">
                    {l.latencyMs != null ? `${l.latencyMs}ms` : "—"}
                  </span>
                </button>
              );
            })}
          </div>
        </Panel>

        <Panel className="col-span-12 p-4 lg:col-span-4">
          <Label>host · /proc</Label>
          <div className="mt-4 space-y-4">
            {[
              { k: "cpu", v: 34, unit: "%", tone: "var(--accent)" },
              { k: "memory", v: 61, unit: "%", tone: "var(--accent)" },
              { k: "disk /", v: 75, unit: "%", tone: "var(--warn)" },
              { k: "battery", v: 88, unit: "%", tone: "var(--up)" },
            ].map((m) => (
              <div key={m.k}>
                <div className="mb-1.5 flex items-baseline justify-between">
                  <span className="label">{m.k}</span>
                  <span className="mono tnum text-[11px]">
                    {m.v}
                    {m.unit}
                  </span>
                </div>
                <div className="h-[5px] w-full" style={{ background: "var(--surface-3)" }}>
                  <div className="h-full transition-all" style={{ width: `${m.v}%`, background: m.tone }} />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-5 space-y-1.5 hair-t pt-4">
            {[
              ["platform", AGENT.platform],
              ["node", "v20.11.0"],
              ["storage", "file json → sqlite later"],
              ["inbound", "none — agents dial out"],
            ].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between gap-3">
                <span className="label">{k}</span>
                <span className="mono text-[10px]" style={{ color: "var(--ink-2)" }}>
                  {v}
                </span>
              </div>
            ))}
          </div>
        </Panel>
      </section>
    </>
  );
}

function rank(s?: Status) {
  return s === "DOWN" ? 5 : s === "DEGRADED" ? 4 : s === "STARTING" ? 3 : s === "STOPPED" ? 2 : s === "DISABLED" ? 1 : 0;
}
