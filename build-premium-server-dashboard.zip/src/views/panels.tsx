import { useEffect, useRef, useState } from "react";
import { ALLOWLIST, store, useStore } from "../lib/store";
import type { Deployment, Incident, Project } from "../lib/types";
import { ago, dur, pct } from "../lib/types";
import { Bars, Label, Panel, SectionLabel, Sparkline, StatusBadge, Tag, Toggle, cx } from "../components/ui";

/* ═════════════════════════════ LOGS ═════════════════════════════ */

const LEVEL_TONE: Record<string, string> = {
  sys: "var(--ink-3)",
  info: "var(--ink-2)",
  ok: "var(--up)",
  warn: "var(--warn)",
  error: "var(--down)",
};

export function LogsPanel({ p }: { p: Project }) {
  const w = useStore();
  const l = w.live[p.id];
  const [q, setQ] = useState("");
  const [levels, setLevels] = useState<string[]>(["sys", "info", "ok", "warn", "error"]);
  const [follow, setFollow] = useState(true);
  const [wrap, setWrap] = useState(true);
  const box = useRef<HTMLDivElement>(null);

  const lines = l.logs.filter(
    (x) => levels.includes(x.level) && (!q || x.msg.toLowerCase().includes(q.toLowerCase())),
  );

  useEffect(() => {
    if (follow && box.current) box.current.scrollTop = box.current.scrollHeight;
  }, [lines.length, follow]);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <input className="input min-w-[160px] flex-1" placeholder="grep the tail…" value={q} onChange={(e) => setQ(e.target.value)} />
        {(["error", "warn", "ok", "info", "sys"] as const).map((lv) => {
          const on = levels.includes(lv);
          return (
            <button
              key={lv}
              className="chip"
              onClick={() => setLevels((s) => (on ? s.filter((x) => x !== lv) : [...s, lv]))}
              style={{
                color: on ? "var(--bg)" : LEVEL_TONE[lv],
                background: on ? LEVEL_TONE[lv] : "var(--surface-2)",
                borderColor: "transparent",
              }}
            >
              {lv}
            </button>
          );
        })}
        <div className="ml-auto flex items-center gap-4">
          <Toggle on={follow} onChange={setFollow} labels={["follow", "paused"]} />
          <Toggle on={wrap} onChange={setWrap} labels={["wrap", "nowrap"]} />
        </div>
      </div>

      <Panel flat className="overflow-hidden">
        <div className="flex items-center justify-between px-3 py-2 hair-b">
          <span className="label-sm">
            logs/{p.id}.log · cap 2000 lines · rotate 5mb
          </span>
          <span className="mono text-[9px]" style={{ color: "var(--ink-3)" }}>
            {lines.length} shown / {l.logs.length} buffered
            {follow && <span style={{ color: "var(--up)" }}> · streaming</span>}
          </span>
        </div>
        <div ref={box} className="scroll max-h-[440px] overflow-y-auto px-3 py-2" style={{ background: "var(--surface)" }}>
          {lines.length === 0 && (
            <div className="mono py-6 text-center text-[11px]" style={{ color: "var(--ink-3)" }}>
              no lines match “{q}”
            </div>
          )}
          {lines.map((x, i) => (
            <div key={i} className="flex gap-3 py-[1px]">
              <span className="mono shrink-0 text-[10.5px] tnum" style={{ color: "var(--ink-3)" }}>
                {new Date(x.ts).toISOString().slice(11, 19)}
              </span>
              <span className="mono w-[38px] shrink-0 text-[10.5px] uppercase" style={{ color: LEVEL_TONE[x.level] }}>
                {x.level}
              </span>
              <span
                className="mono flex-1 text-[11px]"
                style={{ color: x.level === "error" ? "var(--down)" : x.level === "warn" ? "var(--warn)" : "var(--ink-2)", whiteSpace: wrap ? "pre-wrap" : "pre", wordBreak: "break-word" }}
              >
                {x.msg}
              </span>
            </div>
          ))}
          <div className="mono pt-1 text-[11px]" style={{ color: "var(--accent)" }}>
            ▍<span className="caret">_</span>
          </div>
        </div>
      </Panel>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <Panel className="p-3.5">
          <Label>secrets</Label>
          <p className="mono mt-2 text-[10.5px] leading-relaxed" style={{ color: "var(--ink-2)" }}>
            env values are masked at the pipe — <span className="mono">token=‹redacted›</span>. tokens never touch logs or the registry.
          </p>
        </Panel>
        <Panel className="p-3.5">
          <Label>stream</Label>
          <p className="mono mt-2 text-[10.5px] leading-relaxed" style={{ color: "var(--ink-2)" }}>
            <span className="mono">GET /api/logs/{p.id}/stream</span> — SSE tail-follow. phase 2.
          </p>
        </Panel>
        <Panel className="p-3.5">
          <Label>keyword retrieval</Label>
          <p className="mono mt-2 text-[10.5px] leading-relaxed" style={{ color: "var(--ink-2)" }}>
            phase 1 ships keyword log-retrieval so the AI helper can ground answers in evidence.
          </p>
        </Panel>
      </div>
    </div>
  );
}

/* ═════════════════════════ TERMINAL ═════════════════════════════ */

export function TerminalPanel({ p }: { p: Project }) {
  const w = useStore();
  const t = w.terminal[p.id] ?? { cwd: "—", mode: "safe" as const, lines: [] };
  const [cmd, setCmd] = useState("");
  const [history, setHistory] = useState<string[]>([]);
  const [hIdx, setHIdx] = useState(-1);
  const box = useRef<HTMLDivElement>(null);
  const local = p.location.type === "local";

  useEffect(() => {
    if (box.current) box.current.scrollTop = box.current.scrollHeight;
  }, [t.lines.length]);

  const run = () => {
    if (!cmd.trim()) return;
    setHistory((h) => [cmd, ...h]);
    setHIdx(-1);
    store.exec(p.id, cmd);
    setCmd("");
  };

  return (
    <div className="space-y-3">
      <Panel className="overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 hair-b">
          <div className="flex min-w-0 items-center gap-2">
            <span className="label-sm truncate">cwd jail · {t.cwd}</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="mono text-[9px]" style={{ color: t.mode === "admin" ? "var(--down)" : "var(--up)" }}>
              {t.mode === "admin" ? "ADMIN — free shell, audited" : "SAFE — allowlisted tools"}
            </span>
            <button
              className={cx("btn btn-sm", t.mode === "admin" && "btn-danger")}
              onClick={() => {
                if (t.mode === "safe" && !confirm("Grant ADMIN shell for this project?\n\nEvery command is written to audit.json. Free-form shell is RCE if done wrong — this is the explicit-grant path."))
                  return;
                store.setTerminalMode(p.id, t.mode === "safe" ? "admin" : "safe");
              }}
            >
              {t.mode === "safe" ? "escalate to admin" : "drop to safe"}
            </button>
          </div>
        </div>

        <div ref={box} className="scroll max-h-[380px] min-h-[240px] overflow-y-auto px-3 py-3" style={{ background: "var(--surface)" }}>
          {t.lines.map((x, i) => {
            const isCmd = x.startsWith("›");
            const denied = x.includes("403 FORBIDDEN");
            return (
              <div
                key={i}
                className="code"
                style={{ color: isCmd ? "var(--accent)" : denied ? "var(--down)" : x.startsWith("⚠") ? "var(--warn)" : x.startsWith("✓") ? "var(--up)" : "var(--ink-2)" }}
              >
                {x}
              </div>
            );
          })}
          <div className="code" style={{ color: "var(--ink)" }}>
            <span style={{ color: "var(--up)" }}>{p.id}</span>
            <span style={{ color: "var(--ink-3)" }}> ~/{p.id} ❯ </span>
            {cmd}
            <span className="caret" style={{ color: "var(--accent)" }}>
              ▍
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 px-3 py-2.5 hair-t">
          <span className="mono text-[11px]" style={{ color: "var(--up)" }}>
            ❯
          </span>
          <input
            className="mono flex-1 bg-transparent text-[11.5px] outline-none"
            style={{ color: "var(--ink)", border: 0, height: 22 }}
            placeholder={local ? "git log --oneline -5  ·  npm test  ·  df -h" : "external project — no local cwd"}
            value={cmd}
            disabled={!local}
            onChange={(e) => setCmd(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") run();
              if (e.key === "ArrowUp") {
                e.preventDefault();
                const n = Math.min(history.length - 1, hIdx + 1);
                if (history[n] !== undefined) {
                  setHIdx(n);
                  setCmd(history[n]);
                }
              }
              if (e.key === "ArrowDown") {
                e.preventDefault();
                const n = hIdx - 1;
                setHIdx(n);
                setCmd(n >= 0 ? history[n] ?? "" : "");
              }
            }}
          />
          <button className="btn btn-sm btn-accent" onClick={run} disabled={!local || !cmd.trim()}>
            exec
          </button>
        </div>
      </Panel>

      <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
        <Panel className="p-3.5 lg:col-span-2">
          <SectionLabel>safe-mode allowlist</SectionLabel>
          <div className="flex flex-wrap gap-1.5">
            {ALLOWLIST.map((c) => (
              <button
                key={c}
                className="chip"
                style={{ cursor: "pointer" }}
                onClick={() => setCmd(c + " ")}
              >
                {c}
              </button>
            ))}
          </div>
          <p className="mono mt-3 text-[10.5px] leading-relaxed" style={{ color: "var(--ink-3)" }}>
            spawned as <span className="mono" style={{ color: "var(--ink-2)" }}>spawn(cmd, args, {"{ cwd, shell: false }"})</span> — no
            <span className="mono"> bash -c "user;injection"</span>. chaining (<span className="mono">;</span>,<span className="mono">&amp;&amp;</span>,<span className="mono">|</span>) is
            rejected before spawn and logged as <span className="mono" style={{ color: "var(--down)" }}>denied</span>.
          </p>
        </Panel>
        <Panel className="p-3.5">
          <SectionLabel>guardrails</SectionLabel>
          <div className="space-y-1.5">
            {[
              ["timeout", "30s hard"],
              ["output cap", "100kb"],
              ["cwd", "project root only"],
              ["audit", "every call → audit.json"],
              ["destructive", "requires confirm"],
            ].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between gap-2">
                <span className="label">{k}</span>
                <span className="mono text-[10px]" style={{ color: "var(--ink-2)" }}>
                  {v}
                </span>
              </div>
            ))}
          </div>
          <div className="mt-3 flex justify-end">
            <button className="btn btn-sm btn-ghost" onClick={() => store.clearTerminal(p.id)}>
              clear buffer
            </button>
          </div>
        </Panel>
      </div>
    </div>
  );
}

/* ═════════════════════════════ AI ═══════════════════════════════ */

const SUGGESTED = [
  "why is this down?",
  "why did latency spike?",
  "what changed in the last deploy?",
  "is this safe to restart?",
];

export function AiPanel({ p }: { p: Project }) {
  const w = useStore();
  const a = w.ai[p.id] ?? { busy: false, q: "" };
  const [q, setQ] = useState("why is this down?");
  const [confirmTool, setConfirmTool] = useState<string | null>(null);
  const l = w.live[p.id];
  const sevTone = (s?: string) =>
    s === "critical" ? "var(--down)" : s === "high" ? "var(--down)" : s === "medium" ? "var(--warn)" : "var(--up)";

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-3 gap-0 hair hair-y">
        {[
          { n: "01", k: "explain", d: "read-only analysis of status + logs" },
          { n: "02", k: "propose", d: "a plan, waiting for approval" },
          { n: "03", k: "execute", d: "tool calls only, logged, reversible" },
        ].map((s, i) => (
          <div key={s.k} className="px-3.5 py-3" style={{ borderRight: i < 2 ? `var(--bw) solid var(--line)` : undefined }}>
            <div className="flex items-center gap-2">
              <span className="mono text-[9.5px]" style={{ color: "var(--accent)" }}>
                {s.n}
              </span>
              <span className="display text-[13px] capitalize">{s.k}</span>
            </div>
            <div className="mono mt-1.5 text-[9.5px] leading-snug" style={{ color: "var(--ink-3)" }}>
              {s.d}
            </div>
          </div>
        ))}
      </div>

      <Panel className="p-4">
        <div className="flex flex-col gap-2 sm:flex-row">
          <input
            className="input flex-1"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && store.ask(p.id, q)}
            placeholder="ask about status, logs, or the last deploy…"
          />
          <button className="btn btn-accent" onClick={() => store.ask(p.id, q)} disabled={a.busy}>
            {a.busy ? "diagnosing…" : "POST /api/ai/" + p.id + "/ask"}
          </button>
        </div>
        <div className="mt-2.5 flex flex-wrap gap-1.5">
          {SUGGESTED.map((s) => (
            <button key={s} className="chip" style={{ cursor: "pointer" }} onClick={() => setQ(s)}>
              {s}
            </button>
          ))}
        </div>
        <div className="mono mt-3 text-[9.5px] leading-relaxed" style={{ color: "var(--ink-3)" }}>
          context gathered server-side: get_status · get_logs(100) · package.json · last incident — the model never receives raw shell.
        </div>
      </Panel>

      {a.busy && (
        <Panel className="p-4">
          <div className="space-y-2">
            {["reading status + 100 log lines", "correlating with last incident", "checking deploy #15 rollback", "composing structured diagnosis"].map((s, i) => (
              <div key={s} className="flex items-center gap-2.5" style={{ opacity: 1 - i * 0.18 }}>
                <span className="breathe" style={{ width: 5, height: 5, background: "var(--accent)", borderRadius: 99 }} />
                <span className="mono text-[10.5px]" style={{ color: "var(--ink-2)" }}>
                  {s}
                </span>
              </div>
            ))}
          </div>
        </Panel>
      )}

      {a.d && (
        <Panel className="rise overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 hair-b" style={{ background: "var(--surface-2)" }}>
            <div className="flex items-center gap-2.5">
              <span className="chip" style={{ color: sevTone(a.d.severity), borderColor: sevTone(a.d.severity) }}>
                severity {a.d.severity}
              </span>
              <span className="mono text-[10px]" style={{ color: "var(--ink-3)" }}>
                {a.d.model}
              </span>
            </div>
            <div className="flex items-center gap-2.5">
              <span className="label">confidence</span>
              <div className="h-[5px] w-[90px]" style={{ background: "var(--surface-3)" }}>
                <div style={{ width: `${a.d.confidence * 100}%`, height: "100%", background: "var(--accent)" }} />
              </div>
              <span className="mono tnum text-[11px]">{Math.round(a.d.confidence * 100)}%</span>
            </div>
          </div>

          <div className="space-y-5 p-4">
            <div>
              <Label>likely cause</Label>
              <p className="serif mt-2 text-[17px] leading-snug">{a.d.likelyCause}</p>
              <p className="mono mt-2 text-[10.5px]" style={{ color: "var(--ink-3)" }}>
                {a.d.summary}
              </p>
            </div>

            <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
              <div>
                <SectionLabel>evidence ({a.d.evidence.length})</SectionLabel>
                <ul className="space-y-2">
                  {a.d.evidence.map((e, i) => (
                    <li key={i} className="flex gap-2.5">
                      <span className="mono mt-[3px] text-[9px]" style={{ color: "var(--ink-3)" }}>
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      <span className="mono text-[10.5px] leading-relaxed" style={{ color: "var(--ink-2)" }}>
                        {e}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <SectionLabel>recommended actions</SectionLabel>
                <ol className="space-y-2">
                  {a.d.recommendedActions.map((r, i) => (
                    <li key={i} className="flex gap-2.5">
                      <span className="mono mt-[2px] text-[10px]" style={{ color: "var(--accent)" }}>
                        ▸
                      </span>
                      <span className="text-[11.5px] leading-relaxed" style={{ color: "var(--ink)" }}>
                        {r}
                      </span>
                    </li>
                  ))}
                </ol>
                <div className="mt-4 space-y-1.5">
                  {a.d.commands.map((c) => (
                    <div key={c} className="flex items-center justify-between gap-2 panel-inset px-2.5 py-1.5">
                      <span className="mono truncate text-[10.5px]">{c}</span>
                      <button
                        className="btn btn-sm btn-ghost"
                        onClick={() => {
                          store.exec(p.id, c);
                          store.toast("command ran in the terminal buffer — open the Terminal tab", "info");
                        }}
                      >
                        run
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="hair-t pt-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <span className="label">step 03 · execute</span>
                  <Tag tone={a.d.safeToAutoFix ? "up" : "warn"}>
                    {a.d.safeToAutoFix ? "safe to auto-fix · reversible" : "not safe to auto-fix · operator only"}
                  </Tag>
                </div>
                <span className="mono text-[9px]" style={{ color: "var(--ink-3)" }}>
                  mutating tools require a confirm token + audit entry
                </span>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                {[
                  { tool: "restart_project", label: "restart_project()" },
                  { tool: "run_safe_command", label: "run_safe_command()" },
                  { tool: "deploy_project", label: "deploy_project()" },
                ].map((t) => (
                  <div key={t.tool} className="flex items-center">
                    <button
                      className={cx("btn btn-sm", confirmTool === t.tool ? "btn-danger" : "")}
                      onClick={() => setConfirmTool(confirmTool === t.tool ? null : t.tool)}
                    >
                      {t.label}
                    </button>
                    {confirmTool === t.tool && (
                      <button
                        className="btn btn-sm btn-danger slide-in"
                        style={{ marginLeft: -1 }}
                        onClick={() => {
                          store.executeTool(p.id, t.tool);
                          setConfirmTool(null);
                        }}
                      >
                        confirm →
                      </button>
                    )}
                  </div>
                ))}
                <span className="mono self-center text-[9.5px]" style={{ color: "var(--ink-3)" }}>
                  status now: {l?.status} · restarts {l?.restarts}
                </span>
              </div>
            </div>
          </div>
        </Panel>
      )}
    </div>
  );
}

/* ═════════════════════════ DEPLOY ══════════════════════════════ */

const STAGE_MARK: Record<string, string> = { pending: "·", running: "◐", ok: "✓", fail: "✕", skip: "—" };

export function DeployPanel({ p }: { p: Project }) {
  const w = useStore();
  const [sha, setSha] = useState("latest");
  const [open, setOpen] = useState<number | null>(null);
  const pipe = w.pipeline?.projectId === p.id ? w.pipeline : null;
  const list = w.deployments.filter((d) => d.projectId === p.id);
  const local = p.location.type === "local";

  return (
    <div className="space-y-3">
      {local ? (
        <Panel className="p-4">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div className="min-w-0">
              <Label>deploy pipeline · local git</Label>
              <p className="mono mt-2 text-[10.5px]" style={{ color: "var(--ink-2)" }}>
                snapshot → fetch → checkout → install → build → pre-hook → restart → health gate (3× OK) → post-hook. gate fail ⇒ rollback to the previous sha.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <input className="input w-[190px]" value={sha} onChange={(e) => setSha(e.target.value)} placeholder="latest | <sha>" />
              <button className="btn btn-primary" onClick={() => store.deploy(p.id, sha)} disabled={!!w.pipeline || w.readOnly}>
                {pipe ? "deploying…" : "POST /api/deploy/" + p.id}
              </button>
            </div>
          </div>

          {pipe && (
            <div className="mt-4">
              <div className="grid grid-cols-2 gap-0 sm:grid-cols-3 lg:grid-cols-5">
                {pipe.stages.map((s, i) => (
                  <div
                    key={s.key}
                    className="px-2.5 py-2"
                    style={{
                      borderRight: (i + 1) % 5 !== 0 ? `var(--bw) solid var(--line)` : undefined,
                      borderTop: `var(--bw) solid var(--line)`,
                      opacity: s.status === "pending" ? 0.42 : 1,
                    }}
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className="mono text-[11px]"
                        style={{ color: s.status === "ok" ? "var(--up)" : s.status === "fail" ? "var(--down)" : s.status === "running" ? "var(--accent)" : "var(--ink-3)" }}
                      >
                        {s.status === "running" ? <span className="breathe">◐</span> : STAGE_MARK[s.status]}
                      </span>
                      <span className="mono truncate text-[10px]" style={{ color: "var(--ink-2)" }}>
                        {s.label}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-3 panel-inset scroll max-h-[180px] overflow-y-auto px-3 py-2">
                {pipe.log.map((x, i) => (
                  <div key={i} className="code" style={{ color: x.includes("FAIL") ? "var(--down)" : x.includes("PASSED") ? "var(--up)" : "var(--ink-2)" }}>
                    {x}
                  </div>
                ))}
                <div className="code" style={{ color: "var(--accent)" }}>
                  ▍<span className="caret">_</span>
                </div>
              </div>
            </div>
          )}
        </Panel>
      ) : (
        <Panel className="p-4">
          <Label>provider-managed deployment</Label>
          <p className="mono mt-2 text-[10.5px]" style={{ color: "var(--ink-2)" }}>
            location.type = external → we never fake local control. deep-link to {p.location.provider} and trigger there; v1 only pings the URL.
          </p>
          <a className="btn mt-3" style={{ borderColor: "var(--accent)", color: "var(--accent)" }} href={p.runtime.healthUrl} target="_blank" rel="noreferrer">
            open {p.location.provider} dashboard ↗
          </a>
        </Panel>
      )}

      <Panel flat className="overflow-hidden">
        <div className="flex items-center justify-between px-4 py-2.5 hair-b">
          <span className="label">deployment record</span>
          <span className="mono text-[9px]" style={{ color: "var(--ink-3)" }}>
            {list.length} deployments · storage/deployments.json
          </span>
        </div>
        <div className="divide-y" style={{ borderColor: "var(--line)" }}>
          {list.length === 0 && (
            <div className="mono px-4 py-8 text-center text-[11px]" style={{ color: "var(--ink-3)" }}>
              no deployments recorded
            </div>
          )}
          {list.map((d: Deployment) => (
            <div key={d.id}>
              <button className="flex w-full items-center gap-3 px-4 py-2.5 text-left" onClick={() => setOpen(open === d.id ? null : d.id)}>
                <span className="mono w-[38px] shrink-0 text-[11px]" style={{ color: "var(--ink-3)" }}>
                  #{d.id}
                </span>
                <span className="mono w-[62px] shrink-0 text-[11px]" style={{ color: "var(--ink)" }}>
                  {d.sha.slice(0, 7)}
                </span>
                <span className="mono hidden w-[54px] shrink-0 text-[10.5px] sm:block" style={{ color: "var(--ink-3)" }}>
                  {d.branch}
                </span>
                <span
                  className="mono w-[86px] shrink-0 text-[10px] uppercase"
                  style={{ color: d.status === "success" ? "var(--up)" : d.status === "running" ? "var(--accent)" : "var(--down)" }}
                >
                  {d.status}
                </span>
                <span className="mono hidden flex-1 text-[10.5px] md:block" style={{ color: "var(--ink-3)" }}>
                  {d.triggeredBy}
                </span>
                <span className="mono tnum shrink-0 text-[10.5px]" style={{ color: "var(--ink-2)" }}>
                  {ago(d.startedAt, w.clock)} ago · {dur(Math.round((d.durationMs || (d.endedAt ? d.endedAt - d.startedAt : 0)) / 1000))}
                </span>
                <span className="mono shrink-0 text-[10px]" style={{ color: "var(--ink-3)" }}>
                  {open === d.id ? "–" : "+"}
                </span>
              </button>
              {open === d.id && (
                <div className="px-4 pb-3">
                  <div className="panel-inset px-3 py-2">
                    {d.buildTail.map((x, i) => (
                      <div key={i} className="code" style={{ color: x.includes("FAIL") ? "var(--down)" : x.includes("PASSED") ? "var(--up)" : "var(--ink-2)" }}>
                        {x}
                      </div>
                    ))}
                  </div>
                  <div className="mt-2 flex flex-wrap gap-2">
                    <button className="btn btn-sm" onClick={() => store.deploy(p.id, d.sha)} disabled={!!w.pipeline}>
                      redeploy this sha
                    </button>
                    <button
                      className="btn btn-sm"
                      onClick={() => {
                        store.toast(`rollback → POST /api/deploy/${p.id}/rollback { toDeploymentId: ${d.id} }`, "warn");
                      }}
                    >
                      rollback to #{d.id}
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}

/* ═════════════════════ INCIDENTS (project) ═════════════════════ */

export function IncidentCard({ i, compact = false }: { i: Incident; compact?: boolean }) {
  const w = useStore();
  const [note, setNote] = useState("");
  const p = w.projects.find((x) => x.id === i.projectId);
  return (
    <Panel className="overflow-hidden" style={{ borderColor: i.state === "resolved" ? undefined : i.severity === "sev1" ? "var(--down)" : "var(--warn)" }}>
      <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 hair-b" style={{ background: "var(--surface-2)" }}>
        <div className="flex flex-wrap items-center gap-2">
          <span className="mono text-[11px]" style={{ color: "var(--ink)" }}>
            {i.id}
          </span>
          <Tag tone={i.severity === "sev1" ? "down" : "warn"}>{i.severity}</Tag>
          <Tag tone={i.state === "resolved" ? "up" : i.state === "ack" ? "accent" : "down"}>{i.state}</Tag>
          {!compact && p && <span className="mono text-[10px]" style={{ color: "var(--ink-3)" }}>{p.id}</span>}
        </div>
        <span className="mono tnum text-[10px]" style={{ color: "var(--ink-3)" }}>
          started {ago(i.startedAt, w.clock)} ago{compact ? "" : ` · ${i.recoveryAttempts} recovery attempts`}
        </span>
      </div>
      <div className="p-4">
        <p className="text-[12.5px] leading-relaxed">{i.cause}</p>
        <div className="mt-4 space-y-2 hair-l pl-3" style={{ borderColor: "var(--line-2)" }}>
          {i.timeline.map((t, k) => (
            <div key={k} className="flex gap-2.5">
              <span className="mono tnum shrink-0 text-[9.5px]" style={{ color: "var(--ink-3)" }}>
                {new Date(t.ts).toISOString().slice(11, 16)}
              </span>
              <span className="mono text-[10.5px] leading-relaxed" style={{ color: "var(--ink-2)" }}>
                {t.text}
              </span>
            </div>
          ))}
        </div>
        {i.note && (
          <div className="mt-3 panel-inset px-3 py-2">
            <span className="label">operator note</span>
            <p className="mono mt-1.5 text-[10.5px]">{i.note}</p>
          </div>
        )}
        {i.state !== "resolved" && (
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <input className="input flex-1" placeholder="note (optional)…" value={note} onChange={(e) => setNote(e.target.value)} />
            <button className="btn btn-sm" onClick={() => store.ackIncident(i.id, note || undefined)} disabled={i.state === "ack"}>
              {i.state === "ack" ? `ack by ${i.acknowledgedBy}` : "ack"}
            </button>
            <button className="btn btn-sm btn-primary" onClick={() => store.resolveIncident(i.id, note || undefined)}>
              resolve
            </button>
          </div>
        )}
      </div>
    </Panel>
  );
}

/* ═════════════════ overview tab ═════════════════ */

export function ProjectOverviewTab({ p, go }: { p: Project; go: (v: { view: string; id?: string; tab?: string }) => void }) {
  const w = useStore();
  const l = w.live[p.id];
  const lat = l.history.filter((c) => c.latencyMs).map((c) => c.latencyMs!).sort((a, b) => a - b);
  const p50 = lat.length ? lat[Math.floor(lat.length / 2)] : 0;
  const p95 = lat.length ? lat[Math.floor(lat.length * 0.95)] : 0;
  const p99 = lat.length ? lat[Math.floor(lat.length * 0.99)] : 0;
  const open = w.incidents.find((i) => i.projectId === p.id && i.state !== "resolved");
  const lastDep = w.deployments.find((d) => d.projectId === p.id);

  return (
    <div className="space-y-3">
      <Panel className="p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <Label>latency · {l.history.length} checks retained (30s interval)</Label>
          <div className="flex items-center gap-4">
            {[
              ["p50", p50],
              ["p95", p95],
              ["p99", p99],
            ].map(([k, v]) => (
              <span key={k as string} className="mono text-[10px]" style={{ color: "var(--ink-3)" }}>
                {k as string} <span className="tnum" style={{ color: "var(--ink)" }}>{v as number}ms</span>
              </span>
            ))}
          </div>
        </div>
        <div className="mt-3">
          <Sparkline checks={l.history} height={72} tone={l.status === "UP" ? "var(--up)" : "var(--warn)"} />
        </div>
        <div className="mt-2 flex justify-between">
          <span className="mono text-[9px]" style={{ color: "var(--ink-3)" }}>
            {new Date(l.history[0]?.ts ?? Date.now()).toISOString().slice(11, 19)}
          </span>
          <span className="mono text-[9px]" style={{ color: "var(--ink-3)" }}>
            now
          </span>
        </div>
        <div className="mt-3">
          <Bars checks={l.history} height={26} />
        </div>
      </Panel>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {(["1h", "24h", "7d", "30d"] as const).map((r) => (
          <Panel key={r} className="p-3.5">
            <Label>uptime {r}</Label>
            <div className="display tnum mt-2 text-[22px] leading-none" style={{ color: l.uptime[r] > 99 ? "var(--up)" : l.uptime[r] > 95 ? "var(--warn)" : "var(--down)" }}>
              {pct(l.uptime[r])}
            </div>
            <div className="mono mt-2 text-[9px]" style={{ color: "var(--ink-3)" }}>
              {r === "1h" ? `${l.history.length} checks` : `p95 ${p95}ms`}
            </div>
          </Panel>
        ))}
      </div>

      {open && <IncidentCard i={open} compact />}

      <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
        <Panel className="p-4">
          <div className="flex items-center justify-between">
            <Label>log tail</Label>
            <button className="btn btn-sm btn-ghost" onClick={() => go({ view: "project", id: p.id, tab: "logs" })}>
              open viewer →
            </button>
          </div>
          <div className="mt-3 space-y-1">
            {l.logs.slice(-7).map((x, i) => (
              <div key={i} className="flex gap-2.5">
                <span className="mono shrink-0 text-[9.5px] tnum" style={{ color: "var(--ink-3)" }}>
                  {new Date(x.ts).toISOString().slice(11, 19)}
                </span>
                <span className="mono truncate text-[10.5px]" style={{ color: x.level === "error" ? "var(--down)" : x.level === "warn" ? "var(--warn)" : "var(--ink-2)" }}>
                  {x.msg}
                </span>
              </div>
            ))}
          </div>
        </Panel>

        <Panel className="p-4">
          <div className="flex items-center justify-between">
            <Label>last deployment</Label>
            {lastDep && (
              <button className="btn btn-sm btn-ghost" onClick={() => go({ view: "project", id: p.id, tab: "deploy" })}>
                full build log →
              </button>
            )}
          </div>
          {lastDep ? (
            <div className="mt-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="mono text-[13px]">#{lastDep.id}</span>
                <span className="mono text-[11px]" style={{ color: "var(--ink-2)" }}>
                  @ {lastDep.sha.slice(0, 7)}
                </span>
                <StatusBadge status={lastDep.status === "success" ? "UP" : lastDep.status === "running" ? "STARTING" : "DOWN"} />
                <span className="mono text-[10px]" style={{ color: "var(--ink-3)" }}>
                  {ago(lastDep.startedAt, w.clock)} ago
                </span>
              </div>
              <div className="mt-3 panel-inset px-3 py-2">
                {lastDep.buildTail.slice(0, 5).map((x, i) => (
                  <div key={i} className="code" style={{ color: "var(--ink-2)" }}>
                    {x}
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="mono mt-4 text-[11px]" style={{ color: "var(--ink-3)" }}>
              never deployed from this dashboard
            </div>
          )}
        </Panel>
      </div>
    </div>
  );
}
