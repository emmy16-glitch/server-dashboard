import { useState } from "react";
import { store, useStore } from "../lib/store";
import type { Project } from "../lib/types";
import { ago, dur, shortSha } from "../lib/types";
import { KV, Panel, SectionLabel, StatusBadge, StatusDot, Tag, cx } from "../components/ui";
import type { Route } from "../components/Shell";
import { AiPanel, DeployPanel, IncidentCard, LogsPanel, ProjectOverviewTab, TerminalPanel } from "./panels";

const TABS = [
  { key: "overview", label: "Overview" },
  { key: "logs", label: "Logs" },
  { key: "deploy", label: "Deployments" },
  { key: "incidents", label: "Incidents" },
  { key: "terminal", label: "Terminal" },
  { key: "ai", label: "AI helper" },
];

export function ProjectView({ p, tab, go }: { p: Project; tab: string; go: (r: Route) => void }) {
  const w = useStore();
  const l = w.live[p.id];
  const [menu, setMenu] = useState(false);
  if (!l) return null;
  const local = p.location.type === "local";
  const incidents = w.incidents.filter((i) => i.projectId === p.id);
  const active = TABS.some((t) => t.key === tab) ? tab : "overview";

  return (
    <div className="pb-4">
      {/* breadcrumb */}
      <div className="flex items-center gap-2 pb-4">
        <button className="btn btn-sm btn-ghost" onClick={() => go({ view: "overview" })}>
          ← fleet
        </button>
        <span className="mono text-[10px]" style={{ color: "var(--ink-3)" }}>
          /
        </span>
        <span className="mono text-[10.5px]" style={{ color: "var(--ink-2)" }}>
          {p.id}
        </span>
        <span className="mono text-[10px]" style={{ color: "var(--ink-3)" }}>
          /
        </span>
        <span className="mono text-[10.5px]">{active}</span>
        <span className="ml-auto label-sm">
          {w.readOnly ? "read-only share link" : "operator session · bearer token"}
        </span>
      </div>

      {/* masthead */}
      <Panel className="overflow-hidden">
        <div className="flex flex-col gap-5 p-5 lg:flex-row lg:items-start lg:justify-between">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-3">
              <StatusDot status={l.status} lg />
              <h1 className="display text-[26px] leading-none sm:text-[30px]">{p.name}</h1>
              <StatusBadge status={l.status} />
              {p.tags?.map((t) => (
                <Tag key={t}>{t}</Tag>
              ))}
            </div>
            <div className="mono mt-3 space-y-1 text-[10.5px]" style={{ color: "var(--ink-3)" }}>
              <div>
                <span style={{ color: "var(--ink-2)" }}>{p.id}</span> · {local ? p.location.cwd : `${p.location.provider} · ${p.runtime.healthUrl}`}
              </div>
              <div>
                {local ? `:${p.runtime.port} · ${p.runtime.command} ${(p.runtime.args ?? []).join(" ")}` : `external · health-only · no local control`}
                {p.source && (
                  <>
                    {" · "}
                    {p.source.repository}@{p.source.branch} · {shortSha(l.sha)}
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="flex flex-col items-start gap-3 lg:items-end">
            <div className="flex flex-wrap items-center gap-2">
              {local ? (
                <>
                  <button className="btn btn-sm btn-primary" onClick={() => store.start(p.id)} disabled={l.status !== "STOPPED" || w.readOnly}>
                    ▶ start
                  </button>
                  <button className="btn btn-sm" onClick={() => store.stop(p.id)} disabled={l.status === "STOPPED" || w.readOnly}>
                    ■ stop
                  </button>
                  <button className="btn btn-sm" onClick={() => store.restart(p.id)} disabled={w.readOnly}>
                    ↻ restart
                  </button>
                  <button className="btn btn-sm btn-accent" onClick={() => go({ view: "project", id: p.id, tab: "deploy" })}>
                    ↑ deploy
                  </button>
                </>
              ) : (
                <a className="btn btn-sm btn-accent" href={p.runtime.healthUrl} target="_blank" rel="noreferrer">
                  open {p.location.provider} ↗
                </a>
              )}
              <div className="relative">
                <button className="btn btn-sm" onClick={() => setMenu(!menu)}>
                  ⋯
                </button>
                {menu && (
                  <div className="panel slide-in absolute right-0 z-30 mt-1 w-[210px] p-1.5">
                    <button
                      className="btn btn-sm btn-ghost w-full justify-start"
                      onClick={() => {
                        navigator.clipboard?.writeText(p.runtime.healthUrl);
                        store.toast("healthUrl copied", "ok");
                        setMenu(false);
                      }}
                    >
                      copy healthUrl
                    </button>
                    <button
                      className="btn btn-sm btn-ghost w-full justify-start"
                      onClick={() => {
                        store.toggleProject(p.id);
                        setMenu(false);
                      }}
                    >
                      {p.enabled ? "disable monitoring" : "enable monitoring"}
                    </button>
                    <button
                      className="btn btn-sm btn-ghost w-full justify-start"
                      style={{ color: "var(--down)" }}
                      onClick={() => {
                        if (!confirm(`DELETE ${p.id}?\n\nStops the process first, then removes it from projects.json.`)) return;
                        store.removeProject(p.id);
                        go({ view: "overview" });
                      }}
                    >
                      delete from registry
                    </button>
                  </div>
                )}
              </div>
            </div>
            <div className="mono text-right text-[10px] leading-relaxed" style={{ color: "var(--ink-3)" }}>
              <div>
                checked {ago(l.checkedAt, w.clock)} ago · code <span style={{ color: l.code === 200 ? "var(--up)" : "var(--warn)" }}>{l.code ?? "—"}</span>
              </div>
              <div>
                {local ? `pid ${l.pid ?? "—"} · up ${dur(l.uptimeSec)} · restarts ${l.restarts}` : "no process — we only ping the url"}
              </div>
            </div>
          </div>
        </div>

        {/* tabs */}
        <div className="flex items-center gap-5 overflow-x-auto px-5 no-bar hair-t">
          {TABS.map((t) => (
            <button key={t.key} className="tab" data-on={active === t.key} onClick={() => go({ view: "project", id: p.id, tab: t.key })}>
              {t.label}
              {t.key === "incidents" && incidents.some((i) => i.state !== "resolved") && (
                <span className="ml-1.5 inline-block h-[5px] w-[5px] rounded-full align-middle" style={{ background: "var(--down)" }} />
              )}
            </button>
          ))}
        </div>
      </Panel>

      {/* body */}
      <div className="mt-3 grid grid-cols-12 gap-3">
        <div className="col-span-12 xl:col-span-8">
          {active === "overview" && <ProjectOverviewTab p={p} go={(x) => go(x as Route)} />}
          {active === "logs" && <LogsPanel p={p} />}
          {active === "deploy" && <DeployPanel p={p} />}
          {active === "terminal" && <TerminalPanel p={p} />}
          {active === "ai" && <AiPanel p={p} />}
          {active === "incidents" && (
            <div className="space-y-3">
              {incidents.length === 0 ? (
                <Panel className="p-10 text-center">
                  <div className="serif text-[20px]">No incidents on record.</div>
                  <p className="mono mt-2 text-[10.5px]" style={{ color: "var(--ink-3)" }}>
                    failed checks open an incident, dedupe on repeat, auto-resolve on 3 consecutive OK checks
                  </p>
                </Panel>
              ) : (
                incidents.map((i) => <IncidentCard key={i.id} i={i} />)
              )}
            </div>
          )}
        </div>

        {/* config rail */}
        <aside className="col-span-12 space-y-3 xl:col-span-4">
          {local && (
            <Panel className="p-4">
              <SectionLabel>process · /proc</SectionLabel>
              <div className="space-y-0">
                <KV k="pid" v={l.pid ?? "not running"} tone={l.pid ? "var(--ink)" : "var(--down)"} />
                <KV k="process uptime" v={l.pid ? dur(l.uptimeSec) : "—"} />
                <KV k="cpu" v={l.pid ? `${l.cpuPct.toFixed(1)}%` : "—"} />
                <KV k="memory" v={l.pid ? `${l.memMB.toFixed(1)} mb` : "—"} />
                <KV k="restarts" v={l.restarts} tone={l.restarts > 3 ? "var(--down)" : undefined} />
                <KV k="restart attempts" v={`${l.restartAttempt}/${p.runtime.maxRestarts ?? 3}`} />
              </div>
              <div className="mt-3 grid grid-cols-3 gap-2">
                {[
                  ["cpu", l.cpuPct],
                  ["mem", (l.memMB / 512) * 100],
                  ["restart", (l.restarts / (p.runtime.maxRestarts ?? 3)) * 100],
                ].map(([k, v]) => (
                  <div key={k as string}>
                    <div className="label mb-1">{k as string}</div>
                    <div className="h-[4px] w-full" style={{ background: "var(--surface-3)" }}>
                      <div style={{ width: `${Math.min(100, v as number)}%`, height: "100%", background: "var(--accent)" }} />
                    </div>
                  </div>
                ))}
              </div>
            </Panel>
          )}

          <Panel className="p-4">
            <SectionLabel>runtime</SectionLabel>
            <KV k="type" v={p.location.type} tone="var(--accent)" />
            {local ? (
              <>
                <KV k="command" v={`${p.runtime.command} ${(p.runtime.args ?? []).join(" ")}`} />
                <KV k="port" v={p.runtime.port ?? "—"} />
                <KV k="env file" v={p.runtime.envFile ?? "none"} />
                <KV k="auto restart" v={String(!!p.runtime.autoRestart)} tone={p.runtime.autoRestart ? "var(--up)" : "var(--ink-3)"} />
                <KV k="max restarts" v={p.runtime.maxRestarts ?? "—"} />
                <KV k="cooldown" v={`${p.runtime.restartCooldownSec ?? 0}s`} />
                <KV k="start on boot" v={String(!!p.runtime.startOnBoot)} />
                <KV k="startup timeout" v={`${p.runtime.startupTimeoutSec ?? 20}s`} />
              </>
            ) : (
              <>
                <KV k="provider" v={p.location.provider ?? "other"} />
                <KV k="control" v="link-out only" tone="var(--warn)" />
                <KV k="health url" v={p.runtime.healthUrl.replace(/^https?:\/\//, "")} />
              </>
            )}
          </Panel>

          <Panel className="p-4">
            <SectionLabel>monitoring</SectionLabel>
            <KV k="health url" v={p.runtime.healthUrl.replace(/^https?:\/\/[^/]+/, "") || "/"} />
            <KV k="interval" v={`${p.monitoring.intervalSeconds}s`} />
            <KV k="timeout" v={`${p.monitoring.timeoutSeconds}s`} />
            <KV k="expected status" v={p.monitoring.expectedStatus.join(" · ")} />
            {p.monitoring.healthConfig?.json && (
              <KV k="expected body" v={JSON.stringify(p.monitoring.healthConfig.json)} />
            )}
            <div className="mono mt-2 text-[9.5px] leading-relaxed" style={{ color: "var(--ink-3)" }}>
              v1 treats 404/500 as DEGRADED and keeps them for AI context. next checks: tcp port, pid alive, ssl expiry, disk/mem pressure.
            </div>
          </Panel>

          {p.source && (
            <Panel className="p-4">
              <SectionLabel>source</SectionLabel>
              <KV k="provider" v={p.source.provider} />
              <KV k="repository" v={p.source.repository} />
              <KV k="branch" v={p.source.branch} />
              <KV k="deploy on push" v={String(!!p.source.deployOnPush)} />
              <KV k="current sha" v={shortSha(l.sha)} />
            </Panel>
          )}

          <Panel className="p-4">
            <SectionLabel>notifications</SectionLabel>
            <div className="space-y-2">
              {[
                ["down", p.notifications.down],
                ["recovered", p.notifications.recovered],
                ["deployment failed", !!p.notifications.deploymentFailed],
                ["crash loop", !!p.notifications.crashLoop],
              ].map(([k, v]) => (
                <div key={k as string} className="flex items-center justify-between">
                  <span className="label">{k as string}</span>
                  <span className="mono text-[10px]" style={{ color: v ? "var(--up)" : "var(--ink-3)" }}>
                    {v ? "on" : "off"}
                  </span>
                </div>
              ))}
            </div>
            <div className="mono mt-3 text-[9.5px] leading-relaxed" style={{ color: "var(--ink-3)" }}>
              alert order: telegram → discord → email → webhook → slack. rules, not hardcodes: “telegram me if DOWN &gt; 60s”.
            </div>
          </Panel>

          <Panel className="p-4">
            <SectionLabel>template</SectionLabel>
            <div className="flex items-center gap-2">
              <Tag tone="accent">{p.template}</Tag>
              <span className="mono text-[10px]" style={{ color: "var(--ink-3)" }}>
                detect · install · build · start · healthPath
              </span>
            </div>
            <p className="mono mt-2.5 text-[9.5px] leading-relaxed" style={{ color: "var(--ink-3)" }}>
              phase 3 — 17 app/dev templates plus autodetect from package.json. v1 already stores runtime + source so templates slot in.
            </p>
          </Panel>
        </aside>
      </div>
    </div>
  );
}

export function ProjectNotFound({ go }: { go: (r: Route) => void }) {
  return (
    <Panel className={cx("p-12 text-center")}>
      <div className="serif text-[24px]">That id isn’t in the registry.</div>
      <p className="mono mt-2 text-[11px]" style={{ color: "var(--ink-3)" }}>
        ids are stable slugs — if it isn’t in projects.json, it isn’t monitored.
      </p>
      <button className="btn mt-4" onClick={() => go({ view: "overview" })}>
        ← back to fleet
      </button>
    </Panel>
  );
}
