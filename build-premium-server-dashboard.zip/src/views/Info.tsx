import { useState } from "react";
import { store, useStore } from "../lib/store";
import { Label, Panel, SectionLabel, Tag } from "../components/ui";
import { IncidentCard } from "./panels";
import { ago } from "../lib/types";

/* ═══════════════════════════ INCIDENTS ═══════════════════════════ */

export function IncidentsView() {
  const w = useStore();
  const [state, setState] = useState<"all" | "open" | "ack" | "resolved">("all");
  const list = w.incidents.filter((i) => state === "all" || i.state === state);
  const counts = {
    open: w.incidents.filter((i) => i.state === "open").length,
    ack: w.incidents.filter((i) => i.state === "ack").length,
    resolved: w.incidents.filter((i) => i.state === "resolved").length,
  };

  return (
    <div className="pb-4">
      <section className="grid grid-cols-12 gap-6 pb-6">
        <div className="col-span-12 lg:col-span-7">
          <Label>monitor → incident → notify → recover</Label>
          <h1 className="display mt-3 text-[34px] leading-[1] sm:text-[42px]">
            A red card
            <br />
            is not enough.
          </h1>
          <p className="mt-3 max-w-[50ch] text-[12.5px] leading-relaxed" style={{ color: "var(--ink-2)" }}>
            Failed checks open a record with a timeline and recovery attempts, then trigger the auto-restart policy, then
            alert. Duplicate incidents dedupe; recovery auto-resolves.
          </p>
        </div>
        <div className="col-span-12 grid grid-cols-3 gap-3 lg:col-span-5">
          {(
            [
              ["open", counts.open, "var(--down)"],
              ["acked", counts.ack, "var(--accent)"],
              ["resolved", counts.resolved, "var(--up)"],
            ] as const
          ).map(([k, v, t]) => (
            <Panel key={k} className="p-4">
              <div className="label">{k}</div>
              <div className="display tnum mt-2 text-[30px] leading-none" style={{ color: t }}>
                {v}
              </div>
            </Panel>
          ))}
        </div>
      </section>

      <div className="grid grid-cols-12 gap-3">
        <div className="col-span-12 space-y-3 xl:col-span-8">
          <div className="flex flex-wrap items-center gap-1">
            {(["all", "open", "ack", "resolved"] as const).map((s) => (
              <button
                key={s}
                className="chip"
                onClick={() => setState(s)}
                style={{
                  color: state === s ? "var(--bg)" : "var(--ink-2)",
                  background: state === s ? "var(--ink)" : "var(--surface-2)",
                  borderColor: "transparent",
                }}
              >
                {s} {s !== "all" && `(${counts[s as keyof typeof counts]})`}
              </button>
            ))}
            <span className="ml-auto mono text-[9px]" style={{ color: "var(--ink-3)" }}>
              GET /api/incidents?state=open · POST /:id/ack · /:id/resolve
            </span>
          </div>

          {list.length === 0 ? (
            <Panel className="p-12 text-center">
              <div className="serif text-[22px]">Nothing here.</div>
              <p className="mono mt-2 text-[10.5px]" style={{ color: "var(--ink-3)" }}>
                no incidents match this state
              </p>
            </Panel>
          ) : (
            list.map((i) => <IncidentCard key={i.id} i={i} />)
          )}
        </div>

        <aside className="col-span-12 space-y-3 xl:col-span-4">
          <Panel className="p-4">
            <SectionLabel>alert rules</SectionLabel>
            <div className="space-y-2.5">
              {[
                ["telegram", "if DOWN > 60s", "var(--up)"],
                ["discord", "if restarts > 5 per 10min", "var(--accent)"],
                ["email", "if deployment failed", "var(--warn)"],
                ["webhook", "if severity = sev1", "var(--down)"],
              ].map(([ch, rule, tone]) => (
                <div key={ch} className="flex items-baseline justify-between gap-2">
                  <span className="mono text-[10.5px]" style={{ color: tone }}>
                    {ch}
                  </span>
                  <span className="mono text-right text-[10px]" style={{ color: "var(--ink-3)" }}>
                    {rule}
                  </span>
                </div>
              ))}
            </div>
            <p className="mono mt-3 text-[9.5px] leading-relaxed" style={{ color: "var(--ink-3)" }}>
              rules, not hardcodes — evaluated by notifier.js against every state transition. dedupe + auto-resolve on recovery.
            </p>
          </Panel>

          <Panel className="p-4">
            <SectionLabel>maintenance window</SectionLabel>
            <div className="flex items-baseline justify-between">
              <span className="label">quiet hours</span>
              <span className="mono text-[11px]">02:00 → 03:00</span>
            </div>
            <p className="mono mt-2.5 text-[10px] leading-relaxed" style={{ color: "var(--ink-3)" }}>
              no alerts dispatched inside the window; incidents still open and stay on the record.
            </p>
          </Panel>

          <Panel className="p-4">
            <SectionLabel>auto-recovery policy (local)</SectionLabel>
            <pre className="mono mt-2 overflow-x-auto text-[10px] leading-[1.75]" style={{ color: "var(--ink-2)" }}>
{`on crash/exit or 3 failed checks:
  wait 5s → restart (attempt 1/3)
  verify /health within 20s
  if still failing after 3 attempts
    → mark DOWN
    → open incident
    → alert
respect: maxRestarts, cooldown,
         startOnBoot`}
            </pre>
          </Panel>
        </aside>
      </div>
    </div>
  );
}

/* ═════════════════════════════ API ═════════════════════════════ */

const METHOD_TONE: Record<string, string> = {
  GET: "var(--info)",
  POST: "var(--up)",
  PATCH: "var(--warn)",
  DELETE: "var(--down)",
  SSE: "var(--accent)",
};

const API: { group: string; note: string; rows: [string, string, string][] }[] = [
  {
    group: "projects",
    note: "registry crud — POST validates cwd inside allowed root, port 1024–65535, url http(s)",
    rows: [
      ["GET", "/api/projects", "{ projects: [...] } — schema: registry-schema.md"],
      ["POST", "/api/projects", "body { name, location, runtime, source? } → { id }"],
      ["PATCH", "/api/projects/:id", "update runtime / monitoring / notifications"],
      ["DELETE", "/api/projects/:id", "stops the process first if local + running"],
    ],
  },
  {
    group: "status",
    note: "latest check + history; /api/health is the only unauthenticated route",
    rows: [
      ["GET", "/api/status", "{ id: { status, code, latencyMs, checkedAt, uptime24h, restarts } }"],
      ["GET", "/api/status/:id/history?range=24h|7d|30d", "{ checks: [{ ts, code, latencyMs, error }] }"],
      ["GET", "/api/health", "unauth → { ok: true } — for tunnel / load balancer"],
    ],
  },
  {
    group: "process",
    note: "local only — external projects return 400, control lives at the provider",
    rows: [
      ["POST", "/api/process/:id/start|stop|restart", "→ { ok, pid? } · SIGTERM → wait → SIGKILL"],
      ["GET", "/api/process/:id", "{ pid, alive, cpuPct, memMB, uptimeSec, restarts }"],
    ],
  },
  {
    group: "logs",
    note: "capped, newest last, secrets redacted at the pipe",
    rows: [
      ["GET", "/api/logs/:id?lines=200", "{ lines: [\"…\"] }"],
      ["SSE", "/api/logs/:id/stream", "tail-follow — phase 2"],
    ],
  },
  {
    group: "deployments",
    note: "async — returns a deploymentId you poll; health gate fail ⇒ automatic rollback",
    rows: [
      ["POST", "/api/deploy/:id", "body { sha?: \"latest\"|\"\", skipBuild? } → { deploymentId }"],
      ["GET", "/api/deploy/:id", "{ id, sha, branch, startedAt, endedAt, status, buildTail }"],
      ["POST", "/api/deploy/:id/rollback", "body { toDeploymentId } → re-checkout + restart + verify"],
    ],
  },
  {
    group: "incidents",
    note: "dedupe on repeat, auto-resolve on 3 consecutive OK checks",
    rows: [
      ["GET", "/api/incidents?project=:id&state=open", "{ incidents: [...] }"],
      ["POST", "/api/incidents/:incidentId/ack", "body { note? }"],
      ["POST", "/api/incidents/:incidentId/resolve", "body { note? }"],
    ],
  },
  {
    group: "terminal",
    note: "safe mode — no shell:true, no chaining; denied commands → 403 + audit “denied”",
    rows: [["POST", "/api/exec/:id", "body { cmd, args, timeoutSec? } → { exitCode, stdout, stderr, truncated }"]],
  },
  {
    group: "ai",
    note: "structured diagnosis; execute requires a confirm token for mutating tools",
    rows: [
      ["POST", "/api/ai/:id/ask", "{ question } → { severity, likelyCause, confidence, evidence[], recommendedActions[], commands[], safeToAutoFix }"],
      ["POST", "/api/ai/:id/execute", "{ tool: restart_project|run_safe_command|deploy_project, args }"],
    ],
  },
];

const PHASES: [string, string, boolean][] = [
  ["Phase 1", "secure monitoring mvp — registry, checks, status cards, latency, log viewer, auth, rotation, ai provider switcher", true],
  ["Phase 2", "process control — start/stop/restart, pid tracking, crash detect, auto-restart, cpu/mem, boot recovery, streaming logs", false],
  ["Phase 3", "deploy engine + templates — git pull/build/verify/rollback, history, hooks, vercel link + api trigger, 17 templates + autodetect", false],
  ["Phase 4", "incidents & alerts — incident records, maintenance, telegram/discord, body-json/tcp/ssl/disk/mem checks, alert rules", false],
  ["Phase 5", "ai ops — structured diagnosis json, incident memory, mcp tools manifest, grounded docs lookup, approved execution, reports", false],
  ["Phase 6", "multi-server — agents, remote control, server overview, team rbac (agents also serve mcp tools)", false],
];

export function ApiView() {
  const w = useStore();
  return (
    <div className="pb-4">
      <section className="grid grid-cols-12 gap-6 pb-6">
        <div className="col-span-12 lg:col-span-7">
          <Label>docs/api-v1.md · the contract</Label>
          <h1 className="display mt-3 text-[34px] leading-[1] sm:text-[42px]">
            Base :3001.
            <br />
            Bearer everywhere.
          </h1>
          <p className="mt-3 max-w-[52ch] text-[12.5px] leading-relaxed" style={{ color: "var(--ink-2)" }}>
            Auth on every <span className="mono">/api/*</span> route except <span className="mono">/api/health</span>.
            Read-only share links carry <span className="mono">?share=</span> and may only reach GET status and projects.
          </p>
          <div className="mt-4 flex flex-wrap gap-1.5">
            {["NOT_FOUND", "VALIDATION", "FORBIDDEN", "CONFLICT"].map((c) => (
              <Tag key={c} tone="warn">
                {c}
              </Tag>
            ))}
            <Tag>errors never leak stack or env</Tag>
          </div>
        </div>
        <div className="col-span-12 lg:col-span-5">
          <Panel className="overflow-hidden">
            <div className="px-4 py-2.5 hair-b">
              <span className="label">mental model</span>
            </div>
            <pre className="mono overflow-x-auto px-4 py-3 text-[9.5px] leading-[1.7]" style={{ color: "var(--ink-2)" }}>
{`+------------------+    poll 30s    +-------------------+
|  Dashboard UI    | <-------------> | server.js (:3001) |
|  cards, logs,    |  REST + SSE     |  api/ + core/     |
|  terminal, AI    |                 +--------+----------+
+------------------+                          |
        | read-only share link                 | spawn / fetch
        v                                      v
  public status page              +---------+----------+
                                  | projects | logs    |
                                  | status | deploys   |
                                  | incidents | audit  |
                                  +---------+----------+
                                  file json → sqlite`}
            </pre>
          </Panel>
        </div>
      </section>

      <div className="grid grid-cols-12 gap-3">
        <div className="col-span-12 space-y-3 xl:col-span-8">
          {API.map((g) => (
            <Panel key={g.group} className="overflow-hidden">
              <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 hair-b" style={{ background: "var(--surface-2)" }}>
                <span className="display text-[13px]">{g.group}</span>
                <span className="mono text-[9px]" style={{ color: "var(--ink-3)" }}>
                  {g.note}
                </span>
              </div>
              <div className="divide-y" style={{ borderColor: "var(--line)" }}>
                {g.rows.map(([m, path, desc]) => (
                  <div key={path + m} className="flex flex-wrap items-baseline gap-x-3 gap-y-1 px-4 py-2.5">
                    <span className="mono w-[46px] shrink-0 text-[10px]" style={{ color: METHOD_TONE[m] }}>
                      {m}
                    </span>
                    <span className="mono min-w-0 flex-1 break-all text-[11px]" style={{ color: "var(--ink)" }}>
                      {path}
                    </span>
                    <span className="mono basis-full pl-[58px] text-[10px] leading-relaxed sm:basis-auto" style={{ color: "var(--ink-3)" }}>
                      {desc}
                    </span>
                  </div>
                ))}
              </div>
            </Panel>
          ))}
        </div>

        <aside className="col-span-12 space-y-3 xl:col-span-4">
          <Panel className="p-4">
            <SectionLabel>roadmap</SectionLabel>
            <div className="space-y-3">
              {PHASES.map(([ph, body, now]) => (
                <div key={ph} className="flex gap-3">
                  <span className="mono mt-[2px] shrink-0 text-[9.5px]" style={{ color: now ? "var(--up)" : "var(--ink-3)" }}>
                    {now ? "●" : "○"}
                  </span>
                  <div className="min-w-0">
                    <div className="mono text-[10.5px]" style={{ color: now ? "var(--up)" : "var(--ink-2)" }}>
                      {ph}
                      {now && <span className="mono ml-1.5" style={{ color: "var(--ink-3)" }}>· building now</span>}
                    </div>
                    <div className="mono mt-1 text-[9.5px] leading-relaxed" style={{ color: "var(--ink-3)" }}>
                      {body}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Panel>

          <Panel className="p-4">
            <SectionLabel>safety rails</SectionLabel>
            <ul className="space-y-2">
              {[
                "token login from day one — control APIs are never public",
                "spawn(cmd, args, { cwd, shell: false }) — no bash -c injection",
                "cwd jail + 30s timeout + 100kb output cap on every exec",
                "env-secret masking before anything is written to disk",
                "destructive commands need an explicit confirm",
                "ai never gets raw shell — it gets tools, and only approved ones",
              ].map((s, i) => (
                <li key={i} className="flex gap-2.5">
                  <span className="mono mt-[1px] text-[10px]" style={{ color: "var(--up)" }}>
                    ✓
                  </span>
                  <span className="text-[11.5px] leading-relaxed">{s}</span>
                </li>
              ))}
            </ul>
          </Panel>

          <Panel className="p-4">
            <SectionLabel>multi-server seam</SectionLabel>
            <pre className="mono mt-2 overflow-x-auto text-[9.5px] leading-[1.7]" style={{ color: "var(--ink-2)" }}>
{`Central ──HTTPS/WS── Agent A
        ──            Agent B (vps)
                      Agent C (pi)

agents dial out — no inbound ports
agent advertises { hostname, platform,
  mem, projects, version }`}
            </pre>
            <p className="mono mt-2.5 text-[9.5px] leading-relaxed" style={{ color: "var(--ink-3)" }}>
              v1 is single-server, but every project already carries <span className="mono">agentId</span> and a stable id, so
              aggregation is additive — not a rewrite.
            </p>
          </Panel>

          <Panel className="p-4">
            <SectionLabel>session</SectionLabel>
            <div className="space-y-1.5">
              {[
                ["uptime", ago(Date.now() - 1000 * 60 * 42, w.clock)],
                ["checks run", `${store.stats().checks}`],
                ["design language", w.theme],
                ["mode", w.readOnly ? "read-only share" : "operator"],
              ].map(([k, v]) => (
                <div key={k} className="flex items-baseline justify-between gap-2">
                  <span className="label">{k}</span>
                  <span className="mono text-[10.5px]" style={{ color: "var(--ink-2)" }}>
                    {v}
                  </span>
                </div>
              ))}
            </div>
          </Panel>
        </aside>
      </div>
    </div>
  );
}
