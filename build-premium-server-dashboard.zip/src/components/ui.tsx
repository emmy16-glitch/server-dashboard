import React from "react";
import type { Check, Status } from "../lib/types";
import { statusColor } from "../lib/types";

export const cx = (...c: (string | false | null | undefined)[]) => c.filter(Boolean).join(" ");

/* ────────────────────────────── atoms ────────────────────────────── */

export function StatusDot({ status, lg = false, breathe = true }: { status: Status; lg?: boolean; breathe?: boolean }) {
  const c = statusColor(status);
  const live = status === "UP" || status === "STARTING" || status === "DEGRADED";
  return (
    <span
      className={cx("dot", lg && "dot-lg", live && breathe && "breathe")}
      style={{ background: c, color: c }}
    />
  );
}

export function StatusBadge({ status, wide = false }: { status: Status; wide?: boolean }) {
  const c = statusColor(status);
  return (
    <span
      className="chip"
      style={{
        color: c,
        borderColor: `color-mix(in srgb, ${c} 42%, transparent)`,
        background: `color-mix(in srgb, ${c} 10%, transparent)`,
        minWidth: wide ? 92 : undefined,
        justifyContent: wide ? "center" : undefined,
      }}
    >
      <span className="dot" style={{ background: c, color: c }} />
      {status}
    </span>
  );
}

export function Tag({ children, tone = "line" }: { children: React.ReactNode; tone?: "line" | "accent" | "up" | "warn" | "down" }) {
  const color = tone === "line" ? "var(--ink-3)" : tone === "accent" ? "var(--accent)" : tone === "up" ? "var(--up)" : tone === "warn" ? "var(--warn)" : "var(--down)";
  return (
    <span className="chip" style={{ color, borderColor: `color-mix(in srgb, ${color} 40%, transparent)` }}>
      {children}
    </span>
  );
}

export function Label({ children, className }: { children: React.ReactNode; className?: string }) {
  return <div className={cx("label", className)}>{children}</div>;
}

export function KV({ k, v, mono = true, tone }: { k: string; v: React.ReactNode; mono?: boolean; tone?: string }) {
  return (
    <div className="flex items-baseline justify-between gap-3 py-[5px]">
      <span className="label" style={{ letterSpacing: "0.1em" }}>
        {k}
      </span>
      <span
        className={cx("text-[11.5px] tnum", mono && "mono")}
        style={{ color: tone ?? "var(--ink)" }}
        title={typeof v === "string" ? v : undefined}
      >
        {v}
      </span>
    </div>
  );
}

export function SectionLabel({ children, right }: { children: React.ReactNode; right?: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3 pt-1 pb-2">
      <span className="label whitespace-nowrap">{children}</span>
      <span className="h-px flex-1" style={{ background: "var(--line)" }} />
      {right}
    </div>
  );
}

export function Panel({
  children,
  className,
  flat,
  as = "div",
  ...rest
}: {
  children: React.ReactNode;
  className?: string;
  flat?: boolean;
  as?: "div" | "section" | "aside";
} & React.HTMLAttributes<HTMLDivElement>) {
  const Tag = as as React.ElementType;
  return (
    <Tag className={cx(flat ? "panel-flat" : "panel", className)} {...rest}>
      {children}
    </Tag>
  );
}

export function Meter({ value, max = 100, tone = "var(--accent)", height = 4 }: { value: number; max?: number; tone?: string; height?: number }) {
  return (
    <div className="w-full overflow-hidden" style={{ height, background: "var(--surface-3)", borderRadius: "var(--r)" }}>
      <div
        style={{
          width: `${Math.max(0, Math.min(100, (value / max) * 100))}%`,
          height: "100%",
          background: tone,
          transition: "width .5s ease",
        }}
      />
    </div>
  );
}

export function BigStat({
  label,
  value,
  unit,
  sub,
  tone,
  serif,
}: {
  label: string;
  value: React.ReactNode;
  unit?: string;
  sub?: React.ReactNode;
  tone?: string;
  serif?: boolean;
}) {
  return (
    <div className="min-w-0">
      <div className="label mb-2">{label}</div>
      <div className="flex items-baseline gap-1.5">
        <span
          className={cx("display tnum leading-none", serif ? "serif text-[40px]" : "text-[30px]")}
          style={{ color: tone ?? "var(--ink)" }}
        >
          {value}
        </span>
        {unit && <span className="mono text-[11px]" style={{ color: "var(--ink-3)" }}>{unit}</span>}
      </div>
      {sub && (
        <div className="mono mt-2 text-[10.5px] leading-tight" style={{ color: "var(--ink-3)" }}>
          {sub}
        </div>
      )}
    </div>
  );
}

/* ───────────────────────────── charts ───────────────────────────── */

export function Sparkline({
  checks,
  height = 34,
  tone = "var(--accent)",
  showFails = true,
}: {
  checks: Check[];
  height?: number;
  tone?: string;
  showFails?: boolean;
}) {
  const pts = checks.slice(-60);
  if (!pts.length) return <div style={{ height }} />;
  const lat = pts.map((c) => c.latencyMs ?? 0);
  const max = Math.max(...lat, 60) * 1.15;
  const w = 100;
  const step = w / Math.max(1, pts.length - 1);
  const y = (v: number) => height - (v / max) * (height - 3) - 1.5;
  const line = pts.map((c, i) => `${(i * step).toFixed(2)},${y(c.latencyMs ?? max * 0.92).toFixed(2)}`).join(" ");
  const area = `0,${height} ${line} ${w},${height}`;
  const fails = pts.map((c, i) => ({ c, i })).filter(({ c }) => c.code !== 200);
  return (
    <svg viewBox={`0 0 ${w} ${height}`} preserveAspectRatio="none" style={{ width: "100%", height, display: "block" }} aria-hidden>
      <line x1="0" y1={height - 0.5} x2={w} y2={height - 0.5} stroke="var(--line)" strokeWidth="0.5" />
      <polygon points={area} fill={tone} opacity="0.09" />
      <polyline points={line} fill="none" stroke={tone} strokeWidth="1" vectorEffect="non-scaling-stroke" strokeLinejoin="round" />
      {showFails &&
        fails.map(({ c, i }) => (
          <rect
            key={i}
            x={(i * step).toFixed(2)}
            y={0}
            width={Math.max(0.7, step * 0.75)}
            height={height}
            fill={c.code === 404 ? "var(--warn)" : "var(--down)"}
            opacity="0.42"
          />
        ))}
    </svg>
  );
}

export function UptimeBar({ checks, segments = 44 }: { checks: Check[]; segments?: number }) {
  const pts = checks.slice(-segments);
  const pad = Math.max(0, segments - pts.length);
  return (
    <div className="flex h-[14px] w-full items-stretch gap-[2px]">
      {Array.from({ length: pad }).map((_, i) => (
        <span key={`p${i}`} className="flex-1" style={{ background: "var(--surface-3)" }} />
      ))}
      {pts.map((c, i) => (
        <span
          key={i}
          className="flex-1"
          title={`${new Date(c.ts).toISOString().slice(11, 19)} · ${c.code ?? "ERR"}${c.error ? ` · ${c.error}` : ""}`}
          style={{
            background: c.code === 200 ? "var(--up)" : c.code === 404 || c.code === 502 ? "var(--warn)" : "var(--down)",
            opacity: c.code === 200 ? 0.72 : 1,
          }}
        />
      ))}
    </div>
  );
}

export function Bars({ checks, height = 30 }: { checks: Check[]; height?: number }) {
  const pts = checks.slice(-48);
  const max = Math.max(...pts.map((c) => c.latencyMs ?? 0), 80);
  return (
    <div className="flex w-full items-end gap-[1.5px]" style={{ height }}>
      {pts.map((c, i) => {
        const h = c.latencyMs ? Math.max(2, (c.latencyMs / max) * height) : 2;
        return (
          <span
            key={i}
            style={{
              flex: 1,
              height: h,
              background: c.code === 200 ? "var(--ink-2)" : c.code === 404 ? "var(--warn)" : "var(--down)",
              opacity: c.code === 200 ? 0.4 : 1,
            }}
          />
        );
      })}
    </div>
  );
}

export function Ring({ value, size = 92, label, tone }: { value: number; size?: number; label?: string; tone?: string }) {
  const r = size / 2 - 6;
  const c = 2 * Math.PI * r;
  const t = tone ?? (value > 99 ? "var(--up)" : value > 90 ? "var(--warn)" : "var(--down)");
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--surface-3)" strokeWidth="6" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={t}
          strokeWidth="6"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c - (c * Math.min(100, value)) / 100}
          style={{ transition: "stroke-dashoffset .6s ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="display tnum text-[17px] leading-none">{value.toFixed(1)}%</span>
        {label && <span className="label mt-1">{label}</span>}
      </div>
    </div>
  );
}

/* ───────────────────────────── controls ─────────────────────────── */

export function Toggle({ on, onChange, labels }: { on: boolean; onChange: (v: boolean) => void; labels?: [string, string] }) {
  return (
    <button
      onClick={() => onChange(!on)}
      className="flex items-center gap-2"
      style={{ background: "none", border: 0, cursor: "pointer", padding: 0 }}
      aria-pressed={on}
    >
      <span
        className="relative inline-flex h-[16px] w-[30px] items-center transition-colors"
        style={{ background: on ? "var(--up)" : "var(--surface-3)", borderRadius: 999, border: "var(--bw) solid var(--line)" }}
      >
        <span
          className="absolute h-[10px] w-[10px] transition-all"
          style={{ left: on ? 17 : 3, background: on ? "#fff" : "var(--ink-3)", borderRadius: 999 }}
        />
      </span>
      {labels && (
        <span className="mono text-[10px]" style={{ color: "var(--ink-2)" }}>
          {on ? labels[0] : labels[1]}
        </span>
      )}
    </button>
  );
}

export function Segmented<T extends string>({
  value,
  options,
  onChange,
}: {
  value: T;
  options: readonly T[];
  onChange: (v: T) => void;
}) {
  return (
    <div
      className="flex items-center gap-0 hair hair-x"
      style={{ borderRadius: "calc(var(--r) * .72)", overflow: "hidden", background: "var(--surface-2)" }}
    >
      {options.map((o) => (
        <button
          key={o}
          onClick={() => onChange(o)}
          className="mono px-2.5 py-[5px] text-[10px] uppercase transition-colors"
          style={{
            background: value === o ? "var(--ink)" : "transparent",
            color: value === o ? "var(--bg)" : "var(--ink-3)",
            letterSpacing: "0.08em",
          }}
        >
          {o}
        </button>
      ))}
    </div>
  );
}

export function Kbd({ children }: { children: React.ReactNode }) {
  return (
    <span
      className="mono px-[4px] py-[2px] text-[9.5px]"
      style={{ border: "var(--bw) solid var(--line)", borderRadius: "calc(var(--r) * .6)", color: "var(--ink-3)" }}
    >
      {children}
    </span>
  );
}

export function Empty({ title, body, action }: { title: string; body: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 px-6 py-14 text-center">
      <div className="serif text-[22px]" style={{ color: "var(--ink)" }}>
        {title}
      </div>
      <p className="max-w-sm text-[12px] leading-relaxed" style={{ color: "var(--ink-3)" }}>
        {body}
      </p>
      {action}
    </div>
  );
}
