import React from "react";
import { AGENT, store, THEMES, useStore } from "../lib/store";
import type { ThemeName } from "../lib/types";
import { clockOf } from "../lib/types";
import { Kbd, StatusDot, cx } from "./ui";

export type View = "overview" | "project" | "registry" | "incidents" | "audit" | "api";
export interface Route {
  view: View;
  id?: string;
  tab?: string;
}

const NAV: { key: View; label: string; hint: string }[] = [
  { key: "overview", label: "Fleet", hint: "status cards · monitor" },
  { key: "registry", label: "Registry", hint: "projects.json" },
  { key: "incidents", label: "Incidents", hint: "open · ack · resolve" },
  { key: "audit", label: "Audit", hint: "append-only trail" },
  { key: "api", label: "API v1", hint: "the contract" },
];

/* ────────────────────────────── theme ────────────────────────────── */

export function ThemeSwitcher({ compact = false }: { compact?: boolean }) {
  const { theme } = useStore();
  const set = (t: ThemeName) => store.set("theme", t);
  if (compact)
    return (
      <div className="flex items-center gap-1 hair hair-x p-[2px]" style={{ borderRadius: 999 }}>
        {THEMES.map((t) => (
          <button
            key={t.key}
            onClick={() => set(t.key)}
            title={`${t.name} — ${t.material}`}
            className="h-[18px] w-[18px]"
            style={{
              borderRadius: 999,
              background: theme === t.key ? "var(--ink)" : "transparent",
              border: `var(--bw) solid ${theme === t.key ? "var(--ink)" : "var(--line)"}`,
            }}
          >
            <span
              className="mx-auto block h-[6px] w-[6px]"
              style={{
                borderRadius: 999,
                background: theme === t.key ? "var(--bg)" : "var(--ink-3)",
              }}
            />
          </button>
        ))}
      </div>
    );
  return (
    <div className="space-y-[3px]">
      {THEMES.map((t) => {
        const on = theme === t.key;
        return (
          <button
            key={t.key}
            onClick={() => set(t.key)}
            className="group w-full text-left transition-all"
            style={{
              padding: "7px 9px",
              border: `var(--bw) solid ${on ? "var(--line-2)" : "transparent"}`,
              background: on ? "var(--surface)" : "transparent",
              borderRadius: "calc(var(--r) * .7)",
            }}
          >
            <div className="flex items-center justify-between gap-2">
              <span
                className="display text-[12.5px] leading-none"
                style={{ color: on ? "var(--ink)" : "var(--ink-2)" }}
              >
                {t.name}
              </span>
              <span className="label-sm" style={{ color: on ? "var(--accent)" : "var(--ink-3)" }}>
                {on ? "active" : ""}
              </span>
            </div>
            <div className="mono mt-[5px] text-[9px] leading-tight" style={{ color: "var(--ink-3)" }}>
              {t.material} · {t.structure}
            </div>
            <div className="mono mt-[3px] text-[9px] leading-tight" style={{ color: "var(--ink-3)", opacity: 0.75 }}>
              {t.feeling}
            </div>
          </button>
        );
      })}
    </div>
  );
}

/* ────────────────────────────── header ───────────────────────────── */

function Header({ route, go, onPalette }: { route: Route; go: (r: Route) => void; onPalette: () => void }) {
  const w = useStore();
  const s = store.stats();
  const fleet = s.fleet >= 99.9 ? "ALL SYSTEMS NOMINAL" : s.down > 0 ? "DEGRADED FLEET" : "PARTIAL DEGRADED";
  return (
    <header
      className="sticky top-0 z-40 hair-b"
      style={{
        background: "color-mix(in srgb, var(--bg) 86%, transparent)",
        backdropFilter: "blur(12px)",
        WebkitBackdropFilter: "blur(12px)",
      }}
    >
      <div className="mx-auto flex h-[54px] max-w-[1560px] items-center gap-4 px-4 sm:px-6">
        <button className="flex items-center gap-2.5" onClick={() => go({ view: "overview" })} style={{ background: "none", border: 0, cursor: "pointer" }}>
          <span className="grid h-[26px] w-[26px] place-items-center" style={{ border: "var(--bw) solid var(--line-2)", borderRadius: "calc(var(--r) * .5)" }}>
            <span className="block h-[10px] w-[3px]" style={{ background: "var(--ink)" }} />
            <span className="block h-[10px] w-[3px] -ml-[6px]" style={{ background: "var(--accent)" }} />
          </span>
          <span className="hidden text-left sm:block">
            <span className="display block text-[14px] leading-none">server-dashboard</span>
            <span className="label block" style={{ marginTop: 4 }}>
              control plane · v1
            </span>
          </span>
        </button>

        <div className="hidden items-center gap-2 xl:flex">
          <span className="h-[22px] w-px" style={{ background: "var(--line)" }} />
          <span className="flex items-center gap-2">
            <StatusDot status={s.down ? "DOWN" : s.degraded ? "DEGRADED" : "UP"} />
            <span className="label" style={{ color: "var(--ink-2)" }}>
              {fleet}
            </span>
          </span>
        </div>

        <div className="flex-1" />

        <button className="btn hidden md:inline-flex" onClick={onPalette} style={{ color: "var(--ink-3)", minWidth: 210, justifyContent: "space-between" }}>
          <span>search · jump · run</span>
          <Kbd>⌘K</Kbd>
        </button>

        <div className="hidden items-center gap-3 lg:flex">
          <div className="text-right">
            <div className="mono tnum text-[12.5px] leading-none">{clockOf(w.clock)}</div>
            <div className="label" style={{ marginTop: 4 }}>
              next check {w.nextCheckIn}s
            </div>
          </div>
          <span className="h-[22px] w-px" style={{ background: "var(--line)" }} />
        </div>

        <button
          className="btn btn-sm"
          onClick={() => {
            store.set("paused", !w.paused);
            store.toast(w.paused ? "monitor resumed" : "monitor paused — checks suspended", "warn");
          }}
          title="pause / resume the health-monitor loop"
        >
          {w.paused ? "▶ resume" : "❙❙ pause"}
        </button>

        <button
          className={cx("btn btn-sm hidden sm:inline-flex", w.readOnly && "btn-accent")}
          onClick={() => {
            store.set("readOnly", !w.readOnly);
            store.toast(
              w.readOnly ? "operator mode — control APIs enabled" : "read-only share link active · POST/PATCH/DELETE blocked",
              w.readOnly ? "ok" : "warn",
            );
          }}
          title="simulate a read-only share link (?share=…)"
        >
          {w.readOnly ? "🔒 read-only" : "🔓 operator"}
        </button>

        <div className="lg:hidden">
          <ThemeSwitcher compact />
        </div>
      </div>

      <div className="mx-auto flex max-w-[1560px] items-center gap-4 overflow-x-auto px-4 pb-2 no-bar sm:px-6 lg:hidden">
        {NAV.map((n) => (
          <button
            key={n.key}
            className="tab"
            data-on={route.view === n.key || (n.key === "overview" && route.view === "project")}
            onClick={() => go({ view: n.key })}
          >
            {n.label}
          </button>
        ))}
      </div>
    </header>
  );
}

/* ─────────────────────────────── rail ────────────────────────────── */

function Rail({ route, go }: { route: Route; go: (r: Route) => void }) {
  const w = useStore();
  const open = w.incidents.filter((i) => i.state !== "resolved").length;
  return (
    <nav className="sticky top-[54px] hidden h-[calc(100vh-54px)] w-[212px] shrink-0 flex-col justify-between overflow-y-auto scroll px-4 py-5 lg:flex hair-r">
      <div className="space-y-[2px]">
        <div className="label mb-3 px-2">navigate</div>
        {NAV.map((n) => {
          const on = route.view === n.key || (n.key === "overview" && route.view === "project");
          return (
            <button
              key={n.key}
              onClick={() => go({ view: n.key })}
              className="group flex w-full items-center justify-between gap-2 px-2 py-[7px] text-left"
              style={{
                background: on ? "var(--surface)" : "transparent",
                border: `var(--bw) solid ${on ? "var(--line)" : "transparent"}`,
                borderRadius: "calc(var(--r) * .7)",
              }}
            >
              <span className="min-w-0">
                <span className="display block text-[13px] leading-none" style={{ color: on ? "var(--ink)" : "var(--ink-2)" }}>
                  {n.label}
                </span>
                <span className="mono mt-[5px] block text-[9px]" style={{ color: "var(--ink-3)" }}>
                  {n.hint}
                </span>
              </span>
              {n.key === "incidents" && open > 0 && (
                <span className="chip" style={{ color: "var(--down)", borderColor: "var(--down)" }}>
                  {open}
                </span>
              )}
            </button>
          );
        })}
      </div>

      <div className="space-y-4">
        <div>
          <div className="label mb-2 px-1">design language</div>
          <ThemeSwitcher />
        </div>
        <div className="space-y-1 px-1 pt-2 hair-t">
          <div className="mono text-[9.5px] leading-relaxed" style={{ color: "var(--ink-3)" }}>
            <div>
              agent <span style={{ color: "var(--ink-2)" }}>{AGENT.id}</span> · {AGENT.hostname}
            </div>
            <div>{AGENT.platform}</div>
            <div style={{ marginTop: 4 }}>
              {store.stats().checks} checks this session
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}

/* ────────────────────────────── footer ───────────────────────────── */

function Footer() {
  const w = useStore();
  const s = store.stats();
  return (
    <footer className="relative z-10 mx-auto mt-10 max-w-[1560px] px-4 pb-10 sm:px-6">
      <div className="hair-t pt-4">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div className="mono text-[9.5px] leading-relaxed" style={{ color: "var(--ink-3)" }}>
            <div>
              api <span style={{ color: "var(--ink-2)" }}>http://localhost:3001</span> · auth bearer on /api/* ·{" "}
              <span style={{ color: "var(--ink-2)" }}>/api/health</span> unauth
            </div>
            <div>
              storage <span style={{ color: "var(--ink-2)" }}>projects.json · status-history.json · audit.json</span> → sqlite later
            </div>
            <div>
              constraints proot-ubuntu/termux · node v20 · no docker / pm2 / nginx / systemd
            </div>
          </div>
          <div className="mono text-[9.5px] text-right leading-relaxed" style={{ color: "var(--ink-3)" }}>
            <div>
              {s.local} local · {s.external} external · {s.total} monitored
            </div>
            <div>
              interval 30s · timeout 10s · <span style={{ color: "var(--warn)" }}>demo time-compressed ×6</span>
            </div>
            <div style={{ color: "var(--ink-2)" }}>
              {w.paused ? "monitor paused" : "monitor live"} · {s.p50}ms p50 / {s.p95}ms p95
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

/* ────────────────────────────── toasts ───────────────────────────── */

function Toasts() {
  const { toasts } = useStore();
  const tone = (k: string) => (k === "ok" ? "var(--up)" : k === "warn" ? "var(--warn)" : k === "err" ? "var(--down)" : "var(--accent)");
  return (
    <div className="pointer-events-none fixed bottom-4 right-4 z-50 flex w-[300px] flex-col gap-2">
      {toasts.map((t) => (
        <div
          key={t.id}
          className="slide-in panel flex items-start gap-2.5 p-3"
          style={{ borderLeft: `3px solid ${tone(t.kind)}` }}
        >
          <span className="mono text-[10px]" style={{ color: tone(t.kind) }}>
            {t.kind === "ok" ? "✓" : t.kind === "err" ? "✕" : t.kind === "warn" ? "!" : "›"}
          </span>
          <span className="mono text-[10.5px] leading-snug" style={{ color: "var(--ink)" }}>
            {t.text}
          </span>
        </div>
      ))}
    </div>
  );
}

/* ─────────────────────────────── shell ───────────────────────────── */

export function Shell({
  route,
  go,
  onPalette,
  children,
}: {
  route: Route;
  go: (r: Route) => void;
  onPalette: () => void;
  children: React.ReactNode;
}) {
  return (
    <div className="relative min-h-screen">
      <div className="page-bg" />
      <div
        className="pointer-events-none fixed left-0 right-0 top-0 z-50"
        style={{ height: 3, background: "var(--accent)" }}
        aria-hidden
      />
      <div className="relative z-10 flex min-h-screen flex-col">
        <Header route={route} go={go} onPalette={onPalette} />
        <div className="mx-auto flex w-full max-w-[1560px] flex-1">
          <Rail route={route} go={go} />
          <main className="min-w-0 flex-1 px-4 pt-5 sm:px-6">{children}</main>
        </div>
        <Footer />
      </div>
      <Toasts />
    </div>
  );
}
