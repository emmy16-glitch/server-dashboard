import { useEffect, useMemo, useRef, useState } from "react";
import { store, THEMES, useStore } from "../lib/store";
import type { ThemeName } from "../lib/types";
import { Kbd, cx } from "./ui";
import type { Route, View } from "./Shell";

type Cmd = { group: string; label: string; hint?: string; run: () => void };

export function Palette({ open, onClose, go }: { open: boolean; onClose: () => void; go: (r: Route) => void }) {
  const w = useStore();
  const [q, setQ] = useState("");
  const [i, setI] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const cmds: Cmd[] = useMemo(() => {
    const views: [View, string][] = [
      ["overview", "Fleet — status cards"],
      ["registry", "Registry — projects.json"],
      ["incidents", "Incidents — open · ack · resolve"],
      ["audit", "Audit — append-only trail"],
      ["api", "API v1 — the contract"],
    ];
    return [
      ...views.map(([v, label]) => ({ group: "go to", label, hint: `#${v}`, run: () => go({ view: v }) })),
      ...w.projects.map((p) => ({
        group: "project",
        label: `${p.name} · ${w.live[p.id]?.status ?? "—"}`,
        hint: p.id,
        run: () => go({ view: "project", id: p.id, tab: "overview" }),
      })),
      ...w.projects
        .filter((p) => p.location.type === "local")
        .map((p) => ({
          group: "control",
          label: `restart ${p.name}`,
          hint: `POST /api/process/${p.id}/restart`,
          run: () => store.restart(p.id),
        })),
      ...w.projects
        .filter((p) => p.location.type === "local")
        .map((p) => ({
          group: "control",
          label: `deploy ${p.name}`,
          hint: `POST /api/deploy/${p.id}`,
          run: () => go({ view: "project", id: p.id, tab: "deploy" }),
        })),
      ...w.incidents
        .filter((x) => x.state !== "resolved")
        .map((x) => ({
          group: "incident",
          label: `ack ${x.id} — ${x.cause.slice(0, 46)}…`,
          hint: x.projectId,
          run: () => store.ackIncident(x.id),
        })),
      {
        group: "monitor",
        label: w.paused ? "resume health-monitor loop" : "pause health-monitor loop",
        hint: "interval 30s · timeout 10s",
        run: () => store.set("paused", !w.paused),
      },
      {
        group: "monitor",
        label: w.readOnly ? "leave read-only share mode" : "simulate read-only share link",
        hint: "?share=… · GET status/projects only",
        run: () => store.set("readOnly", !w.readOnly),
      },
      ...THEMES.map((t) => ({
        group: "design language",
        label: `${t.name} — ${t.material}`,
        hint: `${t.structure} · ${t.note}`,
        run: () => store.set("theme", t.key as ThemeName),
      })),
    ];
  }, [w, go]);

  const hits = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return cmds;
    return cmds.filter((c) => `${c.group} ${c.label} ${c.hint ?? ""}`.toLowerCase().includes(s));
  }, [q, cmds]);

  useEffect(() => {
    if (open) {
      setQ("");
      setI(0);
      window.setTimeout(() => inputRef.current?.focus(), 30);
    }
  }, [open]);

  useEffect(() => setI(0), [q]);

  if (!open) return null;

  const exec = (c?: Cmd) => {
    if (!c) return;
    c.run();
    onClose();
  };

  let lastGroup = "";
  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center px-4 pt-[12vh]"
      style={{ background: "color-mix(in srgb, var(--bg) 62%, transparent)", backdropFilter: "blur(6px)" }}
      onClick={onClose}
    >
      <div className="panel slide-in w-full max-w-[620px] overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-3 px-4 py-3 hair-b">
          <span className="mono text-[12px]" style={{ color: "var(--accent)" }}>
            ❯
          </span>
          <input
            ref={inputRef}
            className="mono flex-1 bg-transparent text-[12.5px] outline-none"
            style={{ border: 0, color: "var(--ink)" }}
            placeholder="jump to a project, run a control, switch design language…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Escape") onClose();
              if (e.key === "ArrowDown") {
                e.preventDefault();
                setI((v) => Math.min(hits.length - 1, v + 1));
              }
              if (e.key === "ArrowUp") {
                e.preventDefault();
                setI((v) => Math.max(0, v - 1));
              }
              if (e.key === "Enter") exec(hits[i]);
            }}
          />
          <Kbd>esc</Kbd>
        </div>

        <div className="scroll max-h-[52vh] overflow-y-auto py-1.5">
          {hits.length === 0 && (
            <div className="mono px-4 py-8 text-center text-[11px]" style={{ color: "var(--ink-3)" }}>
              nothing matches “{q}”
            </div>
          )}
          {hits.map((c, k) => {
            const head = c.group !== lastGroup;
            lastGroup = c.group;
            return (
              <div key={k}>
                {head && (
                  <div className="label px-4 pb-1.5 pt-3">
                    {c.group}
                  </div>
                )}
                <button
                  className={cx("flex w-full items-center justify-between gap-3 px-4 py-2 text-left")}
                  style={{
                    background: i === k ? "var(--surface-2)" : "transparent",
                    borderLeft: `2px solid ${i === k ? "var(--accent)" : "transparent"}`,
                  }}
                  onMouseEnter={() => setI(k)}
                  onClick={() => exec(c)}
                >
                  <span className="mono truncate text-[11.5px]" style={{ color: "var(--ink)" }}>
                    {c.label}
                  </span>
                  <span className="mono shrink-0 truncate text-[9.5px]" style={{ color: "var(--ink-3)", maxWidth: 220 }}>
                    {c.hint}
                  </span>
                </button>
              </div>
            );
          })}
        </div>

        <div className="flex items-center justify-between px-4 py-2 hair-t">
          <span className="mono text-[9px]" style={{ color: "var(--ink-3)" }}>
            {hits.length} results · ↑↓ navigate · ⏎ run
          </span>
          <span className="mono text-[9px]" style={{ color: "var(--ink-3)" }}>
            registry, not autodiscovery
          </span>
        </div>
      </div>
    </div>
  );
}
