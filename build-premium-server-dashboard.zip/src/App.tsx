import { useCallback, useEffect, useState } from "react";
import { store, useStore } from "./lib/store";
import { Palette } from "./components/Palette";
import { Shell, type Route } from "./components/Shell";
import { Overview } from "./views/Overview";
import { ProjectNotFound, ProjectView } from "./views/Project";
import { AuditView, RegistryView } from "./views/Registry";
import { ApiView, IncidentsView } from "./views/Info";

/* ───────────────────────── hash routing ───────────────────────── */

function parseHash(): Route {
  const h = window.location.hash.replace(/^#\/?/, "");
  const parts = h.split("/").filter(Boolean);
  if (!parts.length) return { view: "overview" };
  const [a, b, c] = parts;
  if (a === "p" && b) return { view: "project", id: b, tab: c ?? "overview" };
  if (["fleet", "overview"].includes(a)) return { view: "overview" };
  if (["registry", "incidents", "audit", "api"].includes(a)) return { view: a as Route["view"] };
  return { view: "overview" };
}

function toHash(r: Route) {
  if (r.view === "project" && r.id) return `#/p/${r.id}${r.tab ? `/${r.tab}` : ""}`;
  if (r.view === "overview") return "#/fleet";
  return `#/${r.view}`;
}

export default function App() {
  const w = useStore();
  const [route, setRoute] = useState<Route>(() => parseHash());
  const [palette, setPalette] = useState(false);

  /* theme → document */
  useEffect(() => {
    document.documentElement.dataset.theme = w.theme;
    document.documentElement.style.colorScheme = w.theme === "precision" || w.theme === "industrial" ? "light" : "dark";
  }, [w.theme]);

  /* monitor loop */
  useEffect(() => {
    store.startClock();
    return () => store.stopClock();
  }, []);

  /* hash ↔ route */
  useEffect(() => {
    const onHash = () => setRoute(parseHash());
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const go = useCallback((r: Route) => {
    setRoute(r);
    const next = toHash(r);
    if (window.location.hash !== next) window.location.hash = next;
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  /* keyboard */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      const typing = tag === "INPUT" || tag === "TEXTAREA";
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setPalette((v) => !v);
      }
      if (e.key === "Escape") setPalette(false);
      if (!typing && !palette) {
        if (e.key === "/") {
          e.preventDefault();
          setPalette(true);
        }
        if (e.key === "g") {
          const once = (ev: KeyboardEvent) => {
            const map: Record<string, Route> = {
              f: { view: "overview" },
              r: { view: "registry" },
              i: { view: "incidents" },
              a: { view: "audit" },
              d: { view: "api" },
            };
            if (map[ev.key]) go(map[ev.key]);
            window.removeEventListener("keydown", once);
          };
          window.addEventListener("keydown", once);
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [palette, go]);

  const project = route.view === "project" ? w.projects.find((p) => p.id === route.id) : undefined;

  return (
    <>
      <Shell route={route} go={go} onPalette={() => setPalette(true)}>
        {route.view === "overview" && <Overview go={go} />}
        {route.view === "project" && (project ? <ProjectView p={project} tab={route.tab ?? "overview"} go={go} /> : <ProjectNotFound go={go} />)}
        {route.view === "registry" && <RegistryView go={go} />}
        {route.view === "incidents" && <IncidentsView />}
        {route.view === "audit" && <AuditView />}
        {route.view === "api" && <ApiView />}
      </Shell>
      <Palette open={palette} onClose={() => setPalette(false)} go={go} />
    </>
  );
}
