/* ────────────────────────────────────────────────────────────────
   Types mirror docs/registry-schema.md + docs/api-v1.md
   ──────────────────────────────────────────────────────────────── */

export type Status = "UP" | "DEGRADED" | "DOWN" | "STARTING" | "STOPPED" | "DISABLED";
export type EnvType = "local" | "external";
export type Provider = "vercel" | "railway" | "render" | "github" | "other";
export type Range = "1h" | "24h" | "7d" | "30d";
export type ThemeName = "precision" | "terminal" | "glass" | "industrial";

export interface Project {
  id: string;
  name: string;
  enabled: boolean;
  template: string;
  note?: string;
  location: { type: EnvType; agentId: string; cwd?: string; provider?: Provider };
  runtime: {
    command?: string;
    args?: string[];
    port?: number;
    healthUrl: string;
    autoRestart?: boolean;
    maxRestarts?: number;
    restartCooldownSec?: number;
    startOnBoot?: boolean;
    startupTimeoutSec?: number;
    envFile?: string;
  };
  source?: { provider: Provider; repository: string; branch: string; deployOnPush?: boolean };
  monitoring: {
    intervalSeconds: number;
    timeoutSeconds: number;
    expectedStatus: number[];
    expectedBody?: string | null;
    healthConfig?: { type: string; json?: Record<string, string> };
  };
  notifications: {
    down: boolean;
    recovered: boolean;
    deploymentFailed?: boolean;
    crashLoop?: boolean;
  };
  tags?: string[];
}

export interface Check {
  ts: number;
  code: number | null;
  latencyMs: number | null;
  error?: string | null;
}

export type LogLevel = "sys" | "info" | "warn" | "error" | "ok";

export interface LogLine {
  ts: number;
  level: LogLevel;
  msg: string;
}

export interface Deployment {
  id: number;
  projectId: string;
  sha: string;
  branch: string;
  startedAt: number;
  endedAt: number | null;
  status: "running" | "success" | "failed" | "rolled-back";
  durationMs: number;
  triggeredBy: string;
  buildTail: string[];
}

export interface StageState {
  key: string;
  label: string;
  status: "pending" | "running" | "ok" | "fail" | "skip";
  ms: number;
}

export interface Incident {
  id: string;
  projectId: string;
  startedAt: number;
  resolvedAt: number | null;
  state: "open" | "ack" | "resolved";
  cause: string;
  severity: "sev1" | "sev2" | "sev3";
  timeline: { ts: number; text: string }[];
  recoveryAttempts: number;
  note?: string;
  acknowledgedBy?: string;
}

export interface AuditEntry {
  id: number;
  ts: number;
  actor: string;
  action: string;
  projectId: string;
  detail: string;
  result: "ok" | "denied" | "fail";
}

export interface Live {
  status: Status;
  code: number | null;
  latencyMs: number | null;
  checkedAt: number;
  uptime: Record<Range, number>;
  restarts: number;
  pid: number | null;
  cpuPct: number;
  memMB: number;
  uptimeSec: number;
  probes: number;
  fails: number;
  restartAttempt: number;
  sha: string;
  history: Check[];
  logs: LogLine[];
}

export interface AiDiagnosis {
  severity: "low" | "medium" | "high" | "critical";
  likelyCause: string;
  confidence: number;
  evidence: string[];
  recommendedActions: string[];
  commands: string[];
  safeToAutoFix: boolean;
  summary: string;
  model: string;
}

export interface Toast {
  id: number;
  text: string;
  kind: "ok" | "warn" | "err" | "info";
}

export interface World {
  clock: number;
  projects: Project[];
  live: Record<string, Live>;
  deployments: Deployment[];
  incidents: Incident[];
  audit: AuditEntry[];
  pipeline: { projectId: string; stages: StageState[]; startedAt: number; log: string[] } | null;
  ai: Record<string, { busy: boolean; q: string; d?: AiDiagnosis }>;
  theme: ThemeName;
  range: Range;
  readOnly: boolean;
  terminal: Record<string, { lines: string[]; cwd: string; mode: "safe" | "admin" }>;
  toasts: Toast[];
  nextCheckIn: number;
  checkCount: number;
  paused: boolean;
  filter: string;
  statusFilter: Status | "ALL";
  envFilter: EnvType | "ALL";
}

/* ─────────────────────────── helpers ─────────────────────────── */

export const T = (ms: number) => new Date(ms).toISOString().slice(11, 19);
export const clockOf = (ms: number) => new Date(ms).toTimeString().slice(0, 8);

export function ago(ms: number, now = Date.now()) {
  const s = Math.max(0, Math.round((now - ms) / 1000));
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h`;
  return `${Math.floor(h / 24)}d`;
}

export function dur(sec: number) {
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  if (d) return `${d}d ${h}h`;
  if (h) return `${h}h ${String(m).padStart(2, "0")}m`;
  if (m) return `${m}m ${String(s).padStart(2, "0")}s`;
  return `${s}s`;
}

export const statusColor = (s: Status) =>
  s === "UP" ? "var(--up)" : s === "DEGRADED" ? "var(--warn)" : s === "DOWN" ? "var(--down)" : "var(--idle)";

export const shortSha = (s: string) => s.slice(0, 7);

export const pct = (n: number) => `${n.toFixed(n >= 99.95 ? 0 : 2)}%`;

export function uuid() {
  return Math.random().toString(36).slice(2, 9);
}
