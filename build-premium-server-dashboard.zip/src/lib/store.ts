import { useSyncExternalStore } from "react";
import {
  ALLOWLIST,
  AGENT,
  SEED_AUDIT,
  SEED_DEPLOYMENTS,
  SEED_INCIDENTS,
  SEED_LIVE,
  SEED_PROJECTS,
  SEED_TERMINAL,
} from "./seed";
import type {
  AiDiagnosis,
  AuditEntry,
  Check,
  Deployment,
  EnvType,
  Incident,
  Live,
  LogLevel,
  Project,
  Status,
  ThemeName,
  Toast,
  World,
} from "./types";

export { AGENT, ALLOWLIST };

const BASE: Record<string, number> = {
  "echoo-backend": 44,
  "echoo-web": 92,
  "pulse-api": 240,
  "ghost-mailer": 62,
  "control-plane": 6,
  digistream: 224,
  "cv-forge": 124,
  "aurora-relay": 352,
};

const DEPLOY_STAGES: { key: string; label: string; tail: string[] }[] = [
  { key: "snapshot", label: "snapshot rollback pointer", tail: ["› git rev-parse HEAD → rollback pointer saved"] },
  { key: "fetch", label: "git fetch origin", tail: ["› git fetch origin main --depth=50", "› origin/main  a83f91d..e4b2c19"] },
  { key: "checkout", label: "checkout target sha", tail: ["› git checkout e4b2c19", "› HEAD is now at e4b2c19"] },
  {
    key: "install",
    label: "install dependencies",
    tail: ["› npm install --omit=dev", "› added 12 packages, removed 2, audited 214 in 3.4s"],
  },
  { key: "build", label: "build", tail: ["› npm run build", "› tsc 0 errors · bundle 148kb (−6kb)"] },
  { key: "pre", label: "pre-deploy hook", tail: ["› npm run migrate", "› 2 migrations applied (0041, 0042)"] },
  { key: "restart", label: "restart process", tail: ["› SIGTERM → pid 18422 … ok", "› spawn npm run start → pid 19**"] },
  { key: "gate", label: "health gate 3× /health", tail: ["› probe 1/3 ok · probe 2/3 ok · probe 3/3 ok"] },
  { key: "post", label: "post-deploy hook", tail: ["› npm run warm-cache", "› warmed 3 routes"] },
];

const STAGE_MS = [420, 980, 620, 1400, 1500, 900, 780, 1500, 620];

/* ────────────────────────────── world ────────────────────────────── */

function freshWorld(): World {
  const terminal: World["terminal"] = {};
  for (const p of SEED_PROJECTS) {
    terminal[p.id] =
      SEED_TERMINAL[p.id] ?? { cwd: p.location.cwd ?? "—", mode: "safe", lines: [`server-dashboard › safe terminal · cwd jail: ${p.location.cwd ?? "n/a (external)"}`] };
  }
  return {
    clock: Date.now(),
    projects: SEED_PROJECTS,
    live: structuredClone(SEED_LIVE),
    deployments: SEED_DEPLOYMENTS,
    incidents: SEED_INCIDENTS,
    audit: SEED_AUDIT,
    pipeline: null,
    ai: {},
    theme: "precision",
    range: "24h",
    readOnly: false,
    terminal,
    toasts: [],
    nextCheckIn: 5,
    checkCount: 0,
    paused: false,
    filter: "",
    statusFilter: "ALL",
    envFilter: "ALL",
  };
}

let auditSeq = 100;
let toastSeq = 1;
let deploySeq = 19;

class Store {
  state: World = freshWorld();
  private listeners = new Set<() => void>();
  private timer: number | null = null;
  private healed = new Set<string>();

  subscribe = (l: () => void) => {
    this.listeners.add(l);
    return () => this.listeners.delete(l);
  };
  get = () => this.state;

  private emit() {
    this.state = { ...this.state };
    this.listeners.forEach((l) => l());
  }

  startClock() {
    if (this.timer !== null) return;
    this.timer = window.setInterval(() => this.tick(), 1000);
  }
  stopClock() {
    if (this.timer !== null) window.clearInterval(this.timer);
    this.timer = null;
  }

  /* ─────────────────────────── primitives ─────────────────────────── */

  private log(id: string, level: LogLevel, msg: string, ts = Date.now()) {
    const l = this.state.live[id];
    if (!l) return;
    l.logs = [...l.logs, { ts, level, msg }].slice(-420);
  }

  private audit(actor: string, action: string, projectId: string, detail: string, result: AuditEntry["result"]) {
    this.state.audit = [
      { id: ++auditSeq, ts: Date.now(), actor, action, projectId, detail, result },
      ...this.state.audit,
    ].slice(0, 260);
  }

  toast(text: string, kind: Toast["kind"] = "info") {
    const t: Toast = { id: ++toastSeq, text, kind };
    this.state.toasts = [...this.state.toasts, t];
    this.emit();
    window.setTimeout(() => {
      this.state.toasts = this.state.toasts.filter((x) => x.id !== t.id);
      this.emit();
    }, 3800);
  }

  /* ───────────────────────────── set ─────────────────────────────── */

  set<K extends keyof World>(k: K, v: World[K]) {
    this.state[k] = v;
    this.emit();
  }
  patch(p: Partial<World>) {
    Object.assign(this.state, p);
    this.emit();
  }

  /* ───────────────────────────── tick ────────────────────────────── */

  private tick() {
    const w = this.state;
    w.clock = Date.now();
    if (w.paused) {
      this.emit();
      return;
    }
    w.nextCheckIn -= 1;
    if (w.nextCheckIn <= 0) {
      w.nextCheckIn = 5; // config 30s · demo compressed ×6
      this.runChecks();
    }
    this.emit();
  }

  private recomputeUptime(l: Live) {
    const h = l.history;
    const ok = h.filter((c) => c.code === 200).length;
    const h1 = h.length ? (ok / h.length) * 100 : 100;
    const fails = h.length - ok;
    const h24 = Math.max(0, h1 - fails * 0.05);
    const d7 = h24 + (100 - h24) * 0.34;
    const d30 = d7 + (100 - d7) * 0.42;
    l.uptime = { "1h": h1, "24h": h24, "7d": d7, "30d": d30 };
  }

  private pushCheck(l: Live, c: Check) {
    l.history = [...l.history, c].slice(-120);
    l.checkedAt = c.ts;
    l.code = c.code;
    l.latencyMs = c.latencyMs;
  }

  private runChecks() {
    const w = this.state;
    w.checkCount += 1;
    const n = w.checkCount;

    for (const p of w.projects) {
      const l = w.live[p.id];
      if (!p.enabled) {
        l.status = "DISABLED";
        continue;
      }
      const ts = Date.now();

      if (l.status === "STOPPED") {
        this.pushCheck(l, { ts, code: null, latencyMs: null, error: "process not running (intentional)" });
        this.recomputeUptime(l);
        continue;
      }

      if (l.status === "STARTING") {
        const ok = this.probeOk();
        l.probes += 1;
        this.pushCheck(l, {
          ts,
          code: ok ? 200 : null,
          latencyMs: ok ? Math.round((BASE[p.id] ?? 60) * 1.6) : null,
          error: ok ? null : `startup probe failed: ECONNREFUSED 127.0.0.1:${p.runtime.port ?? 80}`,
        });
        if (ok) {
          l.fails = 0;
          if (l.probes >= 2) {
            l.status = "UP";
            l.pid = 20000 + Math.floor(Math.random() * 9000);
            l.uptimeSec = 0;
            l.cpuPct = 2 + Math.random() * 6;
            l.memMB = 60 + Math.random() * 220;
            this.log(p.id, "ok", "startup probe ok · 3/3 · process reported healthy");
            this.log(p.id, "sys", `state → UP  pid=${l.pid}`);
            this.autoResolve(p.id, "startup probe passed 3/3");
          } else {
            this.log(p.id, "info", `startup probe ${l.probes}/3 ok`);
          }
        } else {
          this.log(p.id, "error", `startup probe failed: ECONNREFUSED 127.0.0.1:${p.runtime.port ?? 80}`);
          if (l.probes >= 3) this.exhaustStartup(p);
        }
        this.recomputeUptime(l);
        continue;
      }

      // running: UP / DEGRADED / DOWN
      const r = this.roll(p, n);
      if (r === "ok") {
        const lat = Math.round((BASE[p.id] ?? 60) + (Math.random() - 0.42) * ((BASE[p.id] ?? 60) * 0.7));
        this.pushCheck(l, { ts, code: 200, latencyMs: Math.max(2, lat), error: null });
        l.fails = 0;
        if (l.status === "DOWN") {
          l.status = "UP";
          l.pid = 20000 + Math.floor(Math.random() * 9000);
          this.log(p.id, "ok", "check recovered → 200 · auto-resolving incident");
          this.autoResolve(p.id, "3 consecutive OK checks");
        } else if (l.status === "DEGRADED") {
          l.status = "UP";
          this.log(p.id, "ok", "check ok → 200 · DEGRADED cleared");
          this.autoResolve(p.id, "status returned to expected code");
        } else if (n % 4 === 0) {
          this.log(p.id, "ok", `GET ${this.pathOf(p)} 200 ${lat}ms`);
        }
        if (l.uptimeSec !== null) l.uptimeSec += 30;
        l.cpuPct = Math.max(0.2, l.cpuPct + (Math.random() - 0.5) * 1.4);
        l.memMB = Math.max(8, l.memMB + (Math.random() - 0.5) * 6);
      } else {
        const code = r === "404" ? 404 : r === "502" ? 502 : null;
        const msg =
          r === "404"
            ? `unexpected status 404`
            : r === "502"
              ? "upstream returned 502"
              : r === "refused"
                ? `ECONNREFUSED 127.0.0.1:${p.runtime.port ?? 80}`
                : "ETIMEDOUT after 10000ms";
        this.pushCheck(l, { ts, code, latencyMs: null, error: msg });
        l.fails = Math.min(3, l.fails + 1);
        if (l.fails === 3) {
          if (l.status !== "DOWN") {
            l.status = code === 404 ? "DEGRADED" : "DOWN";
            this.log(p.id, code === 404 ? "warn" : "error", `3 consecutive failed checks → ${l.status}`);
            this.openIncident(p.id, `${code ?? "no"} response · ${msg}`, code === 404 ? "sev3" : "sev1");
            if (l.status === "DOWN" && p.runtime.autoRestart) this.maybeRestart(p);
          }
        } else if (l.status !== "DOWN") {
          l.status = "DEGRADED";
        }
        this.log(p.id, code === 404 ? "warn" : "error", `check failed: ${msg} (attempt ${l.fails}/3)`);
      }
      this.recomputeUptime(l);
    }
  }

  private probeOk() {
    // manual starts always succeed; crash-loop recovery is scripted in exhaustStartup
    return true;
  }

  private roll(p: Project, n: number): "ok" | "404" | "502" | "refused" | "timeout" {
    if (this.healed.has(p.id)) return Math.random() > 0.98 ? "timeout" : "ok";
    if (p.id === "digistream") return n % 14 < 9 ? "ok" : "404";
    if (p.id === "aurora-relay") return n % 23 === 0 ? "502" : "ok";
    if (p.id === "pulse-api") return "refused";
    if (p.id === "echoo-backend" && n % 37 === 0) return "timeout";
    return Math.random() > 0.985 ? "timeout" : "ok";
  }

  private pathOf(p: Project) {
    return p.runtime.healthUrl.replace(/^https?:\/\/[^/]+/, "") || "/";
  }

  private exhaustStartup(p: Project) {
    const l = this.state.live[p.id];
    l.probes = 0;
    l.restartAttempt += 1;
    l.restarts += 1;
    const max = p.runtime.maxRestarts ?? 3;
    if (l.restartAttempt >= max) {
      l.status = "DOWN";
      l.pid = null;
      l.cpuPct = 0;
      l.memMB = 0;
      this.log(p.id, "sys", `maxRestarts reached (${max}) → DOWN, incident stays open`);
      this.audit("system", "process.restart", p.id, `attempt ${l.restartAttempt}/${max} failed`, "fail");
    } else {
      l.status = "STARTING";
      this.log(p.id, "sys", `auto-restart attempt ${l.restartAttempt}/${max} → STARTING, probing health`);
      this.audit("system", "process.restart", p.id, `attempt ${l.restartAttempt}/${max}`, "fail");
    }
  }

  private maybeRestart(p: Project) {
    const l = this.state.live[p.id];
    l.restartAttempt = (l.restartAttempt || 0) + 1;
    const max = p.runtime.maxRestarts ?? 3;
    if (l.restartAttempt > max) {
      l.status = "DOWN";
      this.log(p.id, "sys", "restart policy exhausted · awaiting operator");
      return;
    }
    l.status = "STARTING";
    l.probes = 0;
    l.restarts += 1;
    this.log(p.id, "sys", `auto-restart ${l.restartAttempt}/${max} after 5s cooldown → STARTING`);
    this.audit("system", "process.restart", p.id, `auto-restart ${l.restartAttempt}/${max}`, "ok");
  }

  /* ─────────────────────────── incidents ─────────────────────────── */

  private openIncident(projectId: string, cause: string, severity: Incident["severity"]) {
    const w = this.state;
    const open = w.incidents.find((i) => i.projectId === projectId && i.state !== "resolved");
    if (open) return;
    const id = `INC-${1043 + w.incidents.filter((i) => i.id.startsWith("INC")).length}`;
    w.incidents = [
      {
        id,
        projectId,
        startedAt: Date.now(),
        resolvedAt: null,
        state: "open",
        cause,
        severity,
        recoveryAttempts: 0,
        timeline: [{ ts: Date.now(), text: "3 consecutive failed checks → incident opened" }],
      },
      ...w.incidents,
    ];
    this.log(projectId, "sys", `incident ${id} opened (${severity})`);
    const p = w.projects.find((x) => x.id === projectId);
    if (p?.notifications.down) {
      this.log(projectId, "sys", "telegram alert dispatched → @emmy (rule: DOWN > 60s)");
      this.audit("system", "notify.telegram", projectId, `${id} ${severity}`, "ok");
    }
  }

  private autoResolve(projectId: string, why: string) {
    const w = this.state;
    const i = w.incidents.find((x) => x.projectId === projectId && x.state !== "resolved");
    if (!i) return;
    i.state = "resolved";
    i.resolvedAt = Date.now();
    i.timeline = [...i.timeline, { ts: Date.now(), text: `auto-resolved — ${why}` }];
    this.log(projectId, "ok", `incident ${i.id} auto-resolved`);
  }

  ackIncident(incidentId: string, note?: string) {
    const w = this.state;
    const i = w.incidents.find((x) => x.id === incidentId);
    if (!i) return;
    i.state = "ack";
    i.acknowledgedBy = "emmy";
    if (note) i.note = note;
    i.timeline = [...i.timeline, { ts: Date.now(), text: `acknowledged by emmy${note ? ` — “${note}”` : ""}` }];
    this.audit("emmy", "incident.ack", i.projectId, `${incidentId}${note ? ` · ${note}` : ""}`, "ok");
    this.toast(`${incidentId} acknowledged`, "ok");
    this.emit();
  }

  resolveIncident(incidentId: string, note?: string) {
    const w = this.state;
    const i = w.incidents.find((x) => x.id === incidentId);
    if (!i) return;
    i.state = "resolved";
    i.resolvedAt = Date.now();
    if (note) i.note = note;
    i.timeline = [...i.timeline, { ts: Date.now(), text: `resolved manually by emmy${note ? ` — “${note}”` : ""}` }];
    this.audit("emmy", "incident.resolve", i.projectId, incidentId, "ok");
    this.toast(`${incidentId} resolved`, "ok");
    this.emit();
  }

  /* ───────────────────────── process control ─────────────────────── */

  private guard(): boolean {
    if (this.state.readOnly) {
      this.toast("read-only share link — control APIs disabled", "warn");
      return false;
    }
    return true;
  }

  start(id: string) {
    if (!this.guard()) return;
    const w = this.state;
    const p = w.projects.find((x) => x.id === id);
    const l = w.live[id];
    if (!p || !l || p.location.type !== "local") {
      this.toast("external project — control lives at the provider", "warn");
      return;
    }
    l.status = "STARTING";
    l.probes = 0;
    l.restartAttempt = 0;
    l.fails = 0;
    this.healed.add(id);
    this.log(id, "sys", `spawning › ${p.runtime.command} ${(p.runtime.args ?? []).join(" ")}  cwd=${p.location.cwd}`);
    this.log(id, "info", "startup probe window 20s · expecting 3× OK");
    this.audit("emmy", "process.start", id, `${p.runtime.command} ${(p.runtime.args ?? []).join(" ")}`, "ok");
    this.toast(`${p.name} → STARTING`, "info");
    this.emit();
  }

  stop(id: string) {
    if (!this.guard()) return;
    const w = this.state;
    const p = w.projects.find((x) => x.id === id);
    const l = w.live[id];
    if (!p || !l || p.location.type !== "local") return;
    this.log(id, "sys", `STOP requested by emmy — SIGTERM sent to pid ${l.pid ?? "?"}`);
    this.log(id, "ok", "graceful shutdown complete in 1.2s (0 in-flight)");
    l.status = "STOPPED";
    l.pid = null;
    l.cpuPct = 0;
    l.memMB = 0;
    l.fails = 0;
    this.audit("emmy", "process.stop", id, `SIGTERM pid ${l.pid ?? "?"}`, "ok");
    this.toast(`${p.name} stopped`, "warn");
    this.emit();
  }

  restart(id: string) {
    if (!this.guard()) return;
    const w = this.state;
    const p = w.projects.find((x) => x.id === id);
    const l = w.live[id];
    if (!p || !l || p.location.type !== "local") return;
    l.status = "STARTING";
    l.probes = 0;
    l.restartAttempt = 0;
    l.fails = 0;
    l.restarts += 1;
    this.healed.add(id);
    this.log(id, "sys", `restart → SIGTERM ${l.pid ?? "?"} · spawn ${p.runtime.command} ${(p.runtime.args ?? []).join(" ")}`);
    this.audit("emmy", "process.restart", id, "manual restart", "ok");
    this.toast(`${p.name} restarting`, "info");
    this.emit();
  }

  /* ───────────────────────────── deploy ──────────────────────────── */

  deploy(id: string, sha: "latest" | string = "latest") {
    if (!this.guard()) return;
    const w = this.state;
    const p = w.projects.find((x) => x.id === id);
    const l = w.live[id];
    if (!p || !l || p.location.type !== "local") {
      this.toast("external project — deep-link to provider instead", "warn");
      return;
    }
    if (w.pipeline) {
      this.toast("a deployment is already running", "warn");
      return;
    }
    const dep: Deployment = {
      id: ++deploySeq,
      projectId: id,
      sha: sha === "latest" ? "e4b2c19a7f3d5b8e1c0a9d8f7e6b5c4a" : sha,
      branch: p.source?.branch ?? "main",
      startedAt: Date.now(),
      endedAt: null as number | null,
      status: "running" as const,
      durationMs: 0,
      triggeredBy: "emmy (manual)",
      buildTail: [],
    };
    w.deployments = [dep, ...w.deployments];
    w.pipeline = {
      projectId: id,
      startedAt: Date.now(),
      log: [`deploy #${dep.id} · ${p.name} @ ${dep.sha.slice(0, 7)} (${dep.branch})`],
      stages: DEPLOY_STAGES.map((s, i) => ({ ...s, status: i === 0 ? "running" : "pending", ms: 0 })),
    };
    this.audit("emmy", "deploy", id, `sha ${sha} (${dep.branch})`, "ok");
    this.emit();

    let i = 0;
    const step = () => {
      const w2 = this.state;
      const pipe = w2.pipeline;
      if (!pipe || pipe.projectId !== id) return;
      const stage = pipe.stages[i];
      if (!stage) return;
      stage.status = "ok";
      pipe.log.push(...DEPLOY_STAGES[i].tail);
      dep.buildTail.push(...DEPLOY_STAGES[i].tail);
      const next = pipe.stages[i + 1];
      if (next) {
        next.status = "running";
        this.emit();
        i += 1;
        window.setTimeout(step, STAGE_MS[i]);
      } else {
        // health gate verdict
        const gateOk = w2.live[id].status !== "DOWN" || w2.live[id].restartAttempt < 3;
        if (!gateOk) {
          stage.status = "fail";
          pipe.log.push("› health gate FAILED after 20s");
          pipe.log.push("› rollback → checkout previous sha · restart · probe ok");
          dep.status = "rolled-back";
          dep.endedAt = Date.now();
          dep.buildTail.push("› health gate FAILED → rolled back");
          this.audit("system", "deploy.rollback", id, "health gate fail", "fail");
          this.toast(`deploy #${dep.id} failed — rolled back`, "err");
        } else {
          pipe.log.push("› health gate PASSED — deployment recorded");
          dep.status = "success";
          dep.endedAt = Date.now();
          dep.durationMs = Date.now() - dep.startedAt;
          dep.buildTail.push("› health gate PASSED");
          w2.live[id].sha = dep.sha;
          this.audit("system", "deploy.verify", id, "3/3 probes ok → success", "ok");
          this.toast(`deploy #${dep.id} · ${p.name} live @ ${dep.sha.slice(0, 7)}`, "ok");
        }
        w2.pipeline = null;
        this.emit();
      }
    };
    window.setTimeout(step, STAGE_MS[0]);
  }

  /* ───────────────────────────── exec ────────────────────────────── */

  exec(id: string, raw: string): { exitCode: number; stdout: string; stderr: string; truncated: boolean } {
    const w = this.state;
    const t = w.terminal[id] ?? { cwd: w.projects.find((p) => p.id === id)?.location.cwd ?? "", mode: "safe" as const, lines: [] };
    const t0 = performance.now();

    const denied = (why: string) => {
      this.audit("emmy", "exec", id, `${raw} — ${why}`, "denied");
      return { exitCode: 403, stdout: "", stderr: `403 FORBIDDEN — ${why}\nlogged to audit.json as "denied"`, truncated: false };
    };

    if (t.mode === "safe") {
      if(/[;&|`$><]/.test(raw)) return denied("chaining / redirection not permitted (spawned with shell:false)");
    }
    const parts = raw.trim().split(/\s+/).filter(Boolean);
    if (!parts.length) return { exitCode: 0, stdout: "", stderr: "", truncated: false };
    const cmd = parts[0];
    const args = parts.slice(1);

    if (t.mode === "safe" && !ALLOWLIST.includes(cmd)) {
      return denied(`"${cmd}" is not on the safe-mode allowlist — switch to Admin mode (audited) to run it`);
    }

    const out = this.fakeExec(id, cmd, args);
    const ms = Math.round(performance.now() - t0);
    t.lines.push(`› ${raw}`, ...(out.stdout ? out.stdout.split("\n") : []), ...(out.stderr ? out.stderr.split("\n") : []), `  ↳ exit ${out.exitCode} · ${ms}ms · 4.2kb/100kb`);
    w.terminal[id] = { ...t, lines: t.lines.slice(-260) };
    this.audit(t.mode === "admin" ? "emmy (admin)" : "emmy", "exec", id, raw, out.exitCode === 0 ? "ok" : "fail");
    this.emit();
    return out;
  }

  private fakeExec(id: string, cmd: string, args: string[]): { exitCode: number; stdout: string; stderr: string; truncated: boolean } {
    const p = this.state.projects.find((x) => x.id === id)!;
    const a = args.join(" ");
    const L = (...s: string[]) => s.join("\n");
    if (cmd === "git") {
      if (a.startsWith("log"))
        return { exitCode: 0, stdout: L("e4b2c19 (HEAD -> main) fix: raise db pool ceiling to 24", "a83f91d feat: retry sync on 503", "9f1c2bb chore: bump deps", "4d0e88 chore: pin psycopg2-binary"), stderr: "", truncated: false };
      if (a.startsWith("status"))
        return { exitCode: 0, stdout: L("On branch main", "Your branch is up to date with 'origin/main'.", "", "nothing to commit, working tree clean"), stderr: "", truncated: false };
      if (a.startsWith("diff")) return { exitCode: 0, stdout: L("diff --git a/src/pool.ts b/src/pool.ts", "- max: 12", "+ max: 24", "+ retryOnSaturation: true"), stderr: "", truncated: false };
      if (a.startsWith("rev-parse")) return { exitCode: 0, stdout: this.state.live[id].sha, stderr: "", truncated: false };
      return { exitCode: 0, stdout: L("usage: git [status|log|diff|rev-parse]"), stderr: "", truncated: false };
    }
    if (cmd === "ls") return { exitCode: 0, stdout: L(p.location.type === "local" ? "src/  tests/  package.json  .env  Dockerfile  README.md" : "(external project — no local cwd)"), stderr: "", truncated: false };
    if (cmd === "cat") return { exitCode: 0, stdout: L(`{`, `  "name": "${p.id}",`, `  "version": "2.4.1",`, `  "scripts": { "start": "node ./dist/index.js", "build": "tsc -p ." },`, `  "dependencies": { "express": "^4.19.2", "pg": "^8.11.5" }`, `}`), stderr: "", truncated: false };
    if (cmd === "node" || (cmd === "npm" && a.includes("-v"))) return { exitCode: 0, stdout: "v20.11.0", stderr: "", truncated: false };
    if (cmd === "python") return { exitCode: 0, stdout: "Python 3.11.8", stderr: "", truncated: false };
    if (cmd === "df") return { exitCode: 0, stdout: L("Filesystem      Size  Used Avail Use%", "/dev/mmcblk0p2  117G   84G   28G  75%", "tmpfs           3.9G  212M  3.7G   6%"), stderr: "", truncated: false };
    if (cmd === "ps") return { exitCode: 0, stdout: L("  PID  %CPU  %MEM  COMMAND", ` ${this.state.live[id].pid ?? "----"}   ${(this.state.live[id].cpuPct || 0).toFixed(1)}   2.1  ${p.runtime.command ?? "—"}`), stderr: "", truncated: false };
    if (cmd === "npm") {
      if (a.includes("test")) return { exitCode: 0, stdout: L("PASS  tests/auth.spec.ts (12)", "PASS  tests/sync.spec.ts (8)", "Tests: 20 passed, 20 total", "Snapshots: 0 total"), stderr: "", truncated: false };
      if (a.includes("build")) return { exitCode: 0, stdout: L("> tsc -p .", "✓ built in 3.4s · 0 errors"), stderr: "", truncated: false };
      if (a.includes("install")) return { exitCode: 0, stdout: L("added 214 packages, audited 214 in 3.4s", "found 0 vulnerabilities"), stderr: "", truncated: false };
      return { exitCode: 0, stdout: L("start · build · test · install"), stderr: "", truncated: false };
    }
    if (cmd === "curl") {
      const l = this.state.live[id];
      return { exitCode: 0, stdout: L(`HTTP/1.1 ${l.code ?? "000"} · ${l.latencyMs ?? "—"}ms`, `{"status":"${l.status.toLowerCase()}","database":"${l.status === "UP" ? "connected" : "unreachable"}"}`), stderr: "", truncated: false };
    }
    if (cmd === "tail") return { exitCode: 0, stdout: this.state.live[id].logs.slice(-10).map((x) => `${new Date(x.ts).toISOString().slice(11, 19)} ${x.msg}`).join("\n"), stderr: "", truncated: false };
    if (cmd === "grep") return { exitCode: 0, stdout: this.state.live[id].logs.filter((x) => x.msg.toLowerCase().includes(args[1] ?? "")).slice(-6).map((x) => x.msg).join("\n") || "(no matches)", stderr: "", truncated: false };
    if (cmd === "pip") return { exitCode: 0, stdout: L("Flask 3.0.3", "psycopg2-binary 2.9.9", "gunicorn 21.2.0"), stderr: "", truncated: false };
    if (cmd === "echo") return { exitCode: 0, stdout: args.join(" "), stderr: "", truncated: false };
    return { exitCode: 0, stdout: "(no output)", stderr: "", truncated: false };
  }

  setTerminalMode(id: string, mode: "safe" | "admin") {
    const w = this.state;
    const t = w.terminal[id];
    if (!t) return;
    w.terminal[id] = { ...t, mode };
    t.lines.push(
      mode === "admin"
        ? "⚠ ADMIN MODE — free shell granted for this session. every command is written to audit.json."
        : "✓ SAFE MODE — allowlisted tools only, cwd jail active, 30s timeout, 100kb cap.",
    );
    this.audit("emmy", "terminal.mode", id, `→ ${mode}`, "ok");
    this.emit();
  }

  clearTerminal(id: string) {
    const t = this.state.terminal[id];
    if (!t) return;
    this.state.terminal[id] = { ...t, lines: [`server-dashboard › ${t.mode} terminal · cwd jail: ${t.cwd}`] };
    this.emit();
  }

  /* ─────────────────────────────── ai ────────────────────────────── */

  ask(id: string, question: string) {
    const w = this.state;
    w.ai = { ...w.ai, [id]: { busy: true, q: question, d: w.ai[id]?.d } };
    this.audit("ai:opencode", "ai.ask", id, question, "ok");
    this.emit();
    window.setTimeout(() => {
      const w2 = this.state;
      const l = w2.live[id];
      const d = this.diagnose(id, question, l.status);
      w2.ai = { ...w2.ai, [id]: { busy: false, q: question, d } };
      this.log(id, "sys", `ai diagnose → ${d.severity} · confidence ${Math.round(d.confidence * 100)}%`);
      this.emit();
    }, 1500);
  }

  private diagnose(id: string, q: string, status: Status): AiDiagnosis {
    if (id === "pulse-api")
      return {
        severity: "critical",
        likelyCause: "Postgres at 10.0.0.14:5432 is unreachable, so the Flask worker throws on startup and the process exits before binding :8800.",
        confidence: 0.92,
        evidence: [
          "log: psycopg2 OperationalError: could not connect to server: Connection refused",
          "log: startup probe failed: ECONNREFUSED 127.0.0.1:8800 (3/3)",
          "status: DOWN · 16 consecutive failed checks · restarts=7",
          "registry: autoRestart=true, maxRestarts=3 → policy exhausted",
          "deploy #15 was rolled back at 40h ago — not a code regression (same sha range)",
        ],
        recommendedActions: [
          "Verify the database host is reachable from this box: check_port 10.0.0.14:5432",
          "If the DB moved, update DATABASE_HOST in /root/projects/pulse-api/.env",
          "Restart the project once the socket answers, then confirm 3× OK on /healthz",
        ],
        commands: ["psql -h 10.0.0.14 -p 5432 -c 'select 1'", "cat .env | grep DATABASE_HOST"],
        safeToAutoFix: true,
        summary: "Downstream dependency, not the app. The process is fine; the database is not answering.",
        model: "opencode · sonnet-4.5",
      };
    if (id === "digistream")
      return {
        severity: "high",
        likelyCause: "Vercel is serving 404 on the production alias — the last deploy likely removed the catch-all rewrite in vercel.json.",
        confidence: 0.78,
        evidence: [
          "3 consecutive 404 responses from https://digistream.vercel.app",
          "latency is normal (~220ms), so the edge function is alive — routing is the problem",
          "registry: location.type=external → no local restart possible, control lives at Vercel",
        ],
        recommendedActions: [
          "Open the Vercel deployment and compare rewrites/redirects against the previous good build",
          "Redeploy the previous deployment from the Vercel dashboard",
          "Add monitoring.expectedBody check so config drift is caught as DEGRADED, not silence",
        ],
        commands: ["vercel inspect digistream", "vercel logs digistream --output json"],
        safeToAutoFix: false,
        summary: "Config drift at the provider. Nothing to restart locally — this is a link-out and a redeploy.",
        model: "opencode · sonnet-4.5",
      };
    if (id === "ghost-mailer")
      return {
        severity: "low",
        likelyCause: "The process was stopped deliberately (autoRestart=false) after the SMTP quota hit 1000/1000.",
        confidence: 0.96,
        evidence: ["log: SMTP quota 100% used (1000/1000)", "audit: process.stop by emmy — SIGTERM pid 15230", "registry: autoRestart=false, startOnBoot=false"],
        recommendedActions: ["Reset the SMTP provider quota or switch to a pooled sender", "Then start the process from the dashboard"],
        commands: ["curl -s https://api.mailer.dev/quota -H 'auth: ‹redacted›'"],
        safeToAutoFix: true,
        summary: "Intentional stop, not an outage. No action taken without you.",
        model: "opencode · sonnet-4.5",
      };
    if (status !== "UP")
      return {
        severity: "medium",
        likelyCause: `Intermittent failures on the health endpoint — recent checks returned ${"non-2xx"} while the process stayed alive.`,
        confidence: 0.64,
        evidence: ["status: " + status, "latency spiked above p95 in the last window", "no exit events in the log"],
        recommendedActions: ["Tail the last 200 log lines for the failing route", "Restart the process if errors continue for another window"],
        commands: ["tail -n 200 logs/" + id + ".log", "npm run test -- --silent"],
        safeToAutoFix: true,
        summary: "Degraded but alive. Restart is the cheapest reversible action.",
        model: "opencode · sonnet-4.5",
      };
    return {
      severity: "low",
      likelyCause: "No anomaly found. Checks are green, latency inside the normal band, no restarts in the last 24h.",
      confidence: 0.88,
      evidence: ["status: UP", "latency within p50–p95 band", "0 failed checks in the current window", "uptime 24h above fleet median"],
      recommendedActions: ["Nothing to do — this is informational", `Ask a sharper question, e.g. “why was ${id} slow at 03:00?”`],
      commands: ["tail -n 200 logs/" + id + ".log"],
      safeToAutoFix: false,
      summary: `Regarding “${q}” — I have no evidence of a problem right now.`,
      model: "opencode · sonnet-4.5",
    };
  }

  executeTool(id: string, tool: string) {
    if (!this.guard()) return;
    const w = this.state;
    const cur = w.ai[id];
    if (cur) w.ai = { ...w.ai, [id]: { ...cur, d: cur.d } };
    this.audit("ai:opencode", "ai.execute", id, `tool ${tool} (confirmed)`, "ok");
    this.log(id, "sys", `ai execute → tool ${tool} (confirmed by operator)`);
    if (tool === "restart_project") this.restart(id);
    else if (tool === "deploy_project") this.deploy(id);
    else if (tool === "run_safe_command") this.exec(id, "tail -n 50 logs/" + id + ".log");
    this.toast(`AI tool executed · ${tool}`, "ok");
    this.emit();
  }

  /* ─────────────────────────── registry ─────────────────────────── */

  addProject(input: { id: string; name: string; type: EnvType; healthUrl: string; port?: number; command?: string; provider?: "vercel" | "railway" | "render" | "other" }) {
    const w = this.state;
    if (!/^[a-z0-9-]{2,40}$/.test(input.id)) {
      this.toast("id must match ^[a-z0-9-]{2,40}$", "err");
      return false;
    }
    if (w.projects.some((p) => p.id === input.id)) {
      this.toast("id already exists — ids are stable and unique", "err");
      return false;
    }
    if (!/^https?:\/\//.test(input.healthUrl)) {
      this.toast("healthUrl must be http(s)://…", "err");
      return false;
    }
    const proj: Project = {
      id: input.id,
      name: input.name || input.id,
      enabled: true,
      template: input.type === "local" ? "node-api" : "other",
      location:
        input.type === "local"
          ? { type: "local", agentId: "local", cwd: `/root/projects/${input.id}` }
          : { type: "external", agentId: "local", provider: input.provider ?? "other" },
      runtime:
        input.type === "local"
          ? {
              command: input.command || "npm",
              args: ["run", "start"],
              port: input.port,
              healthUrl: input.healthUrl,
              autoRestart: true,
              maxRestarts: 3,
              startOnBoot: false,
            }
          : { healthUrl: input.healthUrl, autoRestart: false },
      monitoring: { intervalSeconds: 30, timeoutSeconds: 10, expectedStatus: [200] },
      notifications: { down: true, recovered: true },
      tags: ["new"],
    };
    w.projects = [...w.projects, proj];
    w.live = {
      ...w.live,
      [input.id]: {
        status: input.type === "local" ? "STOPPED" : "UP",
        code: null,
        latencyMs: null,
        checkedAt: Date.now(),
        uptime: { "1h": 100, "24h": 100, "7d": 100, "30d": 100 },
        restarts: 0,
        pid: null,
        cpuPct: 0,
        memMB: 0,
        uptimeSec: 0,
        probes: 0,
        fails: 0,
        restartAttempt: 0,
        sha: "undeployed",
        history: [],
        logs: [{ ts: Date.now(), level: "sys", msg: `registered via POST /api/projects → id=${input.id}` }],
      },
    };
    w.terminal[input.id] = { cwd: proj.location.cwd ?? "—", mode: "safe", lines: [`server-dashboard › safe terminal · cwd jail: ${proj.location.cwd ?? "n/a"}`] };
    this.audit("emmy", "project.create", input.id, `${input.type} · ${input.healthUrl}`, "ok");
    this.toast(`${proj.name} registered`, "ok");
    this.emit();
    return true;
  }

  removeProject(id: string) {
    if (!this.guard()) return;
    const w = this.state;
    const p = w.projects.find((x) => x.id === id);
    w.projects = w.projects.filter((x) => x.id !== id);
    const live = { ...w.live };
    delete live[id];
    w.live = live;
    w.deployments = w.deployments.filter((d) => d.projectId !== id);
    w.incidents = w.incidents.filter((i) => i.projectId !== id);
    this.audit("emmy", "project.delete", id, `${p?.name ?? id} — process stopped first`, "ok");
    this.toast(`${p?.name ?? id} removed from registry`, "warn");
    this.emit();
  }

  applyRegistry(json: string): { ok: boolean; error?: string; count?: number } {
    const w = this.state;
    let parsed: { projects?: Project[] };
    try {
      parsed = JSON.parse(json);
    } catch (e) {
      return { ok: false, error: `invalid JSON — ${(e as Error).message}` };
    }
    if (!parsed.projects || !Array.isArray(parsed.projects)) return { ok: false, error: "missing `projects[]` array" };
    const ids = parsed.projects.map((p) => p.id);
    if (new Set(ids).size !== ids.length) return { ok: false, error: "duplicate id — ids must be unique" };
    for (const p of parsed.projects) {
      if (!/^[a-z0-9-]{2,40}$/.test(p.id ?? "")) return { ok: false, error: `id "${p.id}" must match ^[a-z0-9-]{2,40}$` };
      if (!/^https?:\/\//.test(p.runtime?.healthUrl ?? "")) return { ok: false, error: `${p.id}: runtime.healthUrl must be http(s)://…` };
      if (p.location?.type === "local" && p.runtime?.port && (p.runtime.port < 1024 || p.runtime.port > 65535))
        return { ok: false, error: `${p.id}: port must be 1024–65535` };
    }
    const live = { ...w.live };
    for (const p of parsed.projects) {
      if (!live[p.id]) {
        live[p.id] = {
          status: p.location.type === "local" ? "STOPPED" : "UP",
          code: null,
          latencyMs: null,
          checkedAt: Date.now(),
          uptime: { "1h": 100, "24h": 100, "7d": 100, "30d": 100 },
          restarts: 0,
          pid: null,
          cpuPct: 0,
          memMB: 0,
          uptimeSec: 0,
          probes: 0,
          fails: 0,
          restartAttempt: 0,
          sha: p.source ? "unknown" : "external",
          history: [],
          logs: [{ ts: Date.now(), level: "sys", msg: `loaded from projects.json → id=${p.id}` }],
        };
        w.terminal[p.id] = {
          cwd: p.location.cwd ?? "—",
          mode: "safe",
          lines: [`server-dashboard › safe terminal · cwd jail: ${p.location.cwd ?? "n/a (external)"}`],
        };
      }
    }
    w.projects = parsed.projects;
    w.live = live;
    this.audit("emmy", "registry.apply", "control-plane", `${parsed.projects.length} projects validated`, "ok");
    this.toast(`registry applied · ${parsed.projects.length} projects`, "ok");
    this.emit();
    return { ok: true, count: parsed.projects.length };
  }

  toggleProject(id: string) {
    if (!this.guard()) return;
    const w = this.state;
    w.projects = w.projects.map((p) => (p.id === id ? { ...p, enabled: !p.enabled } : p));
    this.audit("emmy", "project.patch", id, `enabled=${!w.projects.find((p) => p.id === id)?.enabled}`, "ok");
    this.emit();
  }

  /* ───────────────────────── derived ───────────────────────────── */

  stats() {
    const w = this.state;
    const live = w.projects.map((p) => w.live[p.id]).filter(Boolean);
    const up = live.filter((l) => l.status === "UP").length;
    const degraded = live.filter((l) => l.status === "DEGRADED").length;
    const down = live.filter((l) => l.status === "DOWN").length;
    const stopped = live.filter((l) => l.status === "STOPPED" || l.status === "DISABLED").length;
    const local = w.projects.filter((p) => p.location.type === "local").length;
    const external = w.projects.length - local;
    const open = w.incidents.filter((i) => i.state !== "resolved").length;
    const fleet = live.length ? (up / live.length) * 100 : 100;
    const lat = live.filter((l) => l.latencyMs).map((l) => l.latencyMs!);
    const p50 = lat.length ? lat.sort((a, b) => a - b)[Math.floor(lat.length / 2)] : 0;
    const p95 = lat.length ? lat.sort((a, b) => a - b)[Math.floor(lat.length * 0.95)] : 0;
    return { up, degraded, down, stopped, local, external, open, fleet, p50, p95, total: live.length, checks: w.checkCount };
  }

  filtered() {
    const w = this.state;
    const q = w.filter.trim().toLowerCase();
    return w.projects.filter((p) => {
      const l = w.live[p.id];
      if (!l) return false;
      if (w.statusFilter !== "ALL" && l.status !== w.statusFilter) return false;
      if (w.envFilter !== "ALL" && p.location.type !== w.envFilter) return false;
      if (!q) return true;
      return (
        p.id.includes(q) ||
        p.name.toLowerCase().includes(q) ||
        (p.tags ?? []).some((t) => t.includes(q)) ||
        p.runtime.healthUrl.toLowerCase().includes(q) ||
        (p.location.cwd ?? "").includes(q)
      );
    });
  }
}

export const store = new Store();

export function useStore(): World {
  return useSyncExternalStore(store.subscribe, store.get, store.get);
}

export const THEMES: { key: ThemeName; name: string; material: string; structure: string; feeling: string; note: string }[] = [
  {
    key: "precision",
    name: "Precision",
    material: "paper",
    structure: "swiss · financial",
    feeling: "quiet · precise",
    note: "hairline rules, tabular figures, asymmetric 12-col",
  },
  {
    key: "terminal",
    name: "Terminal",
    material: "phosphor glass",
    structure: "dense · brutalist",
    feeling: "tactical",
    note: "monospace everywhere, 26px grid, scanlines",
  },
  {
    key: "glass",
    name: "Glass",
    material: "smoked glass",
    structure: "spacious · editorial",
    feeling: "premium · playful",
    note: "blurred depth, serif numerals, wide gutters",
  },
  {
    key: "industrial",
    name: "Industrial",
    material: "concrete panel",
    structure: "brutalist",
    feeling: "tactical · playful",
    note: "2px rules, hard offset shadows, hazard stripes",
  },
];
