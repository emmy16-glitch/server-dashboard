import type { AuditEntry, Check, Deployment, Incident, Live, LogLine, Project, Range } from "./types";

const NOW = Date.now();

/* ───────────────────────── registry (projects.json) ───────────────────── */

export const AGENT = { id: "local", hostname: "pixel-server", platform: "android/proot · node v20.11.0" };

export const SEED_PROJECTS: Project[] = [
  {
    id: "echoo-backend",
    name: "Echoo Backend",
    enabled: true,
    template: "node-api",
    note: "primary API — auth + sync",
    location: { type: "local", agentId: "local", cwd: "/root/Software_projects/echoo/backend" },
    runtime: {
      command: "npm",
      args: ["run", "start"],
      port: 8000,
      healthUrl: "http://localhost:8000/health",
      autoRestart: true,
      maxRestarts: 5,
      restartCooldownSec: 5,
      startOnBoot: true,
      startupTimeoutSec: 20,
      envFile: ".env",
    },
    source: { provider: "github", repository: "owner/echoo", branch: "main", deployOnPush: false },
    monitoring: {
      intervalSeconds: 30,
      timeoutSeconds: 10,
      expectedStatus: [200, 301, 302],
      expectedBody: null,
      healthConfig: { type: "http", json: { database: "connected" } },
    },
    notifications: { down: true, recovered: true, deploymentFailed: true, crashLoop: true },
    tags: ["api", "prod"],
  },
  {
    id: "echoo-web",
    name: "Echoo Web",
    enabled: true,
    template: "next-js",
    note: "marketing + app shell",
    location: { type: "local", agentId: "local", cwd: "/root/Software_projects/echoo/web" },
    runtime: {
      command: "npm",
      args: ["run", "start"],
      port: 3000,
      healthUrl: "http://localhost:3000/api/health",
      autoRestart: true,
      maxRestarts: 3,
      restartCooldownSec: 5,
      startOnBoot: true,
      startupTimeoutSec: 25,
      envFile: ".env.production",
    },
    source: { provider: "github", repository: "owner/echoo", branch: "main", deployOnPush: true },
    monitoring: { intervalSeconds: 30, timeoutSeconds: 10, expectedStatus: [200] },
    notifications: { down: true, recovered: true, deploymentFailed: true },
    tags: ["web"],
  },
  {
    id: "pulse-api",
    name: "Pulse API",
    enabled: true,
    template: "flask",
    note: "cron + webhooks, flaky deps",
    location: { type: "local", agentId: "local", cwd: "/root/projects/pulse-api" },
    runtime: {
      command: "python",
      args: ["app.py"],
      port: 8800,
      healthUrl: "http://localhost:8800/healthz",
      autoRestart: true,
      maxRestarts: 3,
      restartCooldownSec: 5,
      startOnBoot: false,
      startupTimeoutSec: 20,
      envFile: ".env",
    },
    source: { provider: "github", repository: "owner/pulse-api", branch: "main" },
    monitoring: { intervalSeconds: 30, timeoutSeconds: 10, expectedStatus: [200] },
    notifications: { down: true, recovered: true, crashLoop: true },
    tags: ["api", "python"],
  },
  {
    id: "ghost-mailer",
    name: "Ghost Mailer",
    enabled: true,
    template: "node-api",
    note: "stopped — SMTP quota exhausted",
    location: { type: "local", agentId: "local", cwd: "/root/projects/ghost-mailer" },
    runtime: {
      command: "node",
      args: ["server.js"],
      port: 5005,
      healthUrl: "http://localhost:5005/health",
      autoRestart: false,
      maxRestarts: 3,
      restartCooldownSec: 5,
      startOnBoot: false,
      startupTimeoutSec: 15,
      envFile: ".env",
    },
    source: { provider: "github", repository: "owner/ghost-mailer", branch: "main" },
    monitoring: { intervalSeconds: 60, timeoutSeconds: 10, expectedStatus: [200] },
    notifications: { down: false, recovered: true },
    tags: ["worker"],
  },
  {
    id: "control-plane",
    name: "server-dashboard",
    enabled: true,
    template: "node-api",
    note: "this dashboard — :3001",
    location: { type: "local", agentId: "local", cwd: "/root/projects/server-dashboard" },
    runtime: {
      command: "node",
      args: ["server/index.js"],
      port: 3001,
      healthUrl: "http://localhost:3001/api/health",
      autoRestart: true,
      maxRestarts: 5,
      restartCooldownSec: 5,
      startOnBoot: true,
      startupTimeoutSec: 20,
    },
    source: { provider: "github", repository: "emmy16-glitch/server-dashboard", branch: "main" },
    monitoring: { intervalSeconds: 30, timeoutSeconds: 5, expectedStatus: [200] },
    notifications: { down: true, recovered: true, crashLoop: true },
    tags: ["infra"],
  },
  {
    id: "digistream",
    name: "DigiStream",
    enabled: true,
    template: "vercel",
    note: "edge deployment — control lives at provider",
    location: { type: "external", agentId: "local", provider: "vercel" },
    runtime: { healthUrl: "https://digistream.vercel.app", autoRestart: false },
    monitoring: { intervalSeconds: 60, timeoutSeconds: 10, expectedStatus: [200] },
    notifications: { down: true, recovered: true },
    tags: ["edge"],
  },
  {
    id: "cv-forge",
    name: "CV Forge",
    enabled: true,
    template: "vercel",
    location: { type: "external", agentId: "local", provider: "vercel" },
    runtime: { healthUrl: "https://cv-forge.vercel.app", autoRestart: false },
    monitoring: { intervalSeconds: 60, timeoutSeconds: 10, expectedStatus: [200, 301] },
    notifications: { down: true, recovered: true },
    tags: ["edge"],
  },
  {
    id: "aurora-relay",
    name: "Aurora Relay",
    enabled: true,
    template: "other",
    note: "websocket relay — render.com",
    location: { type: "external", agentId: "local", provider: "render" },
    runtime: { healthUrl: "https://aurora-relay.onrender.com/health", autoRestart: false },
    monitoring: { intervalSeconds: 60, timeoutSeconds: 15, expectedStatus: [200] },
    notifications: { down: true, recovered: true },
    tags: ["edge", "ws"],
  },
];

/* ───────────────────────────── history synth ──────────────────────────── */

const rng = (seed: number) => () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);

function synth(opts: {
  n: number;
  base: number;
  spread: number;
  fails: number[]; // indices that fail
  codes?: Record<number, number>;
}): Check[] {
  const r = rng(opts.n * 7919 + opts.base);
  const out: Check[] = [];
  for (let i = 0; i < opts.n; i++) {
    const ts = NOW - (opts.n - i) * 30_000;
    if (opts.fails.includes(i)) {
      const code = opts.codes?.[i] ?? null;
      out.push({
        ts,
        code,
        latencyMs: null,
        error: code === null ? "ETIMEDOUT after 10000ms" : code === 404 ? "unexpected status 404" : "socket hang up",
      });
    } else {
      out.push({ ts, code: 200, latencyMs: Math.round(opts.base + (r() - 0.4) * opts.spread), error: null });
    }
  }
  return out;
}

function uptimeFrom(checks: Check[], window: number, mult = 1) {
  const slice = checks.slice(-Math.round(window * mult));
  if (!slice.length) return 100;
  const ok = slice.filter((c) => c.code === 200).length;
  return (ok / slice.length) * 100;
}

function liveOf(
  init: {
    status: Live["status"];
    base: number;
    spread: number;
    fails: number[];
    codes?: Record<number, number>;
    restarts: number;
    pid?: number | null;
    cpu?: number;
    mem?: number;
    up?: number;
    sha: string;
    logs: LogLine[];
  },
): Live {
  const history = synth({ n: 120, base: init.base, spread: init.spread, fails: init.fails, codes: init.codes });
  const last = history[history.length - 1];
  const ok = last.code === 200;
  return {
    status: init.status,
    code: ok ? 200 : last.code,
    latencyMs: ok ? last.latencyMs : null,
    checkedAt: last.ts,
    uptime: {
      "1h": uptimeFrom(history, 120),
      "24h": uptimeFrom(history, 120, 3.4) - (init.fails.length ? init.fails.length * 0.04 : 0),
      "7d": uptimeFrom(history, 120, 7) - (init.fails.length ? init.fails.length * 0.09 : 0),
      "30d": uptimeFrom(history, 120, 12) - (init.fails.length ? init.fails.length * 0.15 : 0),
    } as Record<Range, number>,
    restarts: init.restarts,
    pid: init.pid ?? null,
    cpuPct: init.cpu ?? 0,
    memMB: init.mem ?? 0,
    uptimeSec: init.up ?? 0,
    probes: 0,
    fails: init.fails.slice(-3).length,
    restartAttempt: init.status === "DOWN" ? 3 : 0,
    sha: init.sha,
    history,
    logs: init.logs,
  };
}

const L = (secAgo: number, level: LogLine["level"], msg: string): LogLine => ({
  ts: NOW - secAgo * 1000,
  level,
  msg,
});

const REDACT = "‹redacted›";

export const SEED_LIVE: Record<string, Live> = {
  "echoo-backend": liveOf({
    status: "UP",
    base: 42,
    spread: 26,
    fails: [37, 38],
    codes: { 37: 503, 38: 503 },
    restarts: 2,
    pid: 18422,
    cpu: 3.4,
    mem: 148.2,
    up: 5 * 86400 + 3 * 3600 + 1220,
    sha: "a83f91dc44be1f9a2c7e5d0b6a19f8c3",
    logs: [
      L(2880, "sys", "spawning › npm run start  cwd=/root/Software_projects/echoo/backend"),
      L(2878, "info", "> echoo-backend@2.4.1 start"),
      L(2877, "info", "> node ./dist/index.js"),
      L(2870, "info", "listening on :8000  env=production  pid=18422"),
      L(2865, "ok", 'health probe ok  200  {"database":"connected","queue":"up"}'),
      L(640, "warn", "GET /api/sync 503 — upstream db pool saturated (12/12)"),
      L(638, "warn", "GET /api/sync 503 — upstream db pool saturated (12/12)"),
      L(620, "ok", "pool recovered, 11 idle connections"),
      L(42, "ok", "GET /health 200 41ms"),
      L(12, "info", "token=" + REDACT + " issued for session 9f2a (masked)"),
    ],
  }),
  "echoo-web": liveOf({
    status: "UP",
    base: 88,
    spread: 40,
    fails: [],
    restarts: 0,
    pid: 19055,
    cpu: 5.1,
    mem: 312.7,
    up: 2 * 86400 + 7 * 3600 + 44,
    sha: "1c7b0e4f9a2210dd5e4c1b7a83f2ea5d",
    logs: [
      L(7200, "sys", "spawning › npm run start  cwd=/root/Software_projects/echoo/web"),
      L(7195, "info", "▲ Next.js 14.2.4  ready on :3000"),
      L(7190, "ok", "compiled /  /api/health  in 412ms"),
      L(300, "info", "GET / 200 84ms  cache=HIT"),
      L(30, "ok", "GET /api/health 200 91ms"),
    ],
  }),
  "pulse-api": liveOf({
    status: "DOWN",
    base: 240,
    spread: 180,
    fails: [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119],
    restarts: 7,
    pid: null,
    cpu: 0,
    mem: 0,
    up: 0,
    sha: "5e2ab90c7f31d0b8a6c4e2f19d70b3aa",
    logs: [
      L(2400, "sys", "spawning › python app.py  cwd=/root/projects/pulse-api"),
      L(2394, "info", " * Serving Flask app 'pulse' (lazy loading)"),
      L(2393, "info", " * Running on http://0.0.0.0:8800"),
      L(920, "error", "Traceback (most recent call last):"),
      L(920, "error", '  File "app.py", line 214, in worker'),
      L(920, "error", "    conn = pool.get_connection(timeout=5)"),
      L(920, "error", "psycopg2 OperationalError: could not connect to server: Connection refused"),
      L(919, "error", "    Is the server running on host '10.0.0.14' and accepting"),
      L(919, "error", "    TCP/IP connections on port 5432?"),
      L(918, "sys", "process exited code=1 signal=null — auto-restart 1/3 in 5s"),
      L(880, "sys", "restart attempt 2/3 → STARTING, probing /healthz (20s)"),
      L(860, "error", "startup probe failed: ECONNREFUSED 127.0.0.1:8800"),
      L(700, "sys", "restart attempt 3/3 → STARTING, probing /healthz (20s)"),
      L(640, "error", "startup probe failed: ECONNREFUSED 127.0.0.1:8800"),
      L(639, "sys", "maxRestarts reached (3) → DOWN, incident INC-1042 opened"),
      L(639, "sys", "telegram alert dispatched → @emmy"),
      L(20, "error", "check failed: ECONNREFUSED 127.0.0.1:8800 (attempt 3/3)"),
    ],
  }),
  "ghost-mailer": liveOf({
    status: "STOPPED",
    base: 60,
    spread: 20,
    fails: [110, 111, 112, 113, 114, 115, 116, 117, 119],
    restarts: 1,
    pid: null,
    cpu: 0,
    mem: 0,
    up: 0,
    sha: "b71ce0a99d2c4f8e1a3b7d0c5f6e8a21",
    logs: [
      L(9000, "sys", "STOP requested by emmy — SIGTERM sent to pid 15230"),
      L(8998, "ok", "graceful shutdown complete in 1.4s (0 in-flight)"),
      L(8997, "sys", "process stopped — no auto-restart (autoRestart=false)"),
      L(5000, "warn", "before stop: SMTP quota 100% used (1000/1000)"),
    ],
  }),
  "control-plane": liveOf({
    status: "UP",
    base: 6,
    spread: 4,
    fails: [],
    restarts: 0,
    pid: 1201,
    cpu: 1.2,
    mem: 62.4,
    up: 11 * 3600 + 40 * 60,
    sha: "0d41f7b2c8e9a1d5f3b7a0c6e2d8f411",
    logs: [
      L(42000, "sys", "registry loaded › 8 projects (5 local / 3 external)"),
      L(42000, "sys", "auth: bearer token required on /api/*  (except /api/health)"),
      L(42000, "sys", "health-monitor loop started › interval 30s  timeout 10s"),
      L(600, "ok", "wrote status-history.json (24,812 checks retained)"),
      L(30, "ok", "GET /api/health 200 5ms"),
      L(4, "ok", "SSE 2 clients /api/logs/echoo-backend/stream"),
    ],
  }),
  digistream: liveOf({
    status: "DEGRADED",
    base: 210,
    spread: 140,
    fails: [88, 89, 90, 116, 117, 118, 119],
    codes: { 88: 404, 89: 404, 90: 404, 116: 404, 117: 404, 118: 404, 119: 404 },
    restarts: 0,
    sha: "external",
    logs: [
      L(4000, "sys", "external check › https://digistream.vercel.app"),
      L(1800, "ok", "200 in 198ms — edge: iad1"),
      L(240, "error", "GET https://digistream.vercel.app 404 in 232ms"),
      L(180, "error", "GET https://digistream.vercel.app 404 in 268ms"),
      L(120, "error", "GET https://digistream.vercel.app 404 in 219ms"),
      L(60, "sys", "3 consecutive non-2xx → DEGRADED (kept for AI context)"),
      L(59, "sys", "no local control: location.type=external → link-out only"),
    ],
  }),
  "cv-forge": liveOf({
    status: "UP",
    base: 120,
    spread: 60,
    fails: [12],
    codes: { 12: 301 },
    restarts: 0,
    sha: "external",
    logs: [
      L(3600, "sys", "external check › https://cv-forge.vercel.app"),
      L(30, "ok", "301 → 200 in 118ms — edge: fra1"),
    ],
  }),
  "aurora-relay": liveOf({
    status: "UP",
    base: 340,
    spread: 190,
    fails: [55, 56],
    codes: { 55: 502, 56: 502 },
    restarts: 0,
    sha: "external",
    logs: [
      L(3600, "sys", "external check › https://aurora-relay.onrender.com/health"),
      L(1200, "warn", "502 — render cold start (free tier spin-up)"),
      L(900, "ok", "recovered 200 in 366ms"),
      L(30, "ok", "200 in 341ms  ws clients=14"),
    ],
  }),
};

/* ───────────────────────────── deployments ────────────────────────────── */

export const SEED_DEPLOYMENTS: Deployment[] = [
  {
    id: 18,
    projectId: "echoo-backend",
    sha: "a83f91dc44be1f9a2c7e5d0b6a19f8c3",
    branch: "main",
    startedAt: NOW - 6 * 3600_000,
    endedAt: NOW - 6 * 3600_000 + 74_000,
    status: "success",
    durationMs: 74_000,
    triggeredBy: "emmy (manual)",
    buildTail: [
      "› git fetch origin main",
      "› HEAD is now at a83f91d feat: retry sync on 503",
      "› npm install --omit=dev  (214 packages, 3.1s)",
      "› npm run build  → tsc ok, 0 errors",
      "› pre-deploy: npm run migrate  (2 migrations applied)",
      "› restart → pid 18422, probe 3/3 ok",
      "› post-deploy: warm /api/sync cache",
      "› health gate PASSED — deployment #18 recorded",
    ],
  },
  {
    id: 17,
    projectId: "echoo-backend",
    sha: "9f1c2bba04d7e8c1a3f5b6d7e8f9a0b1",
    branch: "main",
    startedAt: NOW - 31 * 3600_000,
    endedAt: NOW - 31 * 3600_000 + 61_000,
    status: "success",
    durationMs: 61_000,
    triggeredBy: "emmy (manual)",
    buildTail: ["› git fetch origin main", "› npm install (no change)", "› build ok", "› health gate PASSED"],
  },
  {
    id: 16,
    projectId: "echoo-web",
    sha: "1c7b0e4f9a2210dd5e4c1b7a83f2ea5d",
    branch: "main",
    startedAt: NOW - 2 * 86400_000,
    endedAt: NOW - 2 * 86400_000 + 132_000,
    status: "success",
    durationMs: 132_000,
    triggeredBy: "push → owner/echoo",
    buildTail: ["› next build  (28 routes)", "› probe ok 3/3", "› health gate PASSED"],
  },
  {
    id: 15,
    projectId: "pulse-api",
    sha: "5e2ab90c7f31d0b8a6c4e2f19d70b3aa",
    branch: "main",
    startedAt: NOW - 40 * 3600_000,
    endedAt: NOW - 40 * 3600_000 + 44_000,
    status: "rolled-back",
    durationMs: 44_000,
    triggeredBy: "emmy (manual)",
    buildTail: [
      "› git fetch origin main",
      "› pip install -r requirements.txt (ok)",
      "› restart → probe 1/3 fail, 2/3 fail, 3/3 fail",
      "› health gate FAILED after 20s",
      "› rollback → checkout 4d0e88a1, restart, probe ok",
      "› deployment #15 marked failed + rolled back",
    ],
  },
];

/* ───────────────────────────── incidents ──────────────────────────────── */

export const SEED_INCIDENTS: Incident[] = [
  {
    id: "INC-1042",
    projectId: "pulse-api",
    startedAt: NOW - 15 * 60_000,
    resolvedAt: null,
    state: "open",
    cause: "DB unreachable: could not connect to 10.0.0.14:5432 — crash loop, 3/3 restart attempts exhausted",
    severity: "sev1",
    recoveryAttempts: 3,
    timeline: [
      { ts: NOW - 15 * 60_000, text: "3 consecutive failed checks → incident opened" },
      { ts: NOW - 14 * 60_000, text: "auto-restart attempt 1/3 → probe failed (ECONNREFUSED)" },
      { ts: NOW - 11 * 60_000, text: "auto-restart attempt 2/3 → probe failed" },
      { ts: NOW - 8 * 60_000, text: "auto-restart attempt 3/3 → probe failed, maxRestarts reached" },
      { ts: NOW - 7 * 60_000, text: "telegram alert dispatched → @emmy (rule: DOWN > 60s)" },
    ],
  },
  {
    id: "INC-1041",
    projectId: "digistream",
    startedAt: NOW - 4 * 60_000,
    resolvedAt: null,
    state: "open",
    cause: "404 on https://digistream.vercel.app — likely rewrite/alias misconfig after last Vercel deploy",
    severity: "sev3",
    recoveryAttempts: 0,
    timeline: [
      { ts: NOW - 4 * 60_000, text: "3 consecutive 404 → DEGRADED (kept for AI context)" },
      { ts: NOW - 3 * 60_000, text: "external project — no local control, link-out to provider" },
    ],
  },
  {
    id: "INC-1038",
    projectId: "echoo-backend",
    startedAt: NOW - 19 * 3600_000,
    resolvedAt: NOW - 19 * 3600_000 + 8 * 60_000,
    state: "resolved",
    cause: "503 on /api/sync — db pool saturation (12/12) during nightly backfill",
    severity: "sev2",
    recoveryAttempts: 0,
    acknowledgedBy: "emmy",
    note: "pool limit raised to 24 in a83f91d.",
    timeline: [
      { ts: NOW - 19 * 3600_000, text: "2 failed checks → DEGRADED" },
      { ts: NOW - 19 * 3600_000 + 3 * 60_000, text: "pool recovered on its own (11 idle)" },
      { ts: NOW - 19 * 3600_000 + 8 * 60_000, text: "auto-resolved on 3 consecutive OK checks" },
    ],
  },
  {
    id: "INC-1035",
    projectId: "aurora-relay",
    startedAt: NOW - 6 * 3600_000,
    resolvedAt: NOW - 6 * 3600_000 + 5 * 60_000,
    state: "resolved",
    cause: "502 from render.com free-tier cold start",
    severity: "sev3",
    recoveryAttempts: 0,
    timeline: [
      { ts: NOW - 6 * 3600_000, text: "2 failed checks (502)" },
      { ts: NOW - 6 * 3600_000 + 5 * 60_000, text: "recovered 200 in 366ms" },
    ],
  },
];

/* ─────────────────────────────── audit ────────────────────────────────── */

export const SEED_AUDIT: AuditEntry[] = [
  { id: 1, ts: NOW - 6 * 3600_000, actor: "emmy", action: "deploy", projectId: "echoo-backend", detail: "sha latest (main)", result: "ok" },
  { id: 2, ts: NOW - 6 * 3600_000 + 74_000, actor: "system", action: "deploy.verify", projectId: "echoo-backend", detail: "3/3 probes ok → success", result: "ok" },
  { id: 3, ts: NOW - 9000_000, actor: "emmy", action: "process.stop", projectId: "ghost-mailer", detail: "SIGTERM pid 15230", result: "ok" },
  { id: 4, ts: NOW - 40 * 3600_000, actor: "emmy", action: "deploy", projectId: "pulse-api", detail: "sha latest (main)", result: "ok" },
  { id: 5, ts: NOW - 40 * 3600_000 + 44_000, actor: "system", action: "deploy.rollback", projectId: "pulse-api", detail: "health gate fail → 4d0e88a1", result: "fail" },
  { id: 6, ts: NOW - 22 * 60_000, actor: "emmy", action: "exec", projectId: "pulse-api", detail: "rm -rf /", result: "denied" },
  { id: 7, ts: NOW - 20 * 60_000, actor: "emmy", action: "exec", projectId: "pulse-api", detail: "git log --oneline -5", result: "ok" },
  { id: 8, ts: NOW - 12 * 60_000, actor: "ai:opencode", action: "ai.ask", projectId: "pulse-api", detail: "why is pulse-api down?", result: "ok" },
  { id: 9, ts: NOW - 7 * 60_000, actor: "system", action: "notify.telegram", projectId: "pulse-api", detail: "INC-1042 DOWN > 60s", result: "ok" },
];

export const SEED_TERMINAL: Record<string, { lines: string[]; cwd: string; mode: "safe" | "admin" }> = {
  "pulse-api": {
    cwd: "/root/projects/pulse-api",
    mode: "safe",
    lines: [
      "server-dashboard › safe terminal  ·  cwd jail: /root/projects/pulse-api",
      "allowlist: git, npm, node, python, ls, cat, df, ps, curl, tail, grep",
      "timeout 30s · output cap 100KB · shell:false · every call audited",
      "",
      "› git log --oneline -3",
      "5e2ab9 fix: bump pool timeout to 5s",
      "4d0e88 chore: pin psycopg2-binary",
      "b1c2f0 feat: webhook worker",
    ],
  },
  "echoo-backend": {
    cwd: "/root/Software_projects/echoo/backend",
    mode: "safe",
    lines: [
      "server-dashboard › safe terminal  ·  cwd jail: /root/Software_projects/echoo/backend",
      "",
      "› npm run test -- --silent",
      "PASS  tests/auth.spec.ts (12)",
      "PASS  tests/sync.spec.ts (8)",
      "Tests: 20 passed, 20 total",
    ],
  },
};

export const ALLOWLIST = [
  "git",
  "npm",
  "node",
  "python",
  "pip",
  "ls",
  "cat",
  "df",
  "ps",
  "curl",
  "tail",
  "grep",
  "echo",
];
