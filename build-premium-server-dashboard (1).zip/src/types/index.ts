export type ProjectStatus = 'UP' | 'DEGRADED' | 'DOWN' | 'STARTING' | 'STOPPED';

export type ProjectLocation = {
  type: 'local' | 'external';
  agentId: string;
  cwd?: string;
  provider?: 'vercel' | 'railway' | 'render' | 'other';
};

export type RuntimeConfig = {
  command?: string;
  args?: string[];
  port?: number;
  healthUrl: string;
  autoRestart?: boolean;
  maxRestarts?: number;
  restartCooldownSec?: number;
  startOnBoot?: boolean;
  startupTimeoutSec?: number;
  envFile?: string;
};

export type SourceConfig = {
  provider: 'github' | 'gitlab' | 'other';
  repository?: string;
  branch?: string;
  deployOnPush?: boolean;
};

export type MonitoringConfig = {
  intervalSeconds: number;
  timeoutSeconds: number;
  expectedStatus?: number[];
  expectedBody?: string | null;
  healthConfig?: {
    type: 'http' | 'tcp' | 'body-json';
    json?: Record<string, any>;
  };
};

export type NotificationsConfig = {
  down: boolean;
  recovered: boolean;
  deploymentFailed?: boolean;
  crashLoop?: boolean;
};

export interface Project {
  id: string;
  name: string;
  enabled: boolean;
  location: ProjectLocation;
  runtime: RuntimeConfig;
  source?: SourceConfig;
  monitoring: MonitoringConfig;
  notifications: NotificationsConfig;
  template?: string;
}

export interface ProcessInfo {
  pid?: number;
  alive: boolean;
  cpuPct?: number;
  memMB?: number;
  uptimeSec?: number;
  restarts: number;
}

export interface StatusCheck {
  ts: string;
  code: number;
  latencyMs: number;
  error?: string;
  bodySnippet?: string;
}

export interface ProjectState {
  status: ProjectStatus;
  code: number;
  latencyMs: number;
  checkedAt: string;
  uptime24h: number;
  restarts: number;
  process?: ProcessInfo;
}

export interface Deployment {
  id: string;
  projectId: string;
  sha: string;
  branch: string;
  startedAt: string;
  endedAt?: string;
  status: 'pending' | 'running' | 'success' | 'failed' | 'rolled-back';
  buildTail?: string[];
}

export interface Incident {
  id: string;
  projectId: string;
  startedAt: string;
  resolvedAt?: string;
  cause: string;
  state: 'open' | 'acknowledged' | 'resolved';
  timeline: { ts: string; note: string }[];
  recoveryAttempts: number;
}

export interface AuditEntry {
  ts: string;
  actor: string;
  projectId: string;
  action: string;
  argsHash: string;
  result: string;
}

export interface Agent {
  id: string;
  hostname: string;
  platform: string;
}

export interface DashboardStats {
  total: number;
  up: number;
  degraded: number;
  down: number;
  starting: number;
  stopped: number;
  avgLatency: number;
  openIncidents: number;
}
