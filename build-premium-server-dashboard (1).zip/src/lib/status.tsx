import type { ProjectStatus } from '@/types';

export const statusConfig: Record<ProjectStatus, { label: string; color: string; bg: string; border: string; glow: string }> = {
  UP: {
    label: 'UP',
    color: 'text-up',
    bg: 'bg-up-dim',
    border: 'border-up/20',
    glow: 'shadow-up/10',
  },
  DEGRADED: {
    label: 'DEGRADED',
    color: 'text-degraded',
    bg: 'bg-degraded-dim',
    border: 'border-degraded/20',
    glow: 'shadow-degraded/10',
  },
  DOWN: {
    label: 'DOWN',
    color: 'text-down',
    bg: 'bg-down-dim',
    border: 'border-down/20',
    glow: 'shadow-down/20',
  },
  STARTING: {
    label: 'STARTING',
    color: 'text-starting',
    bg: 'bg-starting-dim',
    border: 'border-starting/20',
    glow: 'shadow-starting/10',
  },
  STOPPED: {
    label: 'STOPPED',
    color: 'text-stopped',
    bg: 'bg-stopped-dim',
    border: 'border-stopped/20',
    glow: 'shadow-stopped/5',
  },
};

export function statusLabel(status: ProjectStatus) {
  return statusConfig[status].label;
}

export function formatDuration(seconds?: number): string {
  if (!seconds) return '—';
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h ${minutes}m`;
  return `${minutes}m`;
}

export function formatLatency(ms: number): string {
  if (ms === 0) return '—';
  if (ms >= 1000) return `${(ms / 1000).toFixed(2)}s`;
  return `${ms}ms`;
}

export function timeAgo(iso?: string): string {
  if (!iso) return '—';
  const seconds = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (seconds < 10) return 'just now';
  if (seconds < 60) return `${seconds}s ago`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}
