import { useEffect, useMemo, useState, useCallback } from 'react';
import type { Project, ProjectState, Deployment, Incident, StatusCheck } from '@/types';
import { mockProjects, initialStates, mockDeployments, mockIncidents, computeStats, generateHistory, generateLogs } from '@/data/mock';

export type ViewTab = 'overview' | 'logs' | 'terminal' | 'ai' | 'deploy' | 'incidents';

export function useDashboard() {
  const [projects, setProjects] = useState<Project[]>(mockProjects);
  const [states, setStates] = useState<Record<string, ProjectState>>(initialStates);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(mockProjects[0].id);
  const [activeTab, setActiveTab] = useState<ViewTab>('overview');
  const [deployments] = useState<Deployment[]>(mockDeployments);
  const [incidents, setIncidents] = useState<Incident[]>(mockIncidents);
  const [history, setHistory] = useState<Record<string, StatusCheck[]>>({});
  const [logs, setLogs] = useState<Record<string, string[]>>({});
  const [isAuthenticated] = useState(true);
  const [aiProvider, setAiProvider] = useState<'opencode' | 'codex' | 'claude' | 'ollama'>('claude');

  const selectedProject = useMemo(() => projects.find((p) => p.id === selectedProjectId) || null, [projects, selectedProjectId]);

  const stats = useMemo(() => computeStats(states), [states]);

  // Simulate live health checks
  useEffect(() => {
    const interval = setInterval(() => {
      setStates((prev) => {
        const next = { ...prev };
        Object.keys(next).forEach((id) => {
          const project = projects.find((p) => p.id === id);
          if (!project || !project.enabled) return;
          const state = next[id];
          if (state.status === 'STOPPED') return;

          const jitter = Math.round((Math.random() - 0.5) * 15);
          let latency = Math.max(5, state.latencyMs + jitter);
          let code = state.code;

          if (state.status === 'DOWN') {
            code = Math.random() > 0.7 ? 503 : 0;
            latency = 4000 + Math.round(Math.random() * 6000);
          } else if (state.status === 'DEGRADED') {
            latency = Math.random() > 0.5 ? state.latencyMs + Math.round(Math.random() * 1200) : Math.max(10, state.latencyMs + jitter);
          }

          next[id] = { ...state, latencyMs: latency, code, checkedAt: new Date().toISOString() };
        });
        return next;
      });
    }, 3000);
    return () => clearInterval(interval);
  }, [projects]);

  const fetchHistory = useCallback((projectId: string) => {
    setHistory((prev) => ({ ...prev, [projectId]: generateHistory(projectId) }));
  }, []);

  const fetchLogs = useCallback((projectId: string) => {
    setLogs((prev) => ({ ...prev, [projectId]: generateLogs(projectId) }));
  }, []);

  const refreshLogs = useCallback((projectId: string) => {
    setLogs((prev) => {
      const current = prev[projectId] || [];
      return {
        ...prev,
        [projectId]: [...current, `[${new Date().toISOString()}] ${projectId} | GET /health 200 ${Math.floor(Math.random() * 60)}ms`],
      };
    });
  }, []);

  const setProjectStatus = useCallback((projectId: string, status: ProjectState['status']) => {
    setStates((prev) => {
      const current = prev[projectId];
      if (!current) return prev;
      const next: ProjectState = { ...current, status, checkedAt: new Date().toISOString() };
      if (status === 'STARTING') next.code = 0;
      if (status === 'STOPPED') {
        next.code = 0;
        next.latencyMs = 0;
        next.process = undefined;
      }
      if (status === 'UP') {
        next.code = 200;
        next.latencyMs = Math.floor(Math.random() * 80) + 10;
        next.process = { pid: 15000 + Math.floor(Math.random() * 9000), alive: true, cpuPct: Math.random() * 10, memMB: Math.floor(Math.random() * 400) + 80, uptimeSec: 60, restarts: current.restarts };
      }
      return { ...prev, [projectId]: next };
    });
  }, []);

  const startProject = useCallback((projectId: string) => {
    setProjectStatus(projectId, 'STARTING');
    setTimeout(() => setProjectStatus(projectId, 'UP'), 2200);
  }, [setProjectStatus]);

  const stopProject = useCallback((projectId: string) => {
    setProjectStatus(projectId, 'STOPPED');
  }, [setProjectStatus]);

  const restartProject = useCallback((projectId: string) => {
    setProjectStatus(projectId, 'STARTING');
    setTimeout(() => setProjectStatus(projectId, 'UP'), 2500);
  }, [setProjectStatus]);

  const deployProject = useCallback((projectId: string) => {
    // Simulated deployment: starting → success after 3s
    setStates((prev) => ({ ...prev, [projectId]: { ...prev[projectId], status: 'STARTING' } }));
    setTimeout(() => setProjectStatus(projectId, 'UP'), 3200);
  }, [setProjectStatus]);

  const runTerminalCommand = useCallback(async (_projectId: string, cmd: string, args: string[]): Promise<{ exitCode: number; stdout: string; stderr: string; truncated: boolean }> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (cmd === 'ls') {
          resolve({ exitCode: 0, stdout: 'dist\nnode_modules\npackage.json\npackage-lock.json\nREADME.md\nsrc', stderr: '', truncated: false });
        } else if (cmd === 'npm' && args[0] === 'run' && args[1] === 'build') {
          resolve({ exitCode: 0, stdout: '> build\n\ncompiled in 4.2s\n\n✓ 184 modules transformed.\n\ndist/index.html created.', stderr: '', truncated: false });
        } else if (cmd === 'git' && args[0] === 'status') {
          resolve({ exitCode: 0, stdout: 'On branch main\nYour branch is up to date with \'origin/main\'.\n\nnothing to commit, working tree clean', stderr: '', truncated: false });
        } else if (cmd === 'cat' && args[0] === '.env') {
          resolve({ exitCode: 1, stdout: '', stderr: 'FORBIDDEN: reading .env requires admin mode', truncated: false });
        } else {
          resolve({ exitCode: 0, stdout: `executed ${cmd} ${args.join(' ')}`, stderr: '', truncated: false });
        }
      }, 600);
    });
  }, []);

  const askAI = useCallback(async (projectId: string, question: string): Promise<{ severity: string; likelyCause: string; confidence: number; evidence: string[]; recommendedActions: string[]; commands: string[]; safeToAutoFix: boolean; raw: string }> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const state = states[projectId];
        const project = projects.find((p) => p.id === projectId);
        const isDegraded = state?.status === 'DEGRADED';
        const isDown = state?.status === 'DOWN';
        resolve({
          severity: isDown ? 'critical' : isDegraded ? 'warning' : 'info',
          likelyCause: isDegraded ? 'Memory pressure causing response latency >2s' : isDown ? 'Provider returned 503' : 'No issue detected',
          confidence: isDegraded ? 0.78 : isDown ? 0.92 : 0.45,
          evidence: [
            `Last check: HTTP ${state?.code} @ ${state?.latencyMs}ms`,
            'Process memory trended up 18% over last hour',
            'No recent restarts before degradation',
          ],
          recommendedActions: isDegraded ? ['Restart service', 'Inspect memory usage', 'Review recent logs'] : isDown ? ['Check provider status page', 'Wait for provider recovery'] : ['Continue monitoring'],
          commands: isDegraded ? ['restart_project', 'run_safe_command: ps aux | grep node'] : [],
          safeToAutoFix: isDegraded,
          raw: `AI (${aiProvider}) analysis for ${project?.name}:\nQ: ${question}\nA: ${isDegraded ? 'Likely memory pressure. Restart is safe and reversible.' : 'No actionable issue.'}`,
        });
      }, 1100);
    });
  }, [states, projects, aiProvider]);

  const acknowledgeIncident = useCallback((incidentId: string, note?: string) => {
    setIncidents((prev) =>
      prev.map((i) =>
        i.id === incidentId
          ? { ...i, state: 'acknowledged' as const, timeline: [...i.timeline, { ts: new Date().toISOString(), note: note || 'Acknowledged manually' }] }
          : i
      )
    );
  }, []);

  const resolveIncident = useCallback((incidentId: string, note?: string) => {
    setIncidents((prev) =>
      prev.map((i) =>
        i.id === incidentId
          ? { ...i, state: 'resolved' as const, resolvedAt: new Date().toISOString(), timeline: [...i.timeline, { ts: new Date().toISOString(), note: note || 'Resolved manually' }] }
          : i
      )
    );
  }, []);

  const addProject = useCallback((project: Project) => {
    setProjects((prev) => [...prev, project]);
    setStates((prev) => ({
      ...prev,
      [project.id]: {
        status: 'STOPPED',
        code: 0,
        latencyMs: 0,
        checkedAt: new Date().toISOString(),
        uptime24h: 0,
        restarts: 0,
      },
    }));
  }, []);

  return {
    projects,
    states,
    stats,
    selectedProject,
    selectedProjectId,
    setSelectedProjectId,
    activeTab,
    setActiveTab,
    deployments,
    incidents,
    history,
    logs,
    fetchHistory,
    fetchLogs,
    refreshLogs,
    startProject,
    stopProject,
    restartProject,
    deployProject,
    runTerminalCommand,
    askAI,
    acknowledgeIncident,
    resolveIncident,
    addProject,
    isAuthenticated,
    aiProvider,
    setAiProvider,
  };
}
