import type { Project, ProjectState, Deployment, Incident, Agent, DashboardStats, StatusCheck } from '@/types';

export const mockAgents: Agent[] = [
  { id: 'local', hostname: 'pixel-server', platform: 'android/proot' },
  { id: 'edge-1', hostname: 'edge-vps', platform: 'linux/amd64' },
];

export const mockProjects: Project[] = [
  {
    id: 'echoo-backend',
    name: 'Echoo Backend',
    enabled: true,
    location: { type: 'local', agentId: 'local', cwd: '/root/Software_projects/echoo/backend' },
    runtime: {
      command: 'npm',
      args: ['run', 'start'],
      port: 8000,
      healthUrl: 'http://localhost:8000/health',
      autoRestart: true,
      maxRestarts: 5,
      restartCooldownSec: 5,
      startOnBoot: true,
      startupTimeoutSec: 20,
      envFile: '.env',
    },
    source: { provider: 'github', repository: 'emmy16-glitch/echoo', branch: 'main', deployOnPush: false },
    monitoring: {
      intervalSeconds: 30,
      timeoutSeconds: 10,
      expectedStatus: [200, 301, 302],
      healthConfig: { type: 'body-json', json: { database: 'connected' } },
    },
    notifications: { down: true, recovered: true, deploymentFailed: true, crashLoop: true },
    template: 'node-api',
  },
  {
    id: 'digistream',
    name: 'DigiStream',
    enabled: true,
    location: { type: 'external', agentId: 'local', provider: 'vercel' },
    runtime: {
      healthUrl: 'https://digistream.vercel.app',
      autoRestart: false,
    },
    monitoring: {
      intervalSeconds: 60,
      timeoutSeconds: 10,
      expectedStatus: [200],
    },
    notifications: { down: true, recovered: true },
  },
  {
    id: 'librechat',
    name: 'LibreChat',
    enabled: true,
    location: { type: 'local', agentId: 'local', cwd: '/root/projects/librechat' },
    runtime: {
      command: 'npm',
      args: ['run', 'start:deployed'],
      port: 3080,
      healthUrl: 'http://localhost:3080/health',
      autoRestart: true,
      maxRestarts: 3,
      restartCooldownSec: 10,
      startOnBoot: false,
      startupTimeoutSec: 45,
      envFile: '.env',
    },
    source: { provider: 'github', repository: 'danny-avila/LibreChat', branch: 'main' },
    monitoring: {
      intervalSeconds: 30,
      timeoutSeconds: 10,
      expectedStatus: [200],
    },
    notifications: { down: true, recovered: true, deploymentFailed: true, crashLoop: true },
    template: 'node-api',
  },
  {
    id: 'ollama',
    name: 'Ollama',
    enabled: true,
    location: { type: 'local', agentId: 'local', cwd: '/root/projects/ollama' },
    runtime: {
      command: 'ollama',
      args: ['serve'],
      port: 11434,
      healthUrl: 'http://localhost:11434',
      autoRestart: true,
      maxRestarts: 5,
      restartCooldownSec: 5,
      startOnBoot: true,
      startupTimeoutSec: 30,
    },
    monitoring: {
      intervalSeconds: 30,
      timeoutSeconds: 10,
      expectedStatus: [200],
    },
    notifications: { down: true, recovered: true, crashLoop: true },
  },
  {
    id: 'archivebox',
    name: 'ArchiveBox',
    enabled: false,
    location: { type: 'local', agentId: 'local', cwd: '/root/projects/archivebox' },
    runtime: {
      command: 'archivebox',
      args: ['server'],
      port: 8001,
      healthUrl: 'http://localhost:8001/',
      autoRestart: false,
    },
    monitoring: {
      intervalSeconds: 60,
      timeoutSeconds: 10,
      expectedStatus: [200],
    },
    notifications: { down: true, recovered: true },
  },
  {
    id: 'railway-api',
    name: 'Railway API',
    enabled: true,
    location: { type: 'external', agentId: 'local', provider: 'railway' },
    runtime: {
      healthUrl: 'https://api.railway-staging.app/health',
      autoRestart: false,
    },
    monitoring: {
      intervalSeconds: 60,
      timeoutSeconds: 10,
      expectedStatus: [200],
    },
    notifications: { down: true, recovered: true },
  },
];

export const initialStates: Record<string, ProjectState> = {
  'echoo-backend': {
    status: 'UP',
    code: 200,
    latencyMs: 34,
    checkedAt: new Date(Date.now() - 12000).toISOString(),
    uptime24h: 99.98,
    restarts: 0,
    process: { pid: 18432, alive: true, cpuPct: 4.2, memMB: 142, uptimeSec: 86400 + 1200, restarts: 0 },
  },
  digistream: {
    status: 'UP',
    code: 200,
    latencyMs: 156,
    checkedAt: new Date(Date.now() - 45000).toISOString(),
    uptime24h: 100,
    restarts: 0,
  },
  librechat: {
    status: 'DEGRADED',
    code: 200,
    latencyMs: 2450,
    checkedAt: new Date(Date.now() - 28000).toISOString(),
    uptime24h: 97.4,
    restarts: 2,
    process: { pid: 19204, alive: true, cpuPct: 18.6, memMB: 412, uptimeSec: 3600 * 4, restarts: 2 },
  },
  ollama: {
    status: 'UP',
    code: 200,
    latencyMs: 12,
    checkedAt: new Date(Date.now() - 8000).toISOString(),
    uptime24h: 99.9,
    restarts: 0,
    process: { pid: 15001, alive: true, cpuPct: 1.1, memMB: 890, uptimeSec: 86400 * 2, restarts: 0 },
  },
  archivebox: {
    status: 'STOPPED',
    code: 0,
    latencyMs: 0,
    checkedAt: new Date(Date.now() - 120000).toISOString(),
    uptime24h: 0,
    restarts: 0,
  },
  'railway-api': {
    status: 'DOWN',
    code: 503,
    latencyMs: 10234,
    checkedAt: new Date(Date.now() - 62000).toISOString(),
    uptime24h: 94.2,
    restarts: 0,
  },
};

export const mockDeployments: Deployment[] = [
  {
    id: 'd-18',
    projectId: 'echoo-backend',
    sha: 'a83f91d',
    branch: 'main',
    startedAt: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
    endedAt: new Date(Date.now() - 1000 * 60 * 38).toISOString(),
    status: 'success',
    buildTail: [
      '[deploy] fetching origin…',
      '[deploy] checkout a83f91d on main',
      '[deploy] npm install — 312 packages',
      '[deploy] npm run build — 4.2s',
      '[deploy] pre-deploy: npm run migrate',
      '[deploy] restart echoo-backend',
      '[deploy] health gate: 3/3 OK (avg 31ms)',
      '[deploy] post-deploy: notify telegram',
      '[deploy] live.',
    ],
  },
  {
    id: 'd-17',
    projectId: 'echoo-backend',
    sha: 'b12c4e9',
    branch: 'main',
    startedAt: new Date(Date.now() - 1000 * 60 * 60 * 6).toISOString(),
    endedAt: new Date(Date.now() - 1000 * 60 * 60 * 5 + 1000 * 60 * 3).toISOString(),
    status: 'rolled-back',
    buildTail: [
      '[deploy] checkout b12c4e9',
      '[deploy] build failed: TypeError in auth middleware',
      '[deploy] health gate failed',
      '[deploy] rollback to a83f91d',
    ],
  },
  {
    id: 'd-3',
    projectId: 'librechat',
    sha: '7d21a0f',
    branch: 'main',
    startedAt: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
    endedAt: new Date(Date.now() - 1000 * 60 * 60 * 1 + 1000 * 30).toISOString(),
    status: 'success',
    buildTail: [
      '[deploy] npm install — 612 packages',
      '[deploy] npm run frontend:build — 18s',
      '[deploy] restart librechat',
      '[deploy] health gate: 3/3 OK (avg 2.1s)',
    ],
  },
];

export const mockIncidents: Incident[] = [
  {
    id: 'i-2024-001',
    projectId: 'librechat',
    startedAt: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString(),
    cause: 'Latency spike >2s on /health',
    state: 'acknowledged',
    timeline: [
      { ts: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString(), note: 'Auto-opened by monitor' },
      { ts: new Date(Date.now() - 1000 * 60 * 60 * 2 + 1000 * 60 * 5).toISOString(), note: 'Acknowledged — investigating memory pressure' },
    ],
    recoveryAttempts: 1,
  },
  {
    id: 'i-2024-002',
    projectId: 'railway-api',
    startedAt: new Date(Date.now() - 1000 * 60 * 10).toISOString(),
    cause: 'HTTP 503 from provider',
    state: 'open',
    timeline: [
      { ts: new Date(Date.now() - 1000 * 60 * 10).toISOString(), note: 'Auto-opened by monitor' },
      { ts: new Date(Date.now() - 1000 * 60 * 5).toISOString(), note: 'Provider status page reports incident' },
    ],
    recoveryAttempts: 0,
  },
];

export function computeStats(states: Record<string, ProjectState>): DashboardStats {
  const values = Object.values(states);
  return {
    total: values.length,
    up: values.filter((s) => s.status === 'UP').length,
    degraded: values.filter((s) => s.status === 'DEGRADED').length,
    down: values.filter((s) => s.status === 'DOWN').length,
    starting: values.filter((s) => s.status === 'STARTING').length,
    stopped: values.filter((s) => s.status === 'STOPPED').length,
    avgLatency: Math.round(values.filter((s) => s.latencyMs > 0).reduce((a, s) => a + s.latencyMs, 0) / values.filter((s) => s.latencyMs > 0).length) || 0,
    openIncidents: mockIncidents.filter((i) => i.state === 'open' || i.state === 'acknowledged').length,
  };
}

export function generateHistory(projectId: string, hours = 24): StatusCheck[] {
  const checks: StatusCheck[] = [];
  const now = Date.now();
  const state = initialStates[projectId];
  const baseLatency = state?.latencyMs || 60;
  const baseStatus = state?.status || 'UP';

  for (let i = hours * 12; i >= 0; i--) {
    const jitter = Math.round((Math.random() - 0.5) * baseLatency * 0.4);
    const ts = new Date(now - i * 5 * 60 * 1000).toISOString();

    if (baseStatus === 'DOWN') {
      checks.push({ ts, code: Math.random() > 0.3 ? 503 : 0, latencyMs: 5000 + Math.round(Math.random() * 8000), error: 'Service Unavailable' });
    } else if (baseStatus === 'DEGRADED') {
      const slow = Math.random() > 0.6;
      checks.push({ ts, code: 200, latencyMs: slow ? baseLatency + Math.round(Math.random() * 2000) : Math.max(10, baseLatency + jitter) });
    } else if (baseStatus === 'STOPPED') {
      checks.push({ ts, code: 0, latencyMs: 0, error: 'No check — stopped' });
    } else {
      checks.push({ ts, code: 200, latencyMs: Math.max(5, baseLatency + jitter) });
    }
  }
  return checks;
}

export function generateLogs(projectId: string): string[] {
  const project = mockProjects.find((p) => p.id === projectId);
  const base = project?.name || projectId;
  return [
    `[${new Date().toISOString()}] ${base} | process started pid=${15000 + Math.floor(Math.random() * 5000)}`,
    `[${new Date(Date.now() - 120000).toISOString()}] ${base} | GET /health 200 ${Math.floor(Math.random() * 60)}ms`,
    `[${new Date(Date.now() - 90000).toISOString()}] ${base} | GET /api/v1/status 200 ${Math.floor(Math.random() * 80)}ms`,
    `[${new Date(Date.now() - 60000).toISOString()}] ${base} | database connection pool: 4/20`,
    `[${new Date(Date.now() - 30000).toISOString()}] ${base} | GET /health 200 ${Math.floor(Math.random() * 60)}ms`,
    `[${new Date().toISOString()}] ${base} | health check passed`,
  ];
}
