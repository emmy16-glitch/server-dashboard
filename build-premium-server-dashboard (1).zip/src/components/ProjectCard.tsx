import { Power, RotateCw, ExternalLink } from 'lucide-react';
import type { Project, ProjectState } from '@/types';
import { statusConfig, formatLatency, timeAgo, formatDuration } from '@/lib/status';
import { cn } from '@/utils/cn';

interface ProjectCardProps {
  project: Project;
  state: ProjectState;
  isSelected: boolean;
  onSelect: (id: string) => void;
  onStart: (id: string) => void;
  onStop: (id: string) => void;
  onRestart: (id: string) => void;
}

export function ProjectCard({ project, state, isSelected, onSelect, onStart, onStop, onRestart }: ProjectCardProps) {
  const config = statusConfig[state.status];
  const isLocal = project.location.type === 'local';
  const provider = project.location.provider || project.location.type;

  return (
    <div
      onClick={() => onSelect(project.id)}
      className={cn(
        'group relative panel p-4 cursor-pointer transition-all duration-200 hover:-translate-y-0.5',
        isSelected ? 'ring-1 ring-white/15 bg-panel-raised' : 'hover:bg-panel-raised'
      )}
    >
      {/* Top status line */}
      <div className="absolute top-0 left-0 right-0 h-0.5 bg-white/5 overflow-hidden">
        <div className={cn('h-full', config.color.replace('text-', 'bg-'))} style={{ width: state.status === 'STOPPED' ? '0%' : '100%' }} />
      </div>

      <div className="flex items-start justify-between mb-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h3 className="text-sm font-semibold text-ink tracking-tight">{project.name}</h3>
            <span className="tag border-white/5 text-ink-dim bg-white/[0.03]">{provider}</span>
          </div>
          <p className="text-[10px] tracking-wide text-ink-dim font-mono truncate max-w-[200px]">
            {isLocal ? project.location.cwd : project.runtime.healthUrl}
          </p>
        </div>
        <div className={cn('status-dot', state.status === 'UP' && 'status-pulse', config.color.replace('text-', 'bg-'))} />
      </div>

      <div className="grid grid-cols-3 gap-2 mb-4">
        <div className="bg-white/[0.02] border border-white/5 p-2">
          <p className="text-[9px] tracking-[0.15em] uppercase text-ink-dim mb-1">Status</p>
          <p className={cn('text-xs font-bold tracking-wide', config.color)}>{config.label}</p>
        </div>
        <div className="bg-white/[0.02] border border-white/5 p-2">
          <p className="text-[9px] tracking-[0.15em] uppercase text-ink-dim mb-1">Latency</p>
          <p className="text-xs font-bold tabular-nums text-ink">{formatLatency(state.latencyMs)}</p>
        </div>
        <div className="bg-white/[0.02] border border-white/5 p-2">
          <p className="text-[9px] tracking-[0.15em] uppercase text-ink-dim mb-1">Uptime</p>
          <p className="text-xs font-bold tabular-nums text-ink">{state.uptime24h}%</p>
        </div>
      </div>

      {isLocal && state.process && (
        <div className="flex items-center gap-4 mb-4 text-[10px] text-ink-dim">
          <span className="font-mono">PID {state.process.pid}</span>
          <span className="font-mono">CPU {state.process.cpuPct?.toFixed(1)}%</span>
          <span className="font-mono">MEM {state.process.memMB}MB</span>
          <span className="font-mono">UP {formatDuration(state.process.uptimeSec)}</span>
        </div>
      )}

      <div className="flex items-center justify-between pt-3 border-t border-white/5">
        <span className="text-[9px] text-ink-dim">{timeAgo(state.checkedAt)}</span>
        <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
          {isLocal && (
            <>
              {state.status === 'STOPPED' ? (
                <button onClick={() => onStart(project.id)} className="btn-tactical p-1.5 text-up border-up/20 hover:bg-up-dim" title="Start">
                  <Power className="h-3.5 w-3.5" />
                </button>
              ) : (
                <button onClick={() => onStop(project.id)} className="btn-tactical p-1.5" title="Stop">
                  <Power className="h-3.5 w-3.5" />
                </button>
              )}
              <button onClick={() => onRestart(project.id)} className="btn-tactical p-1.5" title="Restart">
                <RotateCw className="h-3.5 w-3.5" />
              </button>
            </>
          )}
          <button className="btn-tactical p-1.5" title="Open in new tab">
            <ExternalLink className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
