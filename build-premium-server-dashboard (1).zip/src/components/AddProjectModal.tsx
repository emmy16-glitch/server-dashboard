import { useState } from 'react';
import { X, Plus } from 'lucide-react';
import type { Project } from '@/types';

interface AddProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (project: Project) => void;
}

export function AddProjectModal({ isOpen, onClose, onAdd }: AddProjectModalProps) {
  const [name, setName] = useState('');
  const [type, setType] = useState<'local' | 'external'>('local');
  const [cwd, setCwd] = useState('');
  const [url, setUrl] = useState('');
  const [port, setPort] = useState('');
  const [provider, setProvider] = useState<'vercel' | 'railway' | 'render' | 'other'>('vercel');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const id = name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
    const project: Project = {
      id,
      name,
      enabled: true,
      location:
        type === 'local'
          ? { type: 'local', agentId: 'local', cwd }
          : { type: 'external', agentId: 'local', provider },
      runtime:
        type === 'local'
          ? {
              command: 'npm',
              args: ['run', 'start'],
              port: parseInt(port, 10) || 3000,
              healthUrl: `http://localhost:${port || 3000}/health`,
              autoRestart: true,
            }
          : { healthUrl: url, autoRestart: false },
      monitoring: { intervalSeconds: 30, timeoutSeconds: 10, expectedStatus: [200] },
      notifications: { down: true, recovered: true },
    };
    onAdd(project);
    setName('');
    setCwd('');
    setUrl('');
    setPort('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="w-full max-w-lg glass-strong border border-white/10 p-6">
        <div className="flex items-center justify-between mb-5">
          <h3 className="text-sm font-bold tracking-[0.12em] uppercase text-ink">Add Project</h3>
          <button onClick={onClose} className="btn-tactical p-1.5">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-[10px] font-bold tracking-[0.15em] uppercase text-ink-dim block mb-1.5">Project Name</label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              className="w-full bg-white/5 border border-white/10 text-ink text-sm px-3 py-2 focus:outline-none focus:border-accent/40 placeholder:text-ink-dim/40"
              placeholder="My Service"
            />
          </div>

          <div>
            <label className="text-[10px] font-bold tracking-[0.15em] uppercase text-ink-dim block mb-1.5">Location Type</label>
            <div className="flex gap-2">
              {(['local', 'external'] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setType(t)}
                  className={`flex-1 py-2 text-xs font-semibold uppercase tracking-wider border ${
                    type === t ? 'bg-white/10 border-white/30 text-ink' : 'bg-white/5 border-white/10 text-ink-dim'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {type === 'local' ? (
            <>
              <div>
                <label className="text-[10px] font-bold tracking-[0.15em] uppercase text-ink-dim block mb-1.5">Working Directory</label>
                <input
                  value={cwd}
                  onChange={(e) => setCwd(e.target.value)}
                  required
                  className="w-full bg-white/5 border border-white/10 text-ink text-sm px-3 py-2 focus:outline-none focus:border-accent/40 placeholder:text-ink-dim/40 font-mono"
                  placeholder="/root/projects/my-app"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold tracking-[0.15em] uppercase text-ink-dim block mb-1.5">Port</label>
                <input
                  type="number"
                  value={port}
                  onChange={(e) => setPort(e.target.value)}
                  required
                  className="w-full bg-white/5 border border-white/10 text-ink text-sm px-3 py-2 focus:outline-none focus:border-accent/40 placeholder:text-ink-dim/40 font-mono"
                  placeholder="3000"
                />
              </div>
            </>
          ) : (
            <>
              <div>
                <label className="text-[10px] font-bold tracking-[0.15em] uppercase text-ink-dim block mb-1.5">Provider</label>
                <select
                  value={provider}
                  onChange={(e) => setProvider(e.target.value as any)}
                  className="w-full bg-white/5 border border-white/10 text-ink text-sm px-3 py-2 focus:outline-none focus:border-accent/40"
                >
                  <option value="vercel">Vercel</option>
                  <option value="railway">Railway</option>
                  <option value="render">Render</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] font-bold tracking-[0.15em] uppercase text-ink-dim block mb-1.5">Health URL</label>
                <input
                  type="url"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  required
                  className="w-full bg-white/5 border border-white/10 text-ink text-sm px-3 py-2 focus:outline-none focus:border-accent/40 placeholder:text-ink-dim/40 font-mono"
                  placeholder="https://example.com/health"
                />
              </div>
            </>
          )}

          <div className="pt-2">
            <button type="submit" className="btn-primary w-full py-2.5">
              <Plus className="h-4 w-4" />
              Add Project
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
