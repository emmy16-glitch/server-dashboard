import { Rocket, GitBranch, Clock, RotateCcw, CheckCircle2, XCircle, Loader2, AlertCircle } from 'lucide-react';
import type { Deployment, Project } from '@/types';
import { timeAgo } from '@/lib/status';

interface DeploymentPanelProps {
  project: Project;
  deployments: Deployment[];
  onDeploy: (id: string) => void;
}

const statusIcons = {
  pending: Loader2,
  running: Loader2,
  success: CheckCircle2,
  failed: XCircle,
  'rolled-back': AlertCircle,
};

const statusClasses = {
  pending: 'text-starting',
  running: 'text-starting',
  success: 'text-up',
  failed: 'text-down',
  'rolled-back': 'text-degraded',
};

export function DeploymentPanel({ project, deployments, onDeploy }: DeploymentPanelProps) {
  const projectDeployments = deployments.filter((d) => d.projectId === project.id);

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Rocket className="h-3.5 w-3.5 text-accent" />
          <span className="text-[10px] font-bold tracking-[0.15em] uppercase text-ink-dim">Deployments</span>
        </div>
        {project.location.type === 'local' && (
          <button onClick={() => onDeploy(project.id)} className="btn-primary text-[9px] py-1.5 px-3">
            <Rocket className="h-3 w-3" />
            Deploy Latest
          </button>
        )}
      </div>

      <div className="flex-1 overflow-auto scrollbar-thin pr-1">
        {projectDeployments.length === 0 ? (
          <div className="h-40 flex items-center justify-center border border-white/5 bg-white/[0.02]">
            <p className="text-xs text-ink-dim">No deployments recorded</p>
          </div>
        ) : (
          <div className="space-y-3">
            {projectDeployments.map((d) => {
              const Icon = statusIcons[d.status];
              return (
                <div key={d.id} className="border border-white/5 bg-white/[0.02] p-3 hover:bg-white/[0.04] transition-colors">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-semibold text-ink">Deploy #{d.id.split('-')[1]}</span>
                        <span className={`tag ${statusClasses[d.status]} bg-white/[0.03] border-current/20`}>
                          <Icon className={`h-3 w-3 ${d.status === 'running' || d.status === 'pending' ? 'animate-spin' : ''}`} />
                          {d.status}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-[10px] text-ink-dim">
                        <span className="flex items-center gap-1">
                          <GitBranch className="h-3 w-3" />
                          {d.branch} @ {d.sha}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {timeAgo(d.startedAt)}
                        </span>
                      </div>
                    </div>
                    {d.status === 'failed' && (
                      <button className="btn-tactical p-1.5" title="Rollback">
                        <RotateCcw className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                  {d.buildTail && (
                    <div className="terminal p-2 text-[10px] max-h-32 overflow-auto scrollbar-thin">
                      {d.buildTail.map((line, i) => (
                        <div key={i} className="whitespace-pre-wrap break-all py-0.5">
                          {line}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
