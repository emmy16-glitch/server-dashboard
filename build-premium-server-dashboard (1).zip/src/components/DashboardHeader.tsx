import { Activity, ShieldCheck, Server, Clock } from 'lucide-react';

export function DashboardHeader() {
  const now = new Date();
  const time = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
  const date = now.toLocaleDateString('en-US', { weekday: 'short', year: 'numeric', month: 'short', day: '2-digit' });

  return (
    <header className="sticky top-0 z-40 glass border-b border-white/[0.06]">
      <div className="flex h-14 items-center justify-between px-5 lg:px-8">
        <div className="flex items-center gap-4">
          <div className="flex h-8 w-8 items-center justify-center border border-white/10 bg-white/5">
            <Activity className="h-4 w-4 text-up" />
          </div>
          <div className="hidden sm:block">
            <h1 className="text-sm font-bold tracking-[0.12em] uppercase text-ink">Control Plane</h1>
            <p className="text-[10px] tracking-widest uppercase text-ink-dim">Personal Server Dashboard</p>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="hidden md:flex items-center gap-3 text-[10px] tracking-widest uppercase text-ink-dim">
            <span className="flex items-center gap-1.5">
              <Server className="h-3 w-3" />
              pixel-server
            </span>
            <span className="ruler-v h-4" />
            <span className="flex items-center gap-1.5 text-up">
              <ShieldCheck className="h-3 w-3" />
              Authenticated
            </span>
          </div>

          <div className="flex items-center gap-2 text-right">
            <Clock className="h-3.5 w-3.5 text-ink-dim" />
            <div>
              <div className="text-xs font-semibold tabular-nums tracking-wide text-ink">{time}</div>
              <div className="text-[9px] tracking-wider uppercase text-ink-dim">{date}</div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
