import { useEffect, useRef, useState, useCallback } from 'react';
import { Terminal, Play, ShieldAlert } from 'lucide-react';
import type { Project } from '@/types';

interface TerminalPanelProps {
  project: Project;
  onExec: (projectId: string, cmd: string, args: string[]) => Promise<{ exitCode: number; stdout: string; stderr: string; truncated: boolean }>;
}

export function TerminalPanel({ project, onExec }: TerminalPanelProps) {
  const [lines, setLines] = useState<string[]>([
    `~ control-plane terminal v1.0 — cwd: ${project.location.cwd || '/'}`,
    '> safe mode: allowlisted commands only. type "help" for options.',
    '',
  ]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [lines]);

  const append = useCallback((text: string) => {
    setLines((prev) => [...prev, text]);
  }, []);

  const run = useCallback(
    async (raw: string) => {
      const trimmed = raw.trim();
      if (!trimmed) return;
      append(`$ ${trimmed}`);

      if (trimmed === 'help') {
        append('allowlisted: ls, ps, git status, npm run build, cat <file>, pwd, whoami');
        append('admin mode required for: shell metacharacters, env inspection, destructive ops');
        return;
      }

      if (trimmed === 'pwd') {
        append(project.location.cwd || '/');
        return;
      }
      if (trimmed === 'whoami') {
        append('dashboard-user (safe-mode)');
        return;
      }

      setBusy(true);
      const parts = trimmed.split(/\s+/);
      const [cmd, ...args] = parts;
      const allowed = ['ls', 'ps', 'git', 'npm', 'cat'];
      if (!allowed.includes(cmd)) {
        append(`403 forbidden: "${cmd}" is not in safe-mode allowlist`);
        setBusy(false);
        return;
      }

      try {
        const result = await onExec(project.id, cmd, args);
        if (result.stdout) append(result.stdout);
        if (result.stderr) append(`stderr: ${result.stderr}`);
        if (result.truncated) append('... output truncated');
        append(`exit code ${result.exitCode}`);
      } catch (e) {
        append(`error: ${e instanceof Error ? e.message : 'unknown'}`);
      } finally {
        setBusy(false);
      }
    },
    [append, onExec, project.id, project.location.cwd]
  );

  const handleSubmit = useCallback(
    (e: React.FormEvent) => {
      e.preventDefault();
      const command = input;
      setInput('');
      run(command);
    },
    [input, run]
  );

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Terminal className="h-3.5 w-3.5 text-terminal" />
          <span className="text-[10px] font-bold tracking-[0.15em] uppercase text-ink-dim">Scoped Terminal</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="tag border-degraded/30 text-degraded bg-degraded-dim">
            <ShieldAlert className="h-3 w-3" />
            Safe Mode
          </span>
        </div>
      </div>

      <div className="flex-1 terminal p-4 overflow-auto scrollbar-thin border border-terminal/10 mb-3">
        {lines.map((line, i) => (
          <div key={i} className="whitespace-pre-wrap break-all py-0.5">
            {line.startsWith('$') ? <span className="text-accent mr-2">{line.slice(0, 2)}</span> : null}
            {line.startsWith('$') ? line.slice(2) : line}
          </div>
        ))}
        {busy && <div className="animate-pulse text-terminal/70">executing...</div>}
        <div ref={bottomRef} />
      </div>

      <form onSubmit={handleSubmit} className="flex items-center gap-2">
        <span className="text-terminal font-mono text-xs">$</span>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={busy}
          placeholder="run a safe command…"
          className="flex-1 bg-black/40 border border-white/10 text-ink text-xs font-mono px-3 py-2 focus:outline-none focus:border-terminal/40 placeholder:text-ink-dim/40"
        />
        <button type="submit" disabled={busy || !input.trim()} className="btn-primary py-2 px-3">
          <Play className="h-3 w-3" />
          Run
        </button>
      </form>
    </div>
  );
}
