import { FileText, TerminalSquare, Bot, Rocket, AlertOctagon, LayoutDashboard, X } from 'lucide-react';
import type { Project, ProjectState, Deployment, Incident, StatusCheck } from '@/types';
import type { ViewTab } from '@/hooks/useDashboard';
import { statusConfig, formatLatency, timeAgo, formatDuration } from '@/lib/status';
import { LatencyChart } from './LatencyChart';
import { LogViewer } from './LogViewer';
import { TerminalPanel } from './TerminalPanel';
import { AIChat } from './AIChat';
import { DeploymentPanel } from './DeploymentPanel';
import { IncidentPanel } from './IncidentPanel';
import { cn } from '@/utils/cn';

interface ProjectDetailProps {
  project: Project;
  state: ProjectState;
  activeTab: ViewTab;
  onTabChange: (tab: ViewTab) => void;
  onClose: () => void;
  deployments: Deployment[];
  incidents: Incident[];
  history: StatusCheck[];
  logs: string[];
  aiProvider: 'opencode' | 'codex' | 'claude' | 'ollama';
  onProviderChange?: (provider: 'opencode' | 'codex' | 'claude' | 'ollama') => void;
  onFetchHistory: () => void;
  onRefreshLogs: () => void;
  onExec: (projectId: string, cmd: string, args: string[]) => Promise<{ exitCode: number; stdout: string; stderr: string; truncated: boolean }>;
  onAsk: (projectId: string, question: string) => Promise<any>;
  onDeploy: (id: string) => void;
  onAcknowledge: (id: string, note?: string) => void;
  onResolve: (id: string, note?: string) => void;
  onRestart: (id: string) => void;
}

const tabs: { id: ViewTab; label: string; icon: React.ElementType }[] = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'logs', label: 'Logs', icon: FileText },
  { id: 'terminal', label: 'Terminal', icon: TerminalSquare },
  { id: 'ai', label: 'AI Helper', icon: Bot },
  { id: 'deploy', label: 'Deploy', icon: Rocket },
  { id: 'incidents', label: 'Incidents', icon: AlertOctagon },
];

export function ProjectDetail({
  project,
  state,
  activeTab,
  onTabChange,
  onClose,
  deployments,
  incidents,
  history,
  logs,
  aiProvider,
  onProviderChange,
  onFetchHistory,
  onRefreshLogs,
  onExec,
  onAsk,
  onDeploy,
  onAcknowledge,
  onResolve,
  onRestart,
}: ProjectDetailProps) {
  const config = statusConfig[state.status];

  return (
    <div className="h-full flex flex-col glass-strong border-l border-white/[0.06]">
      {/* Detail header */}
      <div className="flex items-start justify-between p-5 border-b border-white/[0.06]">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h2 className="text-lg font-bold text-ink tracking-tight">{project.name}</h2>
            <span className={`tag ${config.color} ${config.bg} border-current/20`}>{config.label}</span>
          </div>
          <p className="text-xs text-ink-dim font-mono truncate max-w-md">
            {project.location.type === 'local' ? project.location.cwd : project.runtime.healthUrl}
          </p>
        </div>
        <button onClick={onClose} className="btn-tactical p-1.5">
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex overflow-x-auto scrollbar-thin border-b border-white/[0.06] px-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={cn(
                'flex items-center gap-2 px-4 py-3 text-[10px] font-bold tracking-[0.12em] uppercase border-b-2 transition-colors whitespace-nowrap',
                activeTab === tab.id ? 'text-ink border-accent' : 'text-ink-dim border-transparent hover:text-ink hover:border-white/10'
              )}
            >
              <Icon className="h-3.5 w-3.5" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Tab content */}
      <div className="flex-1 overflow-hidden p-5">
        {activeTab === 'overview' && (
          <div className="space-y-5 h-full overflow-auto scrollbar-thin pr-1">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Metric label="Status" value={config.label} color={config.color} />
              <Metric label="Latency" value={formatLatency(state.latencyMs)} />
              <Metric label="Uptime 24h" value={`${state.uptime24h}%`} />
              <Metric label="Restarts" value={state.restarts.toString()} />
            </div>

            {state.process && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <Metric label="PID" value={state.process.pid?.toString() || '—'} />
                <Metric label="CPU" value={`${state.process.cpuPct?.toFixed(1)}%`} />
                <Metric label="Memory" value={`${state.process.memMB} MB`} />
                <Metric label="Process Uptime" value={formatDuration(state.process.uptimeSec)} />
              </div>
            )}

            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-[10px] font-bold tracking-[0.15em] uppercase text-ink-dim">Latency History (24h)</p>
                <span className="text-[10px] text-ink-dim">last check {timeAgo(state.checkedAt)}</span>
              </div>
              <LatencyChart checks={history} onLoad={onFetchHistory} />
            </div>

            {project.source && (
              <div className="border border-white/5 bg-white/[0.02] p-3">
                <p className="text-[10px] font-bold tracking-[0.15em] uppercase text-ink-dim mb-2">Source</p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <span className="text-ink-dim block">Provider</span>
                    <span className="text-ink capitalize">{project.source.provider}</span>
                  </div>
                  <div>
                    <span className="text-ink-dim block">Repository</span>
                    <span className="text-ink font-mono">{project.source.repository || '—'}</span>
                  </div>
                  <div>
                    <span className="text-ink-dim block">Branch</span>
                    <span className="text-ink font-mono">{project.source.branch || '—'}</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'logs' && <LogViewer logs={logs} projectId={project.id} onRefresh={onRefreshLogs} />}
        {activeTab === 'terminal' && <TerminalPanel project={project} onExec={onExec} />}
        {activeTab === 'ai' && (
          <AIChat
            project={project}
            state={state}
            provider={aiProvider}
            onProviderChange={onProviderChange}
            onAsk={onAsk}
            onExecute={(tool) => {
              if (tool === 'restart_project') onRestart(project.id);
            }}
          />
        )}
        {activeTab === 'deploy' && <DeploymentPanel project={project} deployments={deployments} onDeploy={onDeploy} />}
        {activeTab === 'incidents' && (
          <IncidentPanel project={project} incidents={incidents} onAcknowledge={onAcknowledge} onResolve={onResolve} />
        )}
      </div>
    </div>
  );
}

function Metric({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <div className="bg-white/[0.02] border border-white/5 p-3">
      <p className="text-[9px] tracking-[0.15em] uppercase text-ink-dim mb-1">{label}</p>
      <p className={cn('text-sm font-bold tabular-nums text-ink', color)}>{value}</p>
    </div>
  );
}
