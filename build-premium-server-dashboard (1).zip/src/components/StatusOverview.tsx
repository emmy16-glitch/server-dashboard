import { Activity, AlertTriangle, CheckCircle2, PowerOff, RefreshCw, XCircle } from 'lucide-react';
import type { DashboardStats } from '@/types';
import { formatLatency } from '@/lib/status';

interface StatusOverviewProps {
  stats: DashboardStats;
}

const items = [
  { key: 'up' as const, label: 'UP', icon: CheckCircle2, color: 'text-up', bg: 'bg-up-dim', border: 'border-up/20' },
  { key: 'degraded' as const, label: 'DEGRADED', icon: AlertTriangle, color: 'text-degraded', bg: 'bg-degraded-dim', border: 'border-degraded/20' },
  { key: 'down' as const, label: 'DOWN', icon: XCircle, color: 'text-down', bg: 'bg-down-dim', border: 'border-down/20' },
  { key: 'starting' as const, label: 'STARTING', icon: RefreshCw, color: 'text-starting', bg: 'bg-starting-dim', border: 'border-starting/20' },
  { key: 'stopped' as const, label: 'STOPPED', icon: PowerOff, color: 'text-stopped', bg: 'bg-stopped-dim', border: 'border-stopped/20' },
];

export function StatusOverview({ stats }: StatusOverviewProps) {
  return (
    <section className="grid grid-cols-1 md:grid-cols-12 gap-4 mb-6">
      {/* Total + avg latency card */}
      <div className="md:col-span-3 panel p-5 relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
          <Activity className="h-16 w-16 text-ink" />
        </div>
        <p className="text-[10px] font-bold tracking-[0.2em] uppercase text-ink-dim mb-3">Fleet Health</p>
        <div className="flex items-baseline gap-3">
          <span className="text-5xl font-bold tabular-nums tracking-tight text-ink">{stats.total}</span>
          <span className="text-xs font-medium text-ink-muted uppercase tracking-wide">Projects</span>
        </div>
        <div className="mt-4 flex items-center gap-3 text-xs">
          <span className="text-ink-dim">Avg latency</span>
          <span className="font-semibold tabular-nums text-ink">{formatLatency(stats.avgLatency)}</span>
        </div>
        <div className="mt-2 flex items-center gap-3 text-xs">
          <span className="text-ink-dim">Open incidents</span>
          <span className={`font-semibold tabular-nums ${stats.openIncidents > 0 ? 'text-down' : 'text-up'}`}>{stats.openIncidents}</span>
        </div>
      </div>

      {/* Status distribution */}
      <div className="md:col-span-9 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {items.map((item) => {
          const value = stats[item.key];
          const percentage = stats.total > 0 ? Math.round((value / stats.total) * 100) : 0;
          return (
            <div
              key={item.key}
              className={`panel p-4 border ${item.border} flex flex-col justify-between hover:bg-white/[0.02] transition-colors`}
            >
              <div className="flex items-center justify-between mb-3">
                <item.icon className={`h-4 w-4 ${item.color}`} />
                <span className="text-[9px] font-bold tracking-[0.15em] uppercase text-ink-dim">{item.label}</span>
              </div>
              <div className="flex items-end justify-between">
                <span className="text-3xl font-bold tabular-nums text-ink">{value}</span>
                <span className="text-[10px] tabular-nums text-ink-dim mb-1">{percentage}%</span>
              </div>
              <div className="mt-3 h-1 w-full bg-white/5 overflow-hidden">
                <div
                  className={`h-full ${item.bg.replace('bg-', 'bg-').replace('-dim', '')} ${item.color.replace('text-', 'bg-')}`}
                  style={{ width: `${percentage}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
