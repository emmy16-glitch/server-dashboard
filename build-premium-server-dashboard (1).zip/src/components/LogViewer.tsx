import { useEffect, useRef } from 'react';
import { RefreshCw, Download, Terminal } from 'lucide-react';

interface LogViewerProps {
  logs: string[];
  projectId: string;
  onRefresh: (id: string) => void;
}

export function LogViewer({ logs, projectId, onRefresh }: LogViewerProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Terminal className="h-3.5 w-3.5 text-terminal" />
          <span className="text-[10px] font-bold tracking-[0.15em] uppercase text-ink-dim">Live Logs</span>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => onRefresh(projectId)} className="btn-tactical py-1 px-2 text-[9px]">
            <RefreshCw className="h-3 w-3" />
            Tail
          </button>
          <button className="btn-tactical py-1 px-2 text-[9px]">
            <Download className="h-3 w-3" />
            Export
          </button>
        </div>
      </div>

      <div className="flex-1 terminal p-4 overflow-auto scrollbar-thin border border-terminal/10">
        {logs.length === 0 ? (
          <p className="text-ink-dim opacity-50">No logs available. Click tail to fetch.</p>
        ) : (
          logs.map((line, i) => (
            <div key={i} className="whitespace-pre-wrap break-all py-0.5 hover:bg-white/5">
              <span className="text-ink-dim/60 mr-2">{(i + 1).toString().padStart(4, '0')}</span>
              <span>{line}</span>
            </div>
          ))
        )}
        <div ref={bottomRef} />
      </div>
    </div>
  );
}
