import { useEffect, useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import type { StatusCheck } from '@/types';

interface LatencyChartProps {
  checks: StatusCheck[];
  onLoad: () => void;
}

export function LatencyChart({ checks, onLoad }: LatencyChartProps) {
  useEffect(() => {
    onLoad();
  }, [onLoad]);

  const data = useMemo(() => {
    return checks.map((c) => ({
      time: new Date(c.ts).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }),
      latency: c.latencyMs,
      code: c.code,
    }));
  }, [checks]);

  if (checks.length === 0) {
    return (
      <div className="h-48 flex items-center justify-center border border-white/5 bg-white/[0.02]">
        <p className="text-xs text-ink-dim">No history available</p>
      </div>
    );
  }

  return (
    <div className="h-56 w-full border border-white/5 bg-white/[0.02] p-3">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -20 }}>
          <defs>
            <linearGradient id="latencyGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#2dd4a8" stopOpacity={0.25} />
              <stop offset="100%" stopColor="#2dd4a8" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke="rgba(255,255,255,0.04)" vertical={false} />
          <XAxis dataKey="time" tick={{ fill: '#5c5c66', fontSize: 10 }} axisLine={false} tickLine={false} minTickGap={40} />
          <YAxis tick={{ fill: '#5c5c66', fontSize: 10 }} axisLine={false} tickLine={false} />
          <Tooltip
            contentStyle={{
              background: '#111116',
              border: '1px solid rgba(255,255,255,0.08)',
              borderRadius: 0,
              fontSize: 11,
              color: '#f7f7f5',
            }}
            itemStyle={{ color: '#2dd4a8', fontFamily: 'JetBrains Mono, monospace' }}
            formatter={(value) => [`${value}ms`, 'latency']}
          />
          <Area
            type="monotone"
            dataKey="latency"
            stroke="#2dd4a8"
            strokeWidth={1.5}
            fill="url(#latencyGradient)"
            isAnimationActive={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
