import { useState, useRef, useEffect, useCallback } from 'react';
import { Bot, Send, Sparkles, AlertCircle, CheckCircle2, Cpu } from 'lucide-react';
import type { Project, ProjectState } from '@/types';


interface AIChatProps {
  project: Project;
  state: ProjectState;
  provider: 'opencode' | 'codex' | 'claude' | 'ollama';
  onProviderChange?: (provider: 'opencode' | 'codex' | 'claude' | 'ollama') => void;
  onAsk: (projectId: string, question: string) => Promise<{
    severity: string;
    likelyCause: string;
    confidence: number;
    evidence: string[];
    recommendedActions: string[];
    commands: string[];
    safeToAutoFix: boolean;
    raw: string;
  }>;
  onExecute?: (tool: string, args?: any) => void;
}

export function AIChat({ project, state, provider, onProviderChange, onAsk, onExecute }: AIChatProps) {
  const [messages, setMessages] = useState<{ role: 'user' | 'ai'; text: string; structured?: any }[]>([
    { role: 'ai', text: `Ready to diagnose ${project.name}. Ask me why it's ${state.status.toLowerCase()}.` },
  ]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const send = useCallback(async () => {
    if (!input.trim() || busy) return;
    const question = input;
    setInput('');
    setMessages((prev) => [...prev, { role: 'user', text: question }]);
    setBusy(true);
    try {
      const result = await onAsk(project.id, question);
      setMessages((prev) => [...prev, { role: 'ai', text: result.raw, structured: result }]);
    } catch (e) {
      setMessages((prev) => [...prev, { role: 'ai', text: `Error: ${e instanceof Error ? e.message : 'unknown'}` }]);
    } finally {
      setBusy(false);
    }
  }, [input, busy, onAsk, project.id]);

  const quickQuestions = [
    'Why is this degraded?',
    'Summarize recent logs',
    'Is it safe to restart?',
    'What changed in the last deploy?',
  ];

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Bot className="h-3.5 w-3.5 text-accent" />
          <span className="text-[10px] font-bold tracking-[0.15em] uppercase text-ink-dim">AI Helper</span>
        </div>
        <div className="flex items-center gap-2">
          <Cpu className="h-3 w-3 text-ink-dim" />
          <select
            value={provider}
            onChange={(e) => onProviderChange?.(e.target.value as any)}
            className="bg-white/5 border border-white/10 text-[10px] uppercase tracking-wider text-ink-dim py-1 px-2 focus:outline-none"
          >
            <option value="claude">Claude</option>
            <option value="codex">Codex</option>
            <option value="opencode">OpenCode</option>
            <option value="ollama">Ollama</option>
          </select>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-3">
        {quickQuestions.map((q) => (
          <button
            key={q}
            onClick={() => {
              setInput(q);
            }}
            className="text-[10px] px-2 py-1 border border-white/10 bg-white/[0.03] hover:bg-white/[0.06] text-ink-muted transition-colors"
          >
            {q}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-auto scrollbar-thin border border-white/5 bg-white/[0.02] p-4 mb-3">
        {messages.map((m, i) => (
          <div key={i} className={`mb-4 ${m.role === 'user' ? 'ml-6' : 'mr-6'}`}>
            <div className={`flex items-center gap-2 mb-1 ${m.role === 'user' ? 'justify-end' : ''}`}>
              {m.role === 'ai' && <Bot className="h-3 w-3 text-accent" />}
              <span className={`text-[10px] font-bold uppercase tracking-wider ${m.role === 'user' ? 'text-ink-dim' : 'text-accent'}`}>
                {m.role}
              </span>
              {m.role === 'user' && <Sparkles className="h-3 w-3 text-ink-dim" />}
            </div>
            <div
              className={`text-xs leading-relaxed whitespace-pre-wrap p-3 ${
                m.role === 'user' ? 'bg-white/5 text-ink border border-white/10' : 'bg-accent-dim/30 text-ink border border-accent/10'
              }`}
            >
              {m.text}
            </div>
            {m.structured && (
              <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="bg-white/[0.02] border border-white/5 p-2">
                  <p className="text-[9px] uppercase text-ink-dim mb-1">Likely Cause</p>
                  <p className="text-xs text-ink">{m.structured.likelyCause}</p>
                </div>
                <div className="bg-white/[0.02] border border-white/5 p-2">
                  <p className="text-[9px] uppercase text-ink-dim mb-1">Confidence</p>
                  <p className="text-xs text-ink">{Math.round(m.structured.confidence * 100)}%</p>
                </div>
                {m.structured.evidence.map((ev: string, idx: number) => (
                  <div key={idx} className="flex items-start gap-2 bg-white/[0.02] border border-white/5 p-2">
                    <AlertCircle className="h-3 w-3 text-degraded mt-0.5 shrink-0" />
                    <p className="text-xs text-ink">{ev}</p>
                  </div>
                ))}
              </div>
            )}
            {m.structured?.safeToAutoFix && onExecute && (
              <div className="mt-2 flex items-center gap-2">
                <button onClick={() => onExecute('restart_project')} className="btn-primary text-[9px] py-1 px-2">
                  <CheckCircle2 className="h-3 w-3" />
                  Approve Restart
                </button>
              </div>
            )}
          </div>
        ))}
        {busy && (
          <div className="flex items-center gap-2 text-xs text-ink-dim animate-pulse">
            <Sparkles className="h-3 w-3" />
            reasoning…
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
        className="flex items-center gap-2"
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={busy}
          placeholder="ask the AI helper…"
          className="flex-1 bg-white/5 border border-white/10 text-ink text-xs px-3 py-2 focus:outline-none focus:border-accent/40 placeholder:text-ink-dim/40"
        />
        <button type="submit" disabled={busy || !input.trim()} className="btn-primary py-2 px-3">
          <Send className="h-3 w-3" />
          Ask
        </button>
      </form>
    </div>
  );
}
