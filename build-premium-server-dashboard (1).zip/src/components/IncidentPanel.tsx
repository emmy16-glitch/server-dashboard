import { AlertTriangle, CheckCircle2, Eye, AlertOctagon, Clock } from 'lucide-react';
import type { Incident, Project } from '@/types';
import { timeAgo } from '@/lib/status';

interface IncidentPanelProps {
  project: Project;
  incidents: Incident[];
  onAcknowledge: (id: string, note?: string) => void;
  onResolve: (id: string, note?: string) => void;
}

const stateClasses = {
  open: 'text-down',
  acknowledged: 'text-degraded',
  resolved: 'text-up',
};

export function IncidentPanel({ project, incidents, onAcknowledge, onResolve }: IncidentPanelProps) {
  const projectIncidents = incidents.filter((i) => i.projectId === project.id);

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <AlertOctagon className="h-3.5 w-3.5 text-down" />
          <span className="text-[10px] font-bold tracking-[0.15em] uppercase text-ink-dim">Incidents</span>
        </div>
      </div>

      <div className="flex-1 overflow-auto scrollbar-thin pr-1">
        {projectIncidents.length === 0 ? (
          <div className="h-40 flex items-center justify-center border border-white/5 bg-white/[0.02]">
            <p className="text-xs text-ink-dim">No incidents for this project</p>
          </div>
        ) : (
          <div className="space-y-3">
            {projectIncidents.map((incident) => (
              <div key={incident.id} className="border border-white/5 bg-white/[0.02] p-3">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-semibold text-ink">{incident.id}</span>
                      <span className={`tag ${stateClasses[incident.state]} bg-white/[0.03] border-current/20`}>
                        {incident.state === 'open' && <AlertTriangle className="h-3 w-3" />}
                        {incident.state === 'acknowledged' && <Eye className="h-3 w-3" />}
                        {incident.state === 'resolved' && <CheckCircle2 className="h-3 w-3" />}
                        {incident.state}
                      </span>
                    </div>
                    <p className="text-xs text-ink mb-1">{incident.cause}</p>
                    <p className="text-[10px] text-ink-dim flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {timeAgo(incident.startedAt)} • {incident.recoveryAttempts} recovery attempt
                      {incident.recoveryAttempts !== 1 ? 's' : ''}
                    </p>
                  </div>
                  <div className="flex items-center gap-1">
                    {incident.state === 'open' && (
                      <button onClick={() => onAcknowledge(incident.id, 'Acknowledged from dashboard')} className="btn-tactical text-[9px] py-1 px-2">
                        Ack
                      </button>
                    )}
                    {(incident.state === 'open' || incident.state === 'acknowledged') && (
                      <button onClick={() => onResolve(incident.id, 'Resolved from dashboard')} className="btn-primary text-[9px] py-1 px-2">
                        Resolve
                      </button>
                    )}
                  </div>
                </div>
                {incident.timeline.length > 0 && (
                  <div className="mt-2 border-t border-white/5 pt-2 space-y-1">
                    {incident.timeline.map((t, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-[10px]">
                        <span className="text-ink-dim font-mono shrink-0">{new Date(t.ts).toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' })}</span>
                        <span className="text-ink-muted">{t.note}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
