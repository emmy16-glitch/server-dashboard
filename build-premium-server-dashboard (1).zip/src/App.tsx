import { useState, useMemo } from 'react';
import { Plus, Search, SlidersHorizontal, Terminal, Activity } from 'lucide-react';
import { DashboardHeader } from '@/components/DashboardHeader';
import { StatusOverview } from '@/components/StatusOverview';
import { ProjectCard } from '@/components/ProjectCard';
import { ProjectDetail } from '@/components/ProjectDetail';
import { AddProjectModal } from '@/components/AddProjectModal';
import { useDashboard } from '@/hooks/useDashboard';


export default function App() {
  const {
    projects,
    states,
    stats,
    selectedProject,
    selectedProjectId,
    setSelectedProjectId,
    activeTab,
    setActiveTab,
    deployments,
    incidents,
    history,
    logs,
    fetchHistory,
    fetchLogs,
    refreshLogs,
    startProject,
    stopProject,
    restartProject,
    deployProject,
    runTerminalCommand,
    askAI,
    acknowledgeIncident,
    resolveIncident,
    addProject,
    aiProvider,
    setAiProvider,
  } = useDashboard();

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const filteredProjects = useMemo(() => {
    return projects.filter((p) => {
      const state = states[p.id];
      const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase()) || p.id.toLowerCase().includes(search.toLowerCase());
      const matchesStatus = statusFilter === 'all' || state?.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [projects, states, search, statusFilter]);

  return (
    <div className="min-h-screen flex flex-col">
      <DashboardHeader />

      <main className="flex-1 p-5 lg:p-8 overflow-hidden">
        <StatusOverview stats={stats} />

        <div className="flex flex-col lg:flex-row gap-6 h-[calc(100vh-14rem)]">
          {/* Project list */}
          <section className="flex flex-col lg:w-5/12 xl:w-1/2 h-full">
            <div className="flex items-center justify-between mb-4 gap-3">
              <div className="flex items-center gap-2">
                <Terminal className="h-4 w-4 text-ink-dim" />
                <h2 className="text-xs font-bold tracking-[0.15em] uppercase text-ink">Projects</h2>
                <span className="tag border-white/10 bg-white/[0.03] text-ink-dim">{filteredProjects.length}</span>
              </div>
              <button onClick={() => setIsAddModalOpen(true)} className="btn-primary py-1.5 px-3">
                <Plus className="h-3.5 w-3.5" />
                Add
              </button>
            </div>

            <div className="flex items-center gap-3 mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-ink-dim" />
                <input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Filter projects…"
                  className="w-full bg-white/5 border border-white/10 text-ink text-xs pl-9 pr-3 py-2 focus:outline-none focus:border-accent/40 placeholder:text-ink-dim/40"
                />
              </div>
              <div className="relative">
                <SlidersHorizontal className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-ink-dim" />
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="bg-white/5 border border-white/10 text-ink text-xs pl-8 pr-6 py-2 focus:outline-none focus:border-accent/40 appearance-none"
                >
                  <option value="all">All statuses</option>
                  <option value="UP">UP</option>
                  <option value="DEGRADED">DEGRADED</option>
                  <option value="DOWN">DOWN</option>
                  <option value="STARTING">STARTING</option>
                  <option value="STOPPED">STOPPED</option>
                </select>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto scrollbar-thin pr-2 space-y-3 pb-4">
              {filteredProjects.length === 0 ? (
                <div className="h-40 flex flex-col items-center justify-center border border-white/5 bg-white/[0.02] text-ink-dim">
                  <Activity className="h-6 w-6 mb-2 opacity-30" />
                  <p className="text-xs">No projects match your filters</p>
                </div>
              ) : (
                filteredProjects.map((project) => (
                  <ProjectCard
                    key={project.id}
                    project={project}
                    state={states[project.id]}
                    isSelected={selectedProjectId === project.id}
                    onSelect={(id) => {
                      setSelectedProjectId(id);
                      fetchLogs(id);
                    }}
                    onStart={startProject}
                    onStop={stopProject}
                    onRestart={restartProject}
                  />
                ))
              )}
            </div>
          </section>

          {/* Project detail */}
          <section className="lg:w-7/12 xl:w-1/2 h-full min-h-[400px]">
            {selectedProject ? (
              <ProjectDetail
                project={selectedProject}
                state={states[selectedProject.id]}
                activeTab={activeTab}
                onTabChange={setActiveTab}
                onClose={() => setSelectedProjectId(null)}
                deployments={deployments}
                incidents={incidents}
                history={history[selectedProject.id] || []}
                logs={logs[selectedProject.id] || []}
                aiProvider={aiProvider}
                onProviderChange={setAiProvider}
                onFetchHistory={() => fetchHistory(selectedProject.id)}
                onRefreshLogs={() => refreshLogs(selectedProject.id)}
                onExec={runTerminalCommand}
                onAsk={askAI}
                onDeploy={deployProject}
                onAcknowledge={acknowledgeIncident}
                onResolve={resolveIncident}
                onRestart={restartProject}
              />
            ) : (
              <div className="h-full flex flex-col items-center justify-center border border-white/5 bg-white/[0.02] text-ink-dim">
                <Activity className="h-10 w-10 mb-3 opacity-20" />
                <p className="text-sm font-medium">Select a project to inspect</p>
              </div>
            )}
          </section>
        </div>
      </main>

      <AddProjectModal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} onAdd={addProject} />
    </div>
  );
}
