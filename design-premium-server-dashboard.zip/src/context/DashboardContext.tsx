import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  DesignState,
  MaterialType,
  CompositionType,
  StructureType,
  FeelingType,
  Project,
  Incident,
  DeploymentRecord,
  AuditRecord,
  AgentNode,
  TemplateItem,
  AiDiagnosis,
} from '../types/dashboard';
import {
  INITIAL_PROJECTS,
  INITIAL_INCIDENTS,
  INITIAL_DEPLOYMENTS,
  INITIAL_AUDIT_LOGS,
  INITIAL_AGENTS,
  INITIAL_TEMPLATES,
  MOCK_PROJECT_LOGS,
} from '../data/mockData';

interface DashboardContextType {
  design: DesignState;
  setDesign: React.Dispatch<React.SetStateAction<DesignState>>;
  setMaterial: (m: MaterialType) => void;
  setComposition: (c: CompositionType) => void;
  setStructure: (s: StructureType) => void;
  setFeeling: (f: FeelingType) => void;
  applyPreset: (presetName: string) => void;

  projects: Project[];
  activeProject: Project | null;
  activeProjectId: string | null;
  setActiveProjectId: (id: string | null) => void;

  logs: Record<string, string[]>;
  incidents: Incident[];
  deployments: DeploymentRecord[];
  auditLogs: AuditRecord[];
  agents: AgentNode[];
  templates: TemplateItem[];

  filterStatus: string;
  setFilterStatus: (s: string) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;

  isReadOnlyMode: boolean;
  setIsReadOnlyMode: (ro: boolean) => void;
  authToken: string;
  rotateAuthToken: () => void;

  // Actions
  startProject: (id: string) => Promise<void>;
  stopProject: (id: string) => Promise<void>;
  restartProject: (id: string) => Promise<void>;
  runHealthCheck: (id: string) => Promise<void>;
  triggerDeploy: (id: string, customSha?: string) => Promise<void>;
  rollbackDeploy: (id: string, targetDepId: string) => Promise<void>;
  executeTerminal: (id: string, commandStr: string, isAdmin?: boolean) => Promise<{ exitCode: number; stdout: string; stderr: string }>;
  askAiDiagnosis: (id: string, question: string, provider?: 'opencode' | 'codex' | 'claude' | 'ollama') => Promise<AiDiagnosis>;
  executeAiFix: (id: string, tool: string, args: Record<string, any>) => Promise<boolean>;
  acknowledgeIncident: (id: string, note?: string) => void;
  resolveIncident: (id: string, note?: string, fixSummary?: string) => void;
  addNewProject: (proj: Partial<Project>) => void;

  // Audio effects
  playHapticAudio: (sound: 'click' | 'alarm' | 'deploy' | 'beep' | 'toggle') => void;
  lastSyncTime: string;
}

const DashboardContext = createContext<DashboardContextType | undefined>(undefined);

export const DashboardProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [design, setDesign] = useState<DesignState>({
    material: 'glass',
    composition: 'editorial',
    structure: 'swiss',
    feeling: 'tactical',
    soundEnabled: true,
    scanlines: false,
  });

  const [projects, setProjects] = useState<Project[]>(INITIAL_PROJECTS);
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [logs, setLogs] = useState<Record<string, string[]>>(MOCK_PROJECT_LOGS);
  const [incidents, setIncidents] = useState<Incident[]>(INITIAL_INCIDENTS);
  const [deployments, setDeployments] = useState<DeploymentRecord[]>(INITIAL_DEPLOYMENTS);
  const [auditLogs, setAuditLogs] = useState<AuditRecord[]>(INITIAL_AUDIT_LOGS);
  const [agents] = useState<AgentNode[]>(INITIAL_AGENTS);
  const [templates] = useState<TemplateItem[]>(INITIAL_TEMPLATES);

  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isReadOnlyMode, setIsReadOnlyMode] = useState<boolean>(false);
  const [authToken, setAuthToken] = useState<string>('srv_tok_991fa8e2003c41');
  const [lastSyncTime, setLastSyncTime] = useState<string>('Just now');

  const activeProject = projects.find((p) => p.id === activeProjectId) || null;

  // Web Audio synth for tactical feedback
  const playHapticAudio = useCallback((type: 'click' | 'alarm' | 'deploy' | 'beep' | 'toggle') => {
    if (!design.soundEnabled) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      const now = ctx.currentTime;
      if (type === 'click') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(800, now);
        osc.frequency.exponentialRampToValueAtTime(300, now + 0.04);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
        osc.start(now);
        osc.stop(now + 0.04);
      } else if (type === 'toggle') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(520, now);
        osc.frequency.setValueAtTime(780, now + 0.03);
        gain.gain.setValueAtTime(0.07, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
        osc.start(now);
        osc.stop(now + 0.08);
      } else if (type === 'beep') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, now);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
        osc.start(now);
        osc.stop(now + 0.1);
      } else if (type === 'alarm') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.setValueAtTime(320, now + 0.1);
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
        osc.start(now);
        osc.stop(now + 0.25);
      } else if (type === 'deploy') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.15);
        gain.gain.setValueAtTime(0.09, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
        osc.start(now);
        osc.stop(now + 0.18);
      }
    } catch {
      // AudioContext policy handled quietly
    }
  }, [design.soundEnabled]);

  // Periodic simulated check & jitter
  useEffect(() => {
    const interval = setInterval(() => {
      setLastSyncTime(new Date().toLocaleTimeString());
      // Small latency jitter for living pulse
      setProjects((prev) =>
        prev.map((p) => {
          if (p.status === 'UP') {
            const jitter = (Math.random() - 0.45) * 4;
            const newLat = Math.max(8, Number((p.currentLatency + jitter).toFixed(1)));
            return {
              ...p,
              currentLatency: newLat,
              history: [
                ...p.history.slice(1),
                { ts: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), code: 200, latencyMs: newLat },
              ],
            };
          }
          return p;
        })
      );
    }, 15000);
    return () => clearInterval(interval);
  }, []);

  const setMaterial = (material: MaterialType) => {
    playHapticAudio('toggle');
    setDesign((prev) => ({
      ...prev,
      material,
      scanlines: material === 'terminal',
    }));
  };

  const setComposition = (composition: CompositionType) => {
    playHapticAudio('toggle');
    setDesign((prev) => ({ ...prev, composition }));
  };

  const setStructure = (structure: StructureType) => {
    playHapticAudio('toggle');
    setDesign((prev) => ({ ...prev, structure }));
  };

  const setFeeling = (feeling: FeelingType) => {
    playHapticAudio('toggle');
    setDesign((prev) => ({ ...prev, feeling }));
  };

  const applyPreset = (presetName: string) => {
    playHapticAudio('click');
    switch (presetName) {
      case 'Tactical Industrial Panel':
        setDesign({
          material: 'industrial panel',
          composition: 'dense',
          structure: 'brutalist',
          feeling: 'tactical',
          soundEnabled: true,
          scanlines: false,
        });
        break;
      case 'Swiss Studio Glass':
        setDesign({
          material: 'glass',
          composition: 'spacious',
          structure: 'swiss',
          feeling: 'precise',
          soundEnabled: true,
          scanlines: false,
        });
        break;
      case 'Tokyo Minimalist Paper':
        setDesign({
          material: 'paper',
          composition: 'asymmetric',
          structure: 'japanese minimal',
          feeling: 'quiet',
          soundEnabled: true,
          scanlines: false,
        });
        break;
      case 'CRT Phosphor Terminal':
        setDesign({
          material: 'terminal',
          composition: 'dense',
          structure: 'brutalist',
          feeling: 'tactical',
          soundEnabled: true,
          scanlines: true,
        });
        break;
      case 'Bloomberg Financial Monolith':
        setDesign({
          material: 'industrial panel',
          composition: 'dense',
          structure: 'financial',
          feeling: 'precise',
          soundEnabled: true,
          scanlines: false,
        });
        break;
      case 'Archival Broadsheet Editorial':
        setDesign({
          material: 'paper',
          composition: 'editorial',
          structure: 'swiss',
          feeling: 'quiet',
          soundEnabled: true,
          scanlines: false,
        });
        break;
      case 'Playful Cyber Ops':
        setDesign({
          material: 'glass',
          composition: 'asymmetric',
          structure: 'brutalist',
          feeling: 'playful',
          soundEnabled: true,
          scanlines: false,
        });
        break;
      default:
        break;
    }
  };

  const rotateAuthToken = () => {
    playHapticAudio('click');
    const newTok = 'srv_tok_' + Math.random().toString(36).substring(2, 12) + Math.random().toString(36).substring(2, 6);
    setAuthToken(newTok);
    addAuditEntry('bearer_token', 'local', 'exec_command', 'Rotated dashboard auth bearer token');
  };

  const addAuditEntry = (
    actor: string,
    projectId: string,
    action: AuditRecord['action'],
    details: string,
    result: 'success' | 'denied' | 'failed' = 'success'
  ) => {
    const newEntry: AuditRecord = {
      id: `aud-${Date.now().toString().slice(-4)}`,
      ts: new Date().toLocaleTimeString(),
      actor,
      projectId,
      action,
      argsHash: `sha256:${Math.random().toString(36).substring(2, 9)}`,
      details,
      result,
    };
    setAuditLogs((prev) => [newEntry, ...prev]);
  };

  const appendLog = (projectId: string, line: string) => {
    const formatted = `[${new Date().toISOString().replace('T', ' ').slice(0, 23)}] ${line}`;
    setLogs((prev) => ({
      ...prev,
      [projectId]: [...(prev[projectId] || []), formatted],
    }));
  };

  // Process Controls
  const startProject = async (id: string) => {
    if (isReadOnlyMode) return;
    playHapticAudio('click');
    appendLog(id, '[INFO] [supervisor] Manual start requested by operator');
    setProjects((prev) =>
      prev.map((p) => (p.id === id ? { ...p, status: 'STARTING' } : p))
    );

    await new Promise((r) => setTimeout(r, 1400));

    const newPid = Math.floor(20000 + Math.random() * 9000);
    appendLog(id, `[INFO] [process] Spawned PID ${newPid} in ${projects.find((p) => p.id === id)?.location.cwd || '.'}`);
    appendLog(id, '[INFO] [probe] Verification pass 1/3: HTTP 200 OK (14ms)');

    setProjects((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              ...p,
              status: 'UP',
              currentLatency: 14.5,
              process: {
                pid: newPid,
                alive: true,
                cpuPct: 12.4,
                memMB: 180.5,
                uptimeSec: 1,
                restarts: p.process ? p.process.restarts : 0,
              },
            }
          : p
      )
    );
    addAuditEntry('bearer_token:admin_ops', id, 'process_start', `Started process PID ${newPid}`);
    playHapticAudio('beep');
  };

  const stopProject = async (id: string) => {
    if (isReadOnlyMode) return;
    playHapticAudio('click');
    appendLog(id, '[WARN] [supervisor] SIGTERM dispatched to process tree');
    setProjects((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              ...p,
              status: 'STOPPED',
              currentLatency: 0,
              process: p.process ? { ...p.process, alive: false, cpuPct: 0, memMB: 0, uptimeSec: 0 } : undefined,
            }
          : p
      )
    );
    addAuditEntry('bearer_token:admin_ops', id, 'process_stop', 'Sent SIGTERM and cleaned pid lock');
  };

  const restartProject = async (id: string) => {
    if (isReadOnlyMode) return;
    playHapticAudio('click');
    appendLog(id, '[INFO] [supervisor] Restarting process: SIGTERM -> wait 3s -> spawn');
    setProjects((prev) =>
      prev.map((p) => (p.id === id ? { ...p, status: 'STARTING' } : p))
    );

    await new Promise((r) => setTimeout(r, 1500));

    const newPid = Math.floor(20000 + Math.random() * 9000);
    appendLog(id, `[INFO] [supervisor] Warmup complete. PID ${newPid} active, listening on port`);
    appendLog(id, '[INFO] [health] /health probe asserts satisfied {"database":"connected"}');

    setProjects((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              ...p,
              status: 'UP',
              hasIncident: false,
              currentLatency: 16.8,
              process: p.process
                ? {
                    ...p.process,
                    pid: newPid,
                    alive: true,
                    cpuPct: 22.1,
                    memMB: 210.4,
                    uptimeSec: 1,
                    restarts: p.process.restarts + 1,
                  }
                : undefined,
            }
          : p
      )
    );

    // If there is an open incident for this project, resolve it or note restart
    setIncidents((prev) =>
      prev.map((inc) =>
        inc.projectId === id && inc.state !== 'resolved'
          ? {
              ...inc,
              state: 'resolved',
              resolvedAt: 'Just now',
              timeline: [
                ...inc.timeline,
                { ts: new Date().toLocaleTimeString(), event: `Manual process restart cleared error (PID ${newPid})`, actor: 'operator' },
              ],
            }
          : inc
      )
    );

    addAuditEntry('bearer_token:admin_ops', id, 'process_restart', `Restarted process to PID ${newPid}`);
    playHapticAudio('beep');
  };

  const runHealthCheck = async (id: string) => {
    playHapticAudio('click');
    const start = performance.now();
    await new Promise((r) => setTimeout(r, 400));
    const lat = Math.round(performance.now() - start + 12);
    setProjects((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              ...p,
              currentLatency: lat,
              lastChecked: 'Just now',
              history: [
                ...p.history.slice(1),
                { ts: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), code: 200, latencyMs: lat },
              ],
            }
          : p
      )
    );
    appendLog(id, `[INFO] [probe] Manual HTTP health check ok (code 200, ${lat}ms)`);
  };

  // Deploy pipeline
  const triggerDeploy = async (id: string, customSha?: string) => {
    if (isReadOnlyMode) return;
    playHapticAudio('deploy');
    const proj = projects.find((p) => p.id === id);
    const newSha = customSha || Math.random().toString(16).substring(2, 9);
    const depId = `dep-${Math.floor(100 + Math.random() * 900)}`;

    const newDep: DeploymentRecord = {
      id: depId,
      projectId: id,
      sha: newSha,
      branch: proj?.source?.branch || 'main',
      startedAt: 'Just now',
      status: 'running',
      commitMessage: customSha ? `deploy(${customSha}): requested by operator` : 'chore(ops): trigger hot reload & schema migration',
      author: 'emmy16-glitch',
      durationSec: 0,
      buildTail: [
        `$ git fetch origin ${proj?.source?.branch || 'main'}`,
        `Checked out sha ${newSha}`,
        '$ npm install --prefer-offline',
        'Running build hooks...',
      ],
    };

    setDeployments((prev) => [newDep, ...prev]);
    appendLog(id, `[INFO] [deploy] Starting deploy ${depId} for commit ${newSha}`);

    await new Promise((r) => setTimeout(r, 1600));

    // Finish deploy
    setDeployments((prev) =>
      prev.map((d) =>
        d.id === depId
          ? {
              ...d,
              status: 'success',
              endedAt: 'Just now',
              durationSec: 42,
              buildTail: [
                ...d.buildTail,
                'TypeScript build complete in 4.2s',
                'Pre-deploy hook executed: schema valid',
                'Restarting process with zero downtime...',
                'Gate check 3/3 passed (status 200, latency 14ms)',
                `✅ Deploy ${depId} live on ${newSha}`,
              ],
            }
          : d
      )
    );

    setProjects((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              ...p,
              status: 'UP',
              hasIncident: false,
              source: p.source ? { ...p.source, currentSha: newSha } : undefined,
            }
          : p
      )
    );

    addAuditEntry('bearer_token:admin_ops', id, 'deploy', `Deployed sha ${newSha} via git pipeline`);
    playHapticAudio('beep');
  };

  const rollbackDeploy = async (id: string, targetDepId: string) => {
    if (isReadOnlyMode) return;
    playHapticAudio('alarm');
    const target = deployments.find((d) => d.id === targetDepId);
    if (!target) return;

    appendLog(id, `[WARN] [deploy] Initiating 1-click rollback to deployment ${target.id} (${target.sha})`);
    await new Promise((r) => setTimeout(r, 1200));

    setProjects((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              ...p,
              status: 'UP',
              hasIncident: false,
              source: p.source ? { ...p.source, currentSha: target.sha } : undefined,
            }
          : p
      )
    );

    addAuditEntry('bearer_token:admin_ops', id, 'rollback', `Rolled back to sha ${target.sha}`);
  };

  // Safe terminal command executor
  const executeTerminal = async (
    id: string,
    commandStr: string,
    isAdmin = false
  ): Promise<{ exitCode: number; stdout: string; stderr: string }> => {
    if (isReadOnlyMode) {
      return { exitCode: 1, stdout: '', stderr: 'Permission denied: Read-only mode active' };
    }
    playHapticAudio('click');
    const trimmed = commandStr.trim();
    const parts = trimmed.split(/\s+/);
    const cmd = parts[0];
    const args = parts.slice(1);

    const safeAllowlist = ['npm', 'node', 'git', 'df', 'free', 'ls', 'cat', 'pwd', 'ps', 'curl', 'echo', 'uptime', 'python3', 'ollama'];

    if (!isAdmin && !safeAllowlist.includes(cmd)) {
      addAuditEntry('bearer_token', id, 'exec_command', `Denied command: "${trimmed}" outside safe allowlist`, 'denied');
      return {
        exitCode: 403,
        stdout: '',
        stderr: `403 FORBIDDEN: Command "${cmd}" is not in the Safe Mode allowlist. Enable Admin mode to run free shell commands (with audit).`,
      };
    }

    addAuditEntry('bearer_token', id, 'exec_command', `Executed: ${trimmed} (${isAdmin ? 'ADMIN' : 'SAFE'})`, 'success');

    // Simulate responses for common ops queries
    if (cmd === 'df' || trimmed === 'df -h') {
      return {
        exitCode: 0,
        stdout: `Filesystem      Size  Used Avail Use% Mounted on\n/dev/root       128G   43G   85G  34% /\ntmpfs           3.8G  1.2M  3.8G   1% /dev/shm\n/dev/sda1       960G  182G  778G  19% /mnt/storage`,
        stderr: '',
      };
    }
    if (cmd === 'free' || trimmed === 'free -m') {
      return {
        exitCode: 0,
        stdout: `               total        used        free      shared  buff/cache   available\nMem:            7680        1840        4210         112        1630        5612\nSwap:           2048           0        2048`,
        stderr: '',
      };
    }
    if (cmd === 'git' && args[0] === 'status') {
      return {
        exitCode: 0,
        stdout: `On branch main\nYour branch is up to date with 'origin/main'.\n\nnothing to commit, working tree clean`,
        stderr: '',
      };
    }
    if (cmd === 'git' && args[0] === 'log') {
      return {
        exitCode: 0,
        stdout: `* a83f91d (HEAD -> main) refactor(worker): pool connection resilience & healthcheck probe\n* c42e19b fix(auth): sanitize JWT bearer header validation\n* 990f3ac feat(stream): experimental Opus chunk streaming pipeline`,
        stderr: '',
      };
    }
    if (cmd === 'ps' || trimmed.includes('grep node')) {
      return {
        exitCode: 0,
        stdout: `USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND\nroot       24190 22.4  3.7 942180 291044 ?       Sl   10:35   0:42 node dist/server.js\nroot       18902  8.2 12.2 1420912 962560 ?      Sl   09:12   2:18 ollama serve`,
        stderr: '',
      };
    }
    if (cmd === 'npm' && args[0] === 'run' && args[1] === 'build') {
      return {
        exitCode: 0,
        stdout: `> build\n> tsc -p tsconfig.json && vite build\n\nvite v7.3.2 building for production...\n✓ 42 modules transformed.\ndist/index.html   1.21 kB\ndist/assets/index.js   142.10 kB\n✓ built in 1.48s`,
        stderr: '',
      };
    }
    if (cmd === 'pwd') {
      return {
        exitCode: 0,
        stdout: projects.find((p) => p.id === id)?.location.cwd || '/root/projects',
        stderr: '',
      };
    }

    return {
      exitCode: 0,
      stdout: `[safe-exec OK] Command completed successfully (${trimmed})\nExit code: 0`,
      stderr: '',
    };
  };

  // AI Diagnosis (Explain -> Propose -> Execute)
  const askAiDiagnosis = async (
    id: string,
    question: string,
    provider: 'opencode' | 'codex' | 'claude' | 'ollama' = 'claude'
  ): Promise<AiDiagnosis> => {
    playHapticAudio('beep');
    const isDegraded = projects.find((p) => p.id === id)?.status === 'DEGRADED';

    await new Promise((r) => setTimeout(r, 1100));

    const diagnosis: AiDiagnosis = {
      id: `ai-diag-${Date.now()}`,
      projectId: id,
      timestamp: new Date().toLocaleTimeString(),
      question,
      provider,
      severity: isDegraded ? 'high' : 'low',
      likelyCause: isDegraded
        ? 'Postgres database connection pool saturation causing /health assertion failure {"database":"connected"} with 912ms timeout'
        : 'All telemetry metrics healthy; service operating within normal latency baseline (14-35ms).',
      confidence: isDegraded ? 0.94 : 0.98,
      evidence: isDegraded
        ? [
            'Log line 10:28:02: "Pool client acquisition time exceeded 450ms (activeClients: 19/20)"',
            'Log line 10:30:02: "Error: Connection terminated unexpectedly at Connection.parseE"',
            'Health check returned HTTP 502 with Gateway Timeout (912ms)',
            'Auto-restart counter incremented to 3 retries in 15 minutes',
          ]
        : ['HTTP 200 response code on /health', 'Memory 284 MB within safe ceiling (1024 MB)', 'No unhandled promise rejections in last 2000 lines'],
      recommendedActions: isDegraded
        ? [
            'Drain stale socket connections and cycle Node process supervisor (graceful SIGTERM)',
            'Scale connection pool max parameter from 20 to 35 in .env (DB_POOL_MAX)',
            'Verify PostgreSQL backend socket responds to pg_isready on 127.0.0.1:5432',
          ]
        : ['No action necessary. Consider running automated load test before peak hours.'],
      commands: isDegraded
        ? ['kill -15 24190 && npm run start', 'pg_isready -h localhost -p 5432', 'npm run pre-deploy-verify']
        : ['npm test', 'git status'],
      safeToAutoFix: isDegraded,
      rawAnalysis: isDegraded
        ? `[AI DIAGNOSIS - ${provider.toUpperCase()}]\nTarget: ${id}\nRoot Cause: Database pool exhaustion during batch audio ingestion.\nThe supervisor detected 3 failed health probes. Memory is steady at 284 MB, meaning no memory leak, but Postgres clients became orphaned.\nRecommendation: Execute safe process restart to reset client pool and run health check gate.`
        : `[AI DIAGNOSIS - ${provider.toUpperCase()}]\nTarget: ${id}\nSystem is nominal. No anomalies detected in process memory or latency trends.`,
    };

    return diagnosis;
  };

  const executeAiFix = async (id: string, tool: string, args: Record<string, any>): Promise<boolean> => {
    if (isReadOnlyMode) return false;
    playHapticAudio('deploy');
    addAuditEntry('ai-assistant:safe-tool', id, 'ai_fix_execute', `AI tool executed: ${tool} args: ${JSON.stringify(args)}`);

    if (tool === 'restart_project') {
      await restartProject(id);
      return true;
    }
    if (tool === 'run_safe_command' && args.cmd) {
      await executeTerminal(id, args.cmd, false);
      return true;
    }
    if (tool === 'deploy_project') {
      await triggerDeploy(id);
      return true;
    }
    return true;
  };

  const acknowledgeIncident = (id: string, note?: string) => {
    playHapticAudio('click');
    setIncidents((prev) =>
      prev.map((inc) =>
        inc.id === id
          ? {
              ...inc,
              state: 'acknowledged',
              timeline: [
                ...inc.timeline,
                { ts: new Date().toLocaleTimeString(), event: `Acknowledged by operator: ${note || 'Investigating issue'}`, actor: 'operator' },
              ],
            }
          : inc
      )
    );
    addAuditEntry('bearer_token:admin_ops', 'echoo-backend', 'incident_ack', `Acknowledged incident ${id}`);
  };

  const resolveIncident = (id: string, note?: string, fixSummary?: string) => {
    playHapticAudio('beep');
    setIncidents((prev) =>
      prev.map((inc) =>
        inc.id === id
          ? {
              ...inc,
              state: 'resolved',
              resolvedAt: 'Just now',
              timeline: [
                ...inc.timeline,
                {
                  ts: new Date().toLocaleTimeString(),
                  event: `Resolved: ${note || 'Issue remediated and verified'}${fixSummary ? ` [Memory Saved: ${fixSummary}]` : ''}`,
                  actor: 'operator',
                },
              ],
            }
          : inc
      )
    );

    // Also update project to UP
    const targetInc = incidents.find((i) => i.id === id);
    if (targetInc) {
      setProjects((prev) =>
        prev.map((p) => (p.id === targetInc.projectId ? { ...p, status: 'UP', hasIncident: false } : p))
      );
    }

    addAuditEntry('bearer_token:admin_ops', targetInc?.projectId || 'unknown', 'incident_resolve', `Resolved incident ${id}: ${note || 'Fixed'}`);
  };

  const addNewProject = (newProj: Partial<Project>) => {
    playHapticAudio('click');
    const slug = (newProj.name || 'new-app').toLowerCase().replace(/[^a-z0-9]/g, '-');
    const created: Project = {
      id: slug,
      name: newProj.name || 'New Service',
      description: newProj.description || 'Custom monitored service',
      enabled: true,
      status: 'UP',
      tags: newProj.tags || ['custom', 'v1'],
      location: newProj.location || {
        type: 'local',
        agentId: 'local',
        cwd: `/root/Software_projects/${slug}`,
      },
      runtime: newProj.runtime || {
        healthUrl: 'http://localhost:3000/health',
        port: 3000,
        command: 'npm',
        args: ['start'],
      },
      monitoring: {
        intervalSeconds: 30,
        timeoutSeconds: 10,
        expectedStatus: [200],
      },
      process: {
        alive: true,
        cpuPct: 5.2,
        memMB: 120.0,
        uptimeSec: 100,
        restarts: 0,
      },
      history: [
        { ts: '10:00', code: 200, latencyMs: 18.0 },
        { ts: '10:15', code: 200, latencyMs: 16.5 },
        { ts: '10:30', code: 200, latencyMs: 19.2 },
      ],
      uptime24h: 100,
      uptime7d: 100,
      uptime30d: 100,
      currentLatency: 17.5,
      lastChecked: 'Just now',
    };

    setProjects((prev) => [created, ...prev]);
    appendLog(created.id, `[INFO] Registered project ${created.id} into projects.json`);
    addAuditEntry('bearer_token:admin_ops', created.id, 'process_start', `Registered new project ${created.id}`);
  };

  return (
    <DashboardContext.Provider
      value={{
        design,
        setDesign,
        setMaterial,
        setComposition,
        setStructure,
        setFeeling,
        applyPreset,
        projects,
        activeProject,
        activeProjectId,
        setActiveProjectId,
        logs,
        incidents,
        deployments,
        auditLogs,
        agents,
        templates,
        filterStatus,
        setFilterStatus,
        searchQuery,
        setSearchQuery,
        isReadOnlyMode,
        setIsReadOnlyMode,
        authToken,
        rotateAuthToken,
        startProject,
        stopProject,
        restartProject,
        runHealthCheck,
        triggerDeploy,
        rollbackDeploy,
        executeTerminal,
        askAiDiagnosis,
        executeAiFix,
        acknowledgeIncident,
        resolveIncident,
        addNewProject,
        playHapticAudio,
        lastSyncTime,
      }}
    >
      {children}
    </DashboardContext.Provider>
  );
};

export const useDashboard = () => {
  const ctx = useContext(DashboardContext);
  if (!ctx) throw new Error('useDashboard must be used within DashboardProvider');
  return ctx;
};
